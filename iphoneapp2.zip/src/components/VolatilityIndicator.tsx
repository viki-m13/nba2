// Signal Status Indicator - shows if game conditions are favorable for signals
import React from 'react';
import { View, Text } from 'react-native';
import { Target, Clock, TrendingUp } from 'lucide-react-native';
import { cn } from '@/lib/cn';

interface VolatilityIndicatorProps {
  volatility: 'low' | 'medium' | 'high';
  showLabel?: boolean;
  size?: 'sm' | 'md';
}

export function VolatilityIndicator({
  volatility,
  showLabel = true,
  size = 'sm',
}: VolatilityIndicatorProps) {
  // Map volatility to signal-relevant status
  // low volatility = steady lead building = "Signal Zone"
  // medium volatility = normal game flow = "Monitoring"
  // high volatility = choppy/unpredictable = "No Edge"
  const config = {
    low: {
      icon: Target,
      label: 'Signal Zone',
      color: '#10B981',
      bgColor: 'bg-emerald-500/10',
    },
    medium: {
      icon: Clock,
      label: 'Monitoring',
      color: '#F59E0B',
      bgColor: 'bg-amber-500/10',
    },
    high: {
      icon: TrendingUp,
      label: 'No Edge',
      color: '#6B7280',
      bgColor: 'bg-gray-500/10',
    },
  };

  const { icon: Icon, label, color, bgColor } = config[volatility];
  const iconSize = size === 'sm' ? 12 : 16;

  return (
    <View className={cn('flex-row items-center rounded-full px-2 py-0.5', bgColor)}>
      <Icon size={iconSize} color={color} />
      {showLabel && (
        <Text
          className={cn(
            'ml-1 font-medium',
            size === 'sm' ? 'text-xs' : 'text-sm'
          )}
          style={{ color }}
        >
          {label}
        </Text>
      )}
    </View>
  );
}
