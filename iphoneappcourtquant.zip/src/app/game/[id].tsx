// Game Detail Screen
import React from 'react';
import { View, Text, ScrollView, Pressable } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { FadeIn, FadeInDown, FadeInUp } from 'react-native-reanimated';
import {
  ChevronLeft,
  Circle,
  TrendingUp,
  Activity,
  History,
  Lock,
  AlertCircle,
  Star,
  Users,
  Clock,
} from 'lucide-react-native';

import { useDiffFirstStore, useHasProAccess } from '@/lib/store';
import { DifferentialBadge } from '@/components/DifferentialBadge';
import { ScoreFlowChart } from '@/components/ScoreFlowChart';
import { AnalyticsPanel } from '@/components/AnalyticsPanel';
import { AlertCard } from '@/components/AlertCard';
import { LockedAlertCard } from '@/components/LockedAlertCard';
import { cn } from '@/lib/cn';

export default function GameDetailScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const insets = useSafeAreaInsets();

  const games = useDiffFirstStore((s) => s.games);
  const hasProAccess = useHasProAccess();
  const game = games.find((g) => g.id === id);

  if (!game) {
    return (
      <View className="flex-1 bg-[#0A0A0F] items-center justify-center">
        <Text className="text-gray-400">Game not found</Text>
        <Pressable
          onPress={() => router.back()}
          className="mt-4 bg-gray-800 px-4 py-2 rounded-lg"
        >
          <Text className="text-white">Go Back</Text>
        </Pressable>
      </View>
    );
  }

  const isLive = game.status === 'live';
  const isHalftime = game.status === 'halftime';
  const isFinal = game.status === 'final';

  // NEW APPROACH: Non-pro users see ALL signals but they're LOCKED
  // No more 15-minute delay - show that signals exist in real-time but hide the bet details

  // For pro users OR finished games: show all alerts normally
  // For non-pro users on live games: show locked cards
  const showLockedSignals = !hasProAccess && (isLive || isHalftime);

  // Separate active vs historical alerts (sorted newest to oldest)
  const activeAlerts = game.alerts
    .filter((a) => a.outcome === 'pending')
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  const historicalAlerts = game.alerts
    .filter((a) => a.outcome !== 'pending')
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  // Check for high conviction signals
  const hasHighConviction = activeAlerts.some(a => a.isHighConviction);

  const handleUpgradePress = () => {
    router.push('/paywall');
  };

  return (
    <View className="flex-1 bg-[#0A0A0F]">
      {/* Header with gradient */}
      <LinearGradient
        colors={[game.homeTeam.primaryColor + '40', '#0A0A0F']}
        style={{
          paddingTop: insets.top,
          paddingHorizontal: 20,
          paddingBottom: 20,
        }}
      >
        {/* Nav Bar */}
        <Animated.View
          entering={FadeIn.duration(300)}
          className="flex-row items-center justify-between mb-4"
        >
          <Pressable
            onPress={() => router.back()}
            className="flex-row items-center active:opacity-70"
          >
            <ChevronLeft size={24} color="#9CA3AF" />
            <Text className="text-gray-400 ml-1">Games</Text>
          </Pressable>

          {isLive && (
            <View className="flex-row items-center bg-red-500/20 px-3 py-1.5 rounded-full">
              <Circle size={6} fill="#EF4444" color="#EF4444" />
              <Text className="text-red-400 font-semibold ml-2">
                Q{game.quarter} {game.quarterTime}
              </Text>
            </View>
          )}
          {isHalftime && (
            <View className="bg-amber-500/20 px-3 py-1.5 rounded-full">
              <Text className="text-amber-400 font-semibold">HALFTIME</Text>
            </View>
          )}
          {isFinal && (
            <View className="flex-row items-center">
              <View className="bg-gray-700/50 px-3 py-1.5 rounded-full">
                <Text className="text-gray-400 font-semibold">FINAL</Text>
              </View>
              <Text className="text-gray-500 text-sm ml-2">{game.gameDate}</Text>
            </View>
          )}
          {game.status === 'scheduled' && (
            <View className="flex-row items-center">
              <Text className="text-gray-400 font-medium">{game.gameTime}</Text>
              <Text className="text-gray-500 text-sm ml-2">{game.gameDate}</Text>
            </View>
          )}
        </Animated.View>

        {/* Teams & Score Header */}
        <Animated.View entering={FadeInDown.delay(100).springify()}>
          <View className="flex-row items-center justify-between">
            {/* Home Team */}
            <View className="flex-1 items-center">
              <View
                className="w-16 h-16 rounded-full items-center justify-center mb-2"
                style={{ backgroundColor: game.homeTeam.primaryColor + '60' }}
              >
                <Text className="text-white font-black text-xl">
                  {game.homeTeam.abbreviation}
                </Text>
              </View>
              <Text className="text-white font-semibold">{game.homeTeam.city}</Text>
              <Text className="text-white text-3xl font-black mt-1">
                {game.homeScore}
              </Text>
            </View>

            {/* Spread - Center */}
            <View className="items-center px-4">
              <DifferentialBadge differential={game.differential} size="xl" />
              <Text className="text-gray-500 text-xs mt-1">
                {game.differential >= 0 ? game.homeTeam.abbreviation : game.awayTeam.abbreviation}{' '}
                {game.differential === 0 ? 'tied' : 'lead'}
              </Text>
              {game.possession && (isLive || isHalftime) && (
                <View className="flex-row items-center mt-2">
                  <Circle
                    size={8}
                    fill={
                      game.possession === 'home'
                        ? game.homeTeam.primaryColor
                        : game.awayTeam.primaryColor
                    }
                    color={
                      game.possession === 'home'
                        ? game.homeTeam.primaryColor
                        : game.awayTeam.primaryColor
                    }
                  />
                  <Text className="text-gray-400 text-xs ml-1">
                    {game.possession === 'home'
                      ? game.homeTeam.abbreviation
                      : game.awayTeam.abbreviation}{' '}
                    ball
                  </Text>
                </View>
              )}
            </View>

            {/* Away Team */}
            <View className="flex-1 items-center">
              <View
                className="w-16 h-16 rounded-full items-center justify-center mb-2"
                style={{ backgroundColor: game.awayTeam.primaryColor + '60' }}
              >
                <Text className="text-white font-black text-xl">
                  {game.awayTeam.abbreviation}
                </Text>
              </View>
              <Text className="text-white font-semibold">{game.awayTeam.city}</Text>
              <Text className="text-white text-3xl font-black mt-1">
                {game.awayScore}
              </Text>
            </View>
          </View>
        </Animated.View>
      </LinearGradient>

      <ScrollView
        className="flex-1"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
      >
        {/* Chart Section */}
        <Animated.View
          entering={FadeInUp.delay(200).springify()}
          className="px-5 mt-4"
        >
          {/* Chart Header */}
          <View className="flex-row items-center mb-3">
            <Text className="text-gray-400 text-sm font-semibold">
              ScoreFlow
            </Text>
            <Text className="text-gray-600 text-xs ml-2">
              Spread over time
            </Text>
          </View>

          {/* Chart */}
          <View className="bg-[#12121A] rounded-2xl p-3 border border-gray-800">
            {game.playByPlayAvailable ? (
              <ScoreFlowChart
                data={game.differentialHistory}
                runs={game.runs}
                supportLevels={game.analytics.supportLevels}
                resistanceLevels={game.analytics.resistanceLevels}
                alerts={game.alerts}
                homeTeamAbbr={game.homeTeam.abbreviation}
                awayTeamAbbr={game.awayTeam.abbreviation}
                hideSignals={showLockedSignals}
              />
            ) : (
              <View className="h-48 items-center justify-center">
                <AlertCircle size={32} color="#6B7280" />
                <Text className="text-gray-400 text-base font-medium mt-3">
                  Reliable Data Not Available
                </Text>
                <Text className="text-gray-600 text-xs mt-1 text-center px-4">
                  Play-by-play data is not available for this game
                </Text>
              </View>
            )}
          </View>

          {/* Run Highlights */}
          {game.runs.length > 0 && (
            <View className="mt-3">
              <Text className="text-gray-500 text-xs mb-2">Recent Runs</Text>
              <View className="flex-row flex-wrap">
                {game.runs.slice(-3).map((run, i) => (
                  <View
                    key={i}
                    className={cn(
                      'px-2 py-1 rounded-full mr-2 mb-1',
                      run.team === 'home' ? 'bg-emerald-500/20' : 'bg-red-500/20'
                    )}
                  >
                    <Text
                      className={cn(
                        'text-xs font-semibold',
                        run.team === 'home' ? 'text-emerald-400' : 'text-red-400'
                      )}
                    >
                      {run.team === 'home' ? game.homeTeam.abbreviation : game.awayTeam.abbreviation}{' '}
                      {run.description}
                    </Text>
                  </View>
                ))}
              </View>
            </View>
          )}
        </Animated.View>

        {/* Active Signals - Different display for pro vs non-pro users */}
        {activeAlerts.length > 0 && (
          <Animated.View
            entering={FadeInUp.delay(250).springify()}
            className="px-5 mt-4"
          >
            <View className="flex-row items-center justify-between mb-4">
              <View className="flex-row items-center">
                <TrendingUp size={16} color="#10B981" />
                <Text className="text-gray-400 text-sm font-semibold ml-2">
                  {showLockedSignals ? 'Live Signals' : `Active Signal${activeAlerts.length > 1 ? 's' : ''}`}
                </Text>
              </View>
              {showLockedSignals && hasHighConviction && (
                <View className="flex-row items-center bg-amber-500/20 px-2 py-1 rounded-full">
                  <Star size={12} color="#F59E0B" fill="#F59E0B" />
                  <Text className="text-amber-400 text-xs font-bold ml-1">HIGH CONVICTION</Text>
                </View>
              )}
            </View>

            {/* Pro users see full alert cards */}
            {!showLockedSignals && (
              <View className="space-y-4">
                {activeAlerts.map((alert, index) => (
                  <AlertCard key={alert.id} alert={alert} index={index} expanded />
                ))}
              </View>
            )}

            {/* Non-pro users see locked cards - shows signal exists but hides the bet */}
            {showLockedSignals && (
              <View className="space-y-3">
                {activeAlerts.map((alert, index) => (
                  <LockedAlertCard
                    key={alert.id}
                    alert={alert}
                    onUpgradePress={handleUpgradePress}
                    index={index}
                  />
                ))}
              </View>
            )}
          </Animated.View>
        )}

        {/* Signal History (resolved alerts - wins/losses/pushes) */}
        {historicalAlerts.length > 0 && (
          <Animated.View
            entering={FadeInUp.delay(350).springify()}
            className="px-5 mt-6"
          >
            <View className="flex-row items-center mb-4">
              <History size={16} color="#6B7280" />
              <Text className="text-gray-400 text-sm font-semibold ml-2">
                Signal History
              </Text>
            </View>
            <View className="space-y-4">
              {historicalAlerts.map((alert, index) => (
                <AlertCard key={alert.id} alert={alert} index={index} expanded />
              ))}
            </View>
          </Animated.View>
        )}

        {/* Analytics Panel */}
        <Animated.View
          entering={FadeInUp.delay(400).springify()}
          className="px-5 mt-6"
        >
          <View className="flex-row items-center mb-3">
            <Activity size={16} color="#6B7280" />
            <Text className="text-gray-400 text-sm font-semibold ml-2">
              Technical Indicators
            </Text>
          </View>
          <AnalyticsPanel
            analytics={game.analytics}
            currentDifferential={game.differential}
          />
        </Animated.View>
      </ScrollView>
    </View>
  );
}
