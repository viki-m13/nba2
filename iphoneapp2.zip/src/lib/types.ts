// DiffFirst Type Definitions

export interface Team {
  id: string;
  name: string;
  abbreviation: string;
  city: string;
  primaryColor: string;
  secondaryColor: string;
  logo?: string;
}

export interface Possession {
  id: string;
  timestamp: number; // seconds into the game
  quarter: number;
  quarterTime: string; // "4:12" format
  team: 'home' | 'away';
  homeScore: number;
  awayScore: number;
  differential: number; // home - away
  fairDifferential: number; // de-noised d*
  event: 'score' | 'turnover' | 'foul' | 'timeout' | 'quarter_end';
  pointsScored?: number;
  description?: string;
}

export interface DifferentialPoint {
  possession: number;
  differential: number;
  fairDifferential: number;
  timestamp: number;
  quarter: number;
}

export interface Run {
  startPossession: number;
  endPossession: number;
  team: 'home' | 'away';
  points: number;
  opposingPoints: number;
  description: string; // "12-2 run"
}

export interface SupportResistanceLevel {
  level: number;
  type: 'support' | 'resistance';
  touches: number;
  strength: 'weak' | 'moderate' | 'strong';
  identifiedAt?: {
    quarter: number;
    gameTime: string; // "Q2 4:32"
    possessionIndex: number; // For chart placement
  };
}

export interface GameAnalytics {
  // Spread Strategy Indicators
  rsi7: number; // 0-100, 7-period RSI on differential changes
  rsi14: number; // 0-100, 14-period RSI on differential changes
  slope6: number; // 6-possession linear regression slope of differential
  slopeFromStart: number; // Linear regression slope from game start to now
  // Legacy/display
  raRSI: number; // 0-100, Run-Adjusted RSI (legacy, same as rsi7)
  trendStrength: number; // -1 to 1
  trendDirection: 'bullish' | 'bearish' | 'neutral';
  volatility: 'low' | 'medium' | 'high';
  regimeShift: boolean;
  regimeShiftConfirmed: boolean;
  supportLevels: SupportResistanceLevel[];
  resistanceLevels: SupportResistanceLevel[];
  currentMomentum: 'home' | 'away' | 'neutral';
  meanReversionStretch: boolean;
  // Momentum ML indicators
  momentumSwing: number; // Point swing over last 10 possessions (positive = home gaining)
  isCloseGame: boolean; // Within 3 points (for ML strategy)
  // Lead Regression Strategy Indicators
  leadRegressionEligible: boolean; // Whether conditions are met for lead regression signal
  blowoutDetected: boolean; // True if lead is accelerating (skip signal)
  recentLeadMaxCount: number; // Count of new lead highs in last 15 possessions
}

export interface OddsData {
  homeSpread: number;
  homeSpreadOdds: number;
  awaySpread: number;
  awaySpreadOdds: number;
  homeMoneyline: number;
  awayMoneyline: number;
  total: number;
  overOdds: number;
  underOdds: number;
  impliedHomeProbability: number;
  impliedAwayProbability: number;
}

export interface SignalIndicatorState {
  name: string;
  value: string | number;
  explanation: string;
  signalContribution: 'bullish' | 'bearish' | 'neutral';
}

// Signal strategy type - Momentum spread only (4 strategies: sweet_spot, moderate, mid_range, safe)
export type SignalStrategy = 'momentum';

export interface Alert {
  id: string;
  gameId: string;
  timestamp: Date;
  gameTime: string; // "Q2 4:32" - when signal was generated
  betType: 'spread' | 'total';
  team: 'home' | 'away';
  recommendation: string; // "LAL +4.5"
  edge: number; // percentage edge vs market
  modelProbability: number;
  impliedProbability: number;
  confidence: 'low' | 'medium' | 'high';
  reasonCodes: string[];
  riskLevel: 'low' | 'medium' | 'high';
  outcome?: 'win' | 'loss' | 'push' | 'pending';
  // High conviction flag - less frequent, higher confidence
  isHighConviction?: boolean;
  // Signal strategy type - default 'momentum' for backward compatibility
  signalStrategy?: SignalStrategy;
  // Explicit bet instruction
  betInstruction: string; // "BET: Take LAL +4.5 spread"
  expectedOutcome: string; // "EXPECT: Lakers to cover the +4.5 spread (keep game within 4 points or win)"
  // Historical tracking - no forward bias
  scoreAtSignal: { home: number; away: number; differential: number };
  possessionIndex?: number; // For chart placement - index into differentialHistory
  indicatorsAtSignal: SignalIndicatorState[];
  supportResistanceAtSignal?: SupportResistanceLevel[];
  // Lead Regression specific fields
  leadAtSignal?: number; // The lead size when signal fired (for lead regression)
  leadAtEnd?: number; // The final lead (for grading)
  // Reduced spread bet value (e.g., -7 for sweet_spot/moderate/mid_range, -5 for safe)
  spreadBet?: number;
}

export interface Game {
  id: string;
  homeTeam: Team;
  awayTeam: Team;
  homeScore: number;
  awayScore: number;
  differential: number;
  fairDifferential: number;
  quarter: number;
  quarterTime: string;
  gameTime: string; // "7:30 PM ET"
  gameDate: string; // "Jan 4" or "Today"
  status: 'scheduled' | 'live' | 'halftime' | 'final';
  possession: 'home' | 'away' | null;
  possessions: Possession[];
  differentialHistory: DifferentialPoint[];
  runs: Run[];
  analytics: GameAnalytics;
  odds?: OddsData;
  alerts: Alert[];
  // Sparkline data (last ~20 possessions)
  recentDifferentials: number[];
  // Whether reliable play-by-play data is available
  playByPlayAvailable: boolean;
}

export type UserTeamPreference = string | null; // team id for perspective
