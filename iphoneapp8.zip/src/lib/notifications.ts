// Push Notification Service for CourtQuant
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';
import type { Alert } from './types';

// Configure notification handler - how notifications behave when app is foregrounded
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldPlaySound: true,
    shouldSetBadge: true,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

// Request notification permissions
export async function requestNotificationPermissions(): Promise<boolean> {
  if (!Device.isDevice) {
    console.log('[Notifications] Must use physical device for push notifications');
    return false;
  }

  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;

  if (existingStatus !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync({
      ios: {
        allowAlert: true,
        allowBadge: true,
        allowSound: true,
      },
    });
    finalStatus = status;
  }

  if (finalStatus !== 'granted') {
    console.log('[Notifications] Permission not granted');
    return false;
  }

  // Set up Android notification channel
  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('signals', {
      name: 'Signal Alerts',
      importance: Notifications.AndroidImportance.HIGH,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: '#10B981',
      sound: 'default',
    });
  }

  console.log('[Notifications] Permissions granted');
  return true;
}

// Check if notifications are enabled
export async function areNotificationsEnabled(): Promise<boolean> {
  if (!Device.isDevice) return false;

  const { status } = await Notifications.getPermissionsAsync();
  return status === 'granted';
}

// Send immediate notification for a signal alert
export async function sendSignalNotification(
  alert: Alert,
  gameContext: { homeTeam: string; awayTeam: string; quarter: number; time: string }
): Promise<string | null> {
  try {
    const isHighConviction = alert.isHighConviction;

    const title = isHighConviction
      ? `⚡ HIGH CONVICTION: ${alert.recommendation}`
      : `📊 Signal: ${alert.recommendation}`;

    const body = `${gameContext.homeTeam} vs ${gameContext.awayTeam} • Q${gameContext.quarter} ${gameContext.time}\n${alert.betInstruction}`;

    const identifier = await Notifications.scheduleNotificationAsync({
      content: {
        title,
        body,
        data: {
          alertId: alert.id,
          gameId: alert.gameId,
          type: 'signal',
          isHighConviction,
        },
        sound: 'default',
        ...(Platform.OS === 'android' && { channelId: 'signals' }),
      },
      trigger: null, // null = immediate
    });

    console.log('[Notifications] Sent signal notification:', identifier);
    return identifier;
  } catch (error) {
    console.error('[Notifications] Error sending notification:', error);
    return null;
  }
}

// Send notification for alert outcome (win/loss)
export async function sendOutcomeNotification(
  alert: Alert,
  gameContext: { homeTeam: string; awayTeam: string }
): Promise<string | null> {
  if (!alert.outcome || alert.outcome === 'pending') return null;

  try {
    const isWin = alert.outcome === 'win';
    const isPush = alert.outcome === 'push';

    const emoji = isWin ? '✅' : isPush ? '➖' : '❌';
    const result = isWin ? 'WIN' : isPush ? 'PUSH' : 'LOSS';

    const title = `${emoji} ${result}: ${alert.recommendation}`;
    const body = `${gameContext.homeTeam} vs ${gameContext.awayTeam} - Signal resolved`;

    const identifier = await Notifications.scheduleNotificationAsync({
      content: {
        title,
        body,
        data: {
          alertId: alert.id,
          gameId: alert.gameId,
          type: 'outcome',
          outcome: alert.outcome,
        },
        sound: 'default',
        ...(Platform.OS === 'android' && { channelId: 'signals' }),
      },
      trigger: null,
    });

    console.log('[Notifications] Sent outcome notification:', identifier);
    return identifier;
  } catch (error) {
    console.error('[Notifications] Error sending outcome notification:', error);
    return null;
  }
}

// Cancel all pending notifications
export async function cancelAllNotifications(): Promise<void> {
  await Notifications.cancelAllScheduledNotificationsAsync();
  console.log('[Notifications] Cancelled all notifications');
}

// Get notification listeners setup helper
export function setupNotificationListeners(
  onNotificationReceived?: (notification: Notifications.Notification) => void,
  onNotificationResponse?: (response: Notifications.NotificationResponse) => void
) {
  const receivedSubscription = Notifications.addNotificationReceivedListener(
    (notification) => {
      console.log('[Notifications] Received:', notification);
      onNotificationReceived?.(notification);
    }
  );

  const responseSubscription = Notifications.addNotificationResponseReceivedListener(
    (response) => {
      console.log('[Notifications] User tapped:', response);
      onNotificationResponse?.(response);
    }
  );

  return () => {
    receivedSubscription.remove();
    responseSubscription.remove();
  };
}

// Badge management
export async function setBadgeCount(count: number): Promise<void> {
  await Notifications.setBadgeCountAsync(count);
}

export async function clearBadge(): Promise<void> {
  await Notifications.setBadgeCountAsync(0);
}
