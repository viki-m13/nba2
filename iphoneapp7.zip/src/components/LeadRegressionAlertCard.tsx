// Lead Regression Alert Card - Displays lead regression signals
// Strategy: Bet on trailing team when lead is large (12+) - leads tend to shrink
import React from 'react';
import { View, Text, Pressable } from 'react-native';
import Animated, { FadeInUp, useAnimatedStyle, withRepeat, withSequence, withTiming } from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { TrendingDown, AlertTriangle, CheckCircle, XCircle, Clock, Star, ArrowDownRight } from 'lucide-react-native';

import type { Alert } from '@/lib/types';

interface LeadRegressionAlertCardProps {
  alert: Alert;
  expanded?: boolean;
  onPress?: () => void;
  index?: number;
  isHighConviction?: boolean;
}

export function LeadRegressionAlertCard({
  alert,
  expanded = false,
  onPress,
  index = 0,
  isHighConviction,
}: LeadRegressionAlertCardProps) {
  const isHC = isHighConviction ?? alert.isHighConviction;
  const pulseStyle = useAnimatedStyle(() => {
    if (alert.outcome !== 'pending') return { opacity: 1 };
    return {
      opacity: withRepeat(
        withSequence(
          withTiming(1, { duration: 1000 }),
          withTiming(0.7, { duration: 1000 })
        ),
        -1,
        true
      ),
    };
  });

  const confidenceColors = {
    low: { bg: '#F59E0B20', border: '#F59E0B40', text: '#F59E0B' },
    medium: { bg: '#06B6D420', border: '#06B6D440', text: '#06B6D4' },
    high: { bg: '#06B6D430', border: '#06B6D460', text: '#06B6D4' },
  };

  const riskColors = {
    low: '#10B981',
    medium: '#F59E0B',
    high: '#EF4444',
  };

  const outcomeConfig = {
    pending: { icon: Clock, color: '#6B7280', label: 'Pending' },
    win: { icon: CheckCircle, color: '#10B981', label: 'Win' },
    loss: { icon: XCircle, color: '#EF4444', label: 'Loss' },
    push: { icon: AlertTriangle, color: '#F59E0B', label: 'Push' },
  };

  const outcome = outcomeConfig[alert.outcome || 'pending'];

  return (
    <Animated.View entering={FadeInUp.delay(index * 100).springify()}>
      <Pressable onPress={onPress} className="active:opacity-80">
        <View className="overflow-hidden rounded-2xl">
          <LinearGradient
            colors={
              isHC
                ? ['#06B6D425', '#06B6D408']
                : alert.confidence === 'high'
                ? ['#06B6D415', '#06B6D405']
                : ['#1A1A24', '#12121A']
            }
            style={{
              padding: 16,
              borderRadius: 16,
              borderWidth: isHC ? 2 : 1,
              borderColor: isHC ? '#06B6D460' : confidenceColors[alert.confidence].border,
            }}
          >
            {/* High Conviction Badge */}
            {isHC && (
              <View className="flex-row items-center justify-center rounded-lg py-1.5 mb-3 bg-cyan-500/20">
                <Star size={14} color="#06B6D4" fill="#06B6D4" />
                <Text className="text-xs font-bold ml-1.5 uppercase tracking-wider text-cyan-400">
                  Lead Regression Signal
                </Text>
              </View>
            )}

            {/* Header */}
            <View className="flex-row items-center justify-between mb-3">
              <View className="flex-row items-center">
                <Animated.View
                  style={[
                    {
                      backgroundColor: confidenceColors[alert.confidence].bg,
                      borderRadius: 20,
                      padding: 6,
                    },
                    pulseStyle,
                  ]}
                >
                  <ArrowDownRight size={16} color={confidenceColors[alert.confidence].text} />
                </Animated.View>
                <View className="ml-3">
                  <Text
                    className="font-bold text-lg"
                    style={{ color: confidenceColors[alert.confidence].text }}
                  >
                    {alert.recommendation}
                  </Text>
                  <Text className="text-gray-500 text-xs">
                    LEAD REGRESSION
                  </Text>
                </View>
              </View>

              {/* Outcome Badge */}
              <View
                className="flex-row items-center px-2 py-1 rounded-full"
                style={{ backgroundColor: `${outcome.color}20` }}
              >
                <outcome.icon size={14} color={outcome.color} />
                <Text
                  className="text-xs font-semibold ml-1"
                  style={{ color: outcome.color }}
                >
                  {outcome.label}
                </Text>
              </View>
            </View>

            {/* Lead Regression Stats */}
            <View className="bg-gray-800/50 rounded-xl p-3 mb-3">
              <View className="flex-row justify-between items-center mb-2">
                <View>
                  <Text className="text-gray-400 text-xs mb-1">Model Prob</Text>
                  <Text className="text-xl font-bold text-cyan-400">
                    {alert.modelProbability}%
                  </Text>
                </View>
                <View className="items-center">
                  <TrendingDown size={20} color="#06B6D4" />
                  <Text className="font-bold mt-1 text-cyan-400">
                    +{alert.edge}%
                  </Text>
                  <Text className="text-gray-500 text-xs">Edge</Text>
                </View>
                <View className="items-end">
                  <Text className="text-gray-400 text-xs mb-1">Market Prob</Text>
                  <Text className="text-gray-300 text-xl font-bold">
                    {alert.impliedProbability}%
                  </Text>
                </View>
              </View>
              {/* Lead Details */}
              <View className="flex-row justify-between items-center pt-2 border-t border-gray-700/50">
                <View className="flex-row items-center">
                  <Text className="text-gray-500 text-xs">Lead at Signal: </Text>
                  <Text className="text-white text-xs font-semibold">
                    {alert.leadAtSignal || Math.abs(alert.scoreAtSignal?.differential || 0)} pts
                  </Text>
                </View>
                {alert.leadAtEnd !== undefined && (
                  <View className="flex-row items-center">
                    <Text className="text-gray-500 text-xs">Final Lead: </Text>
                    <Text
                      className="text-xs font-semibold"
                      style={{
                        color:
                          alert.leadAtEnd < (alert.leadAtSignal || 0)
                            ? '#10B981'
                            : alert.leadAtEnd > (alert.leadAtSignal || 0)
                            ? '#EF4444'
                            : '#F59E0B',
                      }}
                    >
                      {alert.leadAtEnd} pts
                    </Text>
                  </View>
                )}
              </View>
            </View>

            {/* Bet Instruction & Expected Outcome */}
            {alert.betInstruction && (
              <View className="bg-cyan-500/10 border border-cyan-500/30 rounded-xl p-3 mb-3">
                <Text className="text-cyan-400 font-bold text-base mb-2">
                  {alert.betInstruction}
                </Text>
                <Text className="text-gray-300 text-sm leading-5">
                  {alert.expectedOutcome}
                </Text>
              </View>
            )}

            {/* Reason Codes */}
            {expanded && (
              <View className="mb-3">
                <Text className="text-gray-400 text-xs mb-2 font-semibold">
                  REGRESSION INDICATORS
                </Text>
                {alert.reasonCodes.map((reason, i) => (
                  <View key={i} className="flex-row items-start mb-1.5">
                    <View className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1.5 mr-2" />
                    <Text className="text-gray-300 text-sm flex-1">{reason}</Text>
                  </View>
                ))}
              </View>
            )}

            {/* Footer - Confidence & Risk */}
            <View className="flex-row items-center justify-between pt-3 border-t border-gray-800/50">
              <View className="flex-row items-center">
                <View
                  className="px-2 py-1 rounded-full mr-2"
                  style={{ backgroundColor: confidenceColors[alert.confidence].bg }}
                >
                  <Text
                    className="text-xs font-semibold"
                    style={{ color: confidenceColors[alert.confidence].text }}
                  >
                    {alert.confidence.toUpperCase()} CONFIDENCE
                  </Text>
                </View>
              </View>
              <View className="flex-row items-center">
                <Text className="text-gray-500 text-xs mr-1">Risk:</Text>
                <View
                  className="w-2 h-2 rounded-full mr-1"
                  style={{ backgroundColor: riskColors[alert.riskLevel] }}
                />
                <Text
                  className="text-xs font-semibold"
                  style={{ color: riskColors[alert.riskLevel] }}
                >
                  {alert.riskLevel.toUpperCase()}
                </Text>
              </View>
            </View>

            {/* Timestamp */}
            <Text className="text-gray-600 text-xs mt-2 text-center">
              Signal generated at {alert.gameTime}
            </Text>
          </LinearGradient>
        </View>
      </Pressable>
    </Animated.View>
  );
}

// Compact version for game detail screen
export function LeadRegressionAlertCardCompact({ alert }: { alert: Alert }) {
  return (
    <View className="rounded-xl p-3 bg-cyan-500/10 border border-cyan-500/30">
      <View className="flex-row items-center mb-2">
        <View className="rounded-full p-2 mr-3 bg-cyan-500/20">
          <ArrowDownRight size={16} color="#06B6D4" />
        </View>
        <View className="flex-1">
          <Text className="font-bold text-cyan-400">{alert.recommendation}</Text>
          <Text className="text-gray-400 text-xs">
            LEAD REGRESSION • {alert.gameTime}
          </Text>
        </View>
      </View>
      {/* Probability Stats */}
      <View className="bg-gray-800/30 rounded-lg p-2 mb-2">
        <View className="flex-row justify-between items-center mb-2">
          <View>
            <Text className="text-gray-500 text-xs">Model</Text>
            <Text className="text-base font-bold text-cyan-400">{alert.modelProbability}%</Text>
          </View>
          <View className="items-center">
            <Text className="text-gray-500 text-xs">Edge</Text>
            <Text className="text-base font-bold text-cyan-400">+{alert.edge}%</Text>
          </View>
          <View className="items-end">
            <Text className="text-gray-500 text-xs">Market</Text>
            <Text className="text-gray-300 text-base font-bold">{alert.impliedProbability}%</Text>
          </View>
        </View>
        {/* Lead Details */}
        <View className="flex-row justify-between items-center pt-2 border-t border-gray-700/30">
          <View className="flex-row items-center">
            <Text className="text-gray-500 text-xs">Lead: </Text>
            <Text className="text-white text-xs font-semibold">
              {alert.leadAtSignal || Math.abs(alert.scoreAtSignal?.differential || 0)} pts
            </Text>
          </View>
          <View className="flex-row items-center">
            <Text className="text-gray-500 text-xs">Quarter: </Text>
            <Text className="text-white text-xs font-semibold">
              {alert.gameTime.split(' ')[0]}
            </Text>
          </View>
        </View>
      </View>
      {alert.betInstruction && (
        <View className="bg-gray-800/40 rounded-lg p-2">
          <Text className="text-xs font-semibold text-cyan-400">{alert.betInstruction}</Text>
          <Text className="text-gray-400 text-xs mt-1">{alert.expectedOutcome}</Text>
        </View>
      )}
    </View>
  );
}
