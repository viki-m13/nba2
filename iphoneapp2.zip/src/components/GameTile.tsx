// Game Tile - Clean quant-focused design
import React from 'react';
import { View, Text, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import Animated, {
  FadeInDown,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withRepeat,
  withSequence,
  withTiming,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { Circle, Zap, Lock, TrendingUp, CircleDot } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';

import type { Game } from '@/lib/types';
import { Sparkline } from './Sparkline';
import { VolatilityIndicator } from './VolatilityIndicator';

interface GameTileProps {
  game: Game;
  index?: number;
  delayedMode?: boolean;
  onUpgradePress?: () => void;
}

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

// Format time ago for signals
function formatTimeAgo(timestamp: Date): string {
  const now = Date.now();
  const alertTime = new Date(timestamp).getTime();
  const diffMs = now - alertTime;
  const diffSeconds = Math.floor(diffMs / 1000);
  const diffMinutes = Math.floor(diffSeconds / 60);

  if (diffSeconds < 30) return 'Just now';
  if (diffSeconds < 60) return `${diffSeconds}s`;
  if (diffMinutes < 60) return `${diffMinutes}m`;
  return `${Math.floor(diffMinutes / 60)}h`;
}

export function GameTile({ game, index = 0, delayedMode = false, onUpgradePress }: GameTileProps) {
  const router = useRouter();
  const scale = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  // Pulsing animation for locked signals indicator
  const pulseStyle = useAnimatedStyle(() => ({
    opacity: withRepeat(
      withSequence(
        withTiming(1, { duration: 800 }),
        withTiming(0.6, { duration: 800 })
      ),
      -1,
      true
    ),
  }));

  const handlePressIn = () => {
    scale.value = withSpring(0.98, { damping: 15 });
  };

  const handlePressOut = () => {
    scale.value = withSpring(1, { damping: 15 });
  };

  const handlePress = () => {
    // All users can view game details - scores are live
    router.push(`/game/${game.id}`);
  };

  const isLive = game.status === 'live';
  const isHalftime = game.status === 'halftime';
  const isScheduled = game.status === 'scheduled';

  // NEW APPROACH: Non-pro users see ALL signals exist but they're LOCKED
  // No more 15-minute delay - show real-time that signals fired but hide the bet
  const totalAlerts = game.alerts.length;
  const hasAlerts = totalAlerts > 0;

  // For pro users: show all alerts normally
  // For non-pro users: show that alerts exist but they're locked
  const lockedSignalsCount = delayedMode ? totalAlerts : 0;
  const unlockedSignalsCount = delayedMode ? 0 : totalAlerts;

  // Get the most recent alert for showing "just fired" urgency
  const mostRecentAlert = game.alerts.length > 0
    ? game.alerts.reduce((latest, alert) =>
        new Date(alert.timestamp).getTime() > new Date(latest.timestamp).getTime() ? alert : latest
      )
    : null;

  // Scores are always shown live
  // Only signals are subject to the 15-minute delay
  const showLiveData = true; // Scores always live
  const isLiveButDelayed = false; // Never hide scores

  // Format spread display - for scheduled games show "Upcoming"
  const spread = game.differential;
  const spreadDisplay = isScheduled
    ? 'UPCOMING'
    : isLiveButDelayed
    ? '---'
    : spread > 0
    ? `+${spread}`
    : spread === 0
    ? 'EVEN'
    : `${spread}`;
  const leadingTeam = isScheduled || isLiveButDelayed
    ? null
    : spread > 0
    ? game.homeTeam.abbreviation
    : spread < 0
    ? game.awayTeam.abbreviation
    : null;

  return (
    <AnimatedPressable
      entering={FadeInDown.delay(index * 50).springify()}
      style={animatedStyle}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      onPress={handlePress}
      className="mb-3"
    >
      <View className="overflow-hidden rounded-2xl">
        <LinearGradient
          colors={['#1A1A24', '#12121A']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{
            padding: 16,
            borderRadius: 16,
            borderWidth: 1,
            borderColor: hasAlerts ? '#10B981' : '#1E1E2E',
          }}
        >
          {/* Top Row - Status & Signal */}
          <View className="flex-row items-center justify-between mb-3">
            <View className="flex-row items-center">
              {isLive && (
                <View className="flex-row items-center bg-red-500/20 px-2 py-1 rounded-full mr-2">
                  <Circle size={6} fill="#EF4444" color="#EF4444" />
                  <Text className="text-red-400 text-xs font-semibold ml-1">
                    Q{game.quarter} {game.quarterTime}
                  </Text>
                </View>
              )}
              {isHalftime && (
                <View className="bg-amber-500/20 px-2 py-1 rounded-full mr-2">
                  <Text className="text-amber-400 text-xs font-semibold">HALFTIME</Text>
                </View>
              )}
              {game.status === 'scheduled' && game.gameTime && (
                <Text className="text-gray-400 text-sm font-medium">{game.gameTime}</Text>
              )}
              {game.status === 'final' && (
                <View className="bg-gray-700/50 px-2 py-1 rounded-full mr-2">
                  <Text className="text-gray-400 text-xs font-semibold">FINAL</Text>
                </View>
              )}
              {/* Game Date - show for all games */}
              <Text className="text-gray-500 text-xs ml-1">
                {game.gameDate}
              </Text>
            </View>

            {hasAlerts && !delayedMode && (
              <View className="flex-row items-center bg-emerald-500/20 px-2 py-1 rounded-full">
                <Zap size={12} color="#10B981" />
                <Text className="text-emerald-400 text-xs font-semibold ml-1">
                  {totalAlerts} SIGNAL{totalAlerts > 1 ? 'S' : ''}
                </Text>
              </View>
            )}
            {/* LOCKED SIGNALS - For non-pro users, show real-time that signals exist */}
            {hasAlerts && delayedMode && (isLive || isHalftime) && (
              <Pressable
                onPress={() => {
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                  onUpgradePress?.();
                }}
                className="flex-row items-center"
              >
                <Animated.View
                  style={pulseStyle}
                  className="flex-row items-center bg-emerald-500/20 border border-emerald-500/40 px-2 py-1 rounded-full"
                >
                  <Lock size={10} color="#10B981" />
                  <Text className="text-emerald-400 text-xs font-bold ml-1">
                    {totalAlerts} LIVE
                  </Text>
                </Animated.View>
                {mostRecentAlert && (
                  <Text className="text-gray-500 text-xs ml-1.5">
                    {formatTimeAgo(mostRecentAlert.timestamp)}
                  </Text>
                )}
              </Pressable>
            )}
            {/* For finished games in delayed mode - show signals were available */}
            {hasAlerts && delayedMode && game.status === 'final' && (
              <View className="flex-row items-center bg-gray-700/30 px-2 py-1 rounded-full">
                <Zap size={12} color="#6B7280" />
                <Text className="text-gray-400 text-xs font-semibold ml-1">
                  {totalAlerts} SIGNAL{totalAlerts > 1 ? 'S' : ''}
                </Text>
              </View>
            )}
          </View>

          {/* Main Content */}
          <View className="flex-row items-center">
            {/* Teams & Scores */}
            <View className="flex-1">
              {/* Home Team */}
              <View className="flex-row items-center justify-between mb-2">
                <View className="flex-row items-center flex-1">
                  <View
                    className="w-8 h-8 rounded-lg items-center justify-center mr-3"
                    style={{ backgroundColor: game.homeTeam.primaryColor + '30' }}
                  >
                    <Text
                      className="font-bold text-xs"
                      style={{ color: game.homeTeam.primaryColor }}
                    >
                      {game.homeTeam.abbreviation.slice(0, 2)}
                    </Text>
                  </View>
                  <Text className="text-white font-semibold text-base">
                    {game.homeTeam.abbreviation}
                  </Text>
                </View>
                <Text className={`text-xl font-bold tabular-nums ${isLiveButDelayed ? 'text-gray-600' : 'text-white'}`}>
                  {isLiveButDelayed ? '--' : game.homeScore}
                </Text>
              </View>

              {/* Away Team */}
              <View className="flex-row items-center justify-between">
                <View className="flex-row items-center flex-1">
                  <View
                    className="w-8 h-8 rounded-lg items-center justify-center mr-3"
                    style={{ backgroundColor: game.awayTeam.primaryColor + '30' }}
                  >
                    <Text
                      className="font-bold text-xs"
                      style={{ color: game.awayTeam.primaryColor }}
                    >
                      {game.awayTeam.abbreviation.slice(0, 2)}
                    </Text>
                  </View>
                  <Text className="text-white font-semibold text-base">
                    {game.awayTeam.abbreviation}
                  </Text>
                </View>
                <Text className={`text-xl font-bold tabular-nums ${isLiveButDelayed ? 'text-gray-600' : 'text-white'}`}>
                  {isLiveButDelayed ? '--' : game.awayScore}
                </Text>
              </View>
            </View>

            {/* Current Spread - The Key Metric */}
            <View className="items-center ml-4 pl-4 border-l border-gray-800">
              <Text
                className={`font-black tabular-nums ${
                  isScheduled
                    ? 'text-gray-500 text-sm'
                    : isLiveButDelayed
                    ? 'text-gray-600 text-xl'
                    : spread > 0
                    ? 'text-emerald-400 text-2xl'
                    : spread < 0
                    ? 'text-red-400 text-2xl'
                    : 'text-gray-400 text-2xl'
                }`}
              >
                {spreadDisplay}
              </Text>
              <Text className="text-gray-500 text-xs mt-0.5">
                {isScheduled ? '' : isLiveButDelayed ? 'Locked' : leadingTeam ? `${leadingTeam}` : 'Tied'}
              </Text>
            </View>
          </View>

          {/* Bottom Row - Momentum Sparkline (Live games only, not in delayed mode) */}
          {(isLive || isHalftime) && game.recentDifferentials.length > 2 && showLiveData && (
            <View className="flex-row items-center justify-between mt-4 pt-3 border-t border-gray-800/50">
              <View className="flex-row items-center flex-1">
                <Text className="text-gray-500 text-xs mr-2">Momentum</Text>
                <Sparkline
                  data={game.recentDifferentials}
                  width={120}
                  height={24}
                />
              </View>
              <VolatilityIndicator volatility={game.analytics.volatility} />
            </View>
          )}
        </LinearGradient>
      </View>
    </AnimatedPressable>
  );
}
