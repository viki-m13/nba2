// App Entry - v5.0 RSI+Slope Strategy
import { useEffect, useRef, useCallback } from 'react';
import { AppState, AppStateStatus } from 'react-native';
import { DarkTheme, ThemeProvider } from '@react-navigation/native';
import { Stack, useRouter } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { StatusBar } from 'expo-status-bar';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { KeyboardProvider } from 'react-native-keyboard-controller';
import { useDiffFirstStore } from '@/lib/store';
import {
  requestNotificationPermissions,
  setupNotificationListeners,
  sendSignalNotification,
  clearBadge,
} from '@/lib/notifications';
import type { Alert } from '@/lib/types';

export const unstable_settings = {
  initialRouteName: 'index',
};

// Prevent the splash screen from auto-hiding before asset loading is complete.
SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient();

// Custom dark theme for CourtQuant
const CourtQuantTheme = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    primary: '#10B981', // Emerald green for positive
    background: '#0A0A0F',
    card: '#12121A',
    text: '#FFFFFF',
    border: '#1E1E2E',
    notification: '#EF4444',
  },
};

function RootLayoutNav() {
  return (
    <ThemeProvider value={CourtQuantTheme}>
      <Stack
        screenOptions={{
          headerShown: false,
          contentStyle: { backgroundColor: '#0A0A0F' },
          animation: 'slide_from_right',
        }}
      >
        <Stack.Screen name="index" />
        <Stack.Screen
          name="game/[id]"
          options={{
            animation: 'slide_from_bottom',
          }}
        />
        <Stack.Screen
          name="alerts"
          options={{
            presentation: 'fullScreenModal',
            animation: 'slide_from_bottom',
          }}
        />
        <Stack.Screen
          name="paywall"
          options={{
            presentation: 'fullScreenModal',
            animation: 'slide_from_bottom',
          }}
        />
        <Stack.Screen
          name="settings"
          options={{
            presentation: 'fullScreenModal',
            animation: 'slide_from_bottom',
          }}
        />
        <Stack.Screen
          name="backtest"
          options={{
            presentation: 'fullScreenModal',
            animation: 'slide_from_bottom',
          }}
        />
        <Stack.Screen
          name="how-it-works"
          options={{
            presentation: 'fullScreenModal',
            animation: 'slide_from_bottom',
          }}
        />
      </Stack>
    </ThemeProvider>
  );
}

// Hook to manage notifications for signal alerts
function useNotificationManager() {
  const router = useRouter();
  const alertsEnabled = useDiffFirstStore((s) => s.alertsEnabled);
  const games = useDiffFirstStore((s) => s.games);
  const hasProAccess = useDiffFirstStore((s) => s.hasProAccess);
  const signalTypePreference = useDiffFirstStore((s) => s.signalTypePreference);
  const fetchRealGames = useDiffFirstStore((s) => s.fetchRealGames);

  // Track which alerts we've already notified about
  const notifiedAlertsRef = useRef<Set<string>>(new Set());
  const refreshIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const appStateRef = useRef<AppStateStatus>(AppState.currentState);

  // Check if there are any live games
  const hasLiveGames = games.some((g) => g.status === 'live' || g.status === 'halftime');

  // Request permissions on mount if alerts are enabled
  useEffect(() => {
    if (alertsEnabled) {
      requestNotificationPermissions();
    }
  }, [alertsEnabled]);

  // Set up notification listeners
  useEffect(() => {
    const cleanup = setupNotificationListeners(
      // On notification received (while app is open)
      (notification) => {
        console.log('[Notifications] Received while app open:', notification.request.content.title);
      },
      // On notification tapped
      (response) => {
        const data = response.notification.request.content.data;
        if (data?.gameId && typeof data.gameId === 'string') {
          // Navigate to the game screen
          router.push(`/game/${data.gameId}`);
        } else if (data?.type === 'signal') {
          // Navigate to alerts screen
          router.push('/alerts');
        }
        // Clear badge when user interacts
        clearBadge();
      }
    );

    return cleanup;
  }, [router]);

  // Periodic background refresh for live games
  // All users: refresh every 10 seconds when live games exist and alerts are enabled
  useEffect(() => {
    // Clear any existing interval
    if (refreshIntervalRef.current) {
      clearInterval(refreshIntervalRef.current);
      refreshIntervalRef.current = null;
    }

    // Only poll if there are live games and alerts are enabled
    if (!hasLiveGames || !alertsEnabled) {
      return;
    }

    console.log('[Live Refresh] Starting periodic refresh (every 10s)');

    // Set up interval for periodic refresh
    refreshIntervalRef.current = setInterval(() => {
      // Only refresh if app is active or in background (not inactive during transition)
      if (appStateRef.current !== 'inactive') {
        console.log('[Live Refresh] Fetching latest game data...');
        fetchRealGames();
      }
    }, 10000); // 10 seconds

    return () => {
      if (refreshIntervalRef.current) {
        clearInterval(refreshIntervalRef.current);
        refreshIntervalRef.current = null;
      }
    };
  }, [alertsEnabled, hasLiveGames, fetchRealGames]);

  // Handle app state changes (foreground/background)
  useEffect(() => {
    const subscription = AppState.addEventListener('change', (nextAppState: AppStateStatus) => {
      // When app comes to foreground, refresh immediately if there are live games
      if (
        appStateRef.current.match(/inactive|background/) &&
        nextAppState === 'active' &&
        hasLiveGames
      ) {
        console.log('[App State] App came to foreground, refreshing live games...');
        fetchRealGames();
      }
      appStateRef.current = nextAppState;
    });

    return () => {
      subscription.remove();
    };
  }, [hasLiveGames, fetchRealGames]);

  // Monitor for new pending alerts and send notifications
  useEffect(() => {
    if (!alertsEnabled || !hasProAccess) return;

    // Get all pending alerts from live games
    const pendingAlerts: { alert: Alert; game: typeof games[0] }[] = [];
    for (const game of games) {
      if (game.status === 'live') {
        for (const alert of game.alerts) {
          if (alert.outcome === 'pending') {
            pendingAlerts.push({ alert, game });
          }
        }
      }
    }

    // Filter based on signal type preference
    const filteredAlerts = pendingAlerts.filter(({ alert }) => {
      if (signalTypePreference === 'high_conviction_only') {
        return alert.isHighConviction;
      }
      if (signalTypePreference === 'standard_only') {
        return !alert.isHighConviction;
      }
      return true; // 'all'
    });

    // Send notifications for new alerts
    for (const { alert, game } of filteredAlerts) {
      if (!notifiedAlertsRef.current.has(alert.id)) {
        notifiedAlertsRef.current.add(alert.id);

        sendSignalNotification(alert, {
          homeTeam: game.homeTeam.abbreviation,
          awayTeam: game.awayTeam.abbreviation,
          quarter: game.quarter,
          time: game.quarterTime,
        });
      }
    }
  }, [games, alertsEnabled, hasProAccess, signalTypePreference]);
}

export default function RootLayout() {
  // Initialize notification manager
  useNotificationManager();

  return (
    <QueryClientProvider client={queryClient}>
      <GestureHandlerRootView style={{ flex: 1 }}>
        <KeyboardProvider>
          <StatusBar style="light" />
          <RootLayoutNav />
        </KeyboardProvider>
      </GestureHandlerRootView>
    </QueryClientProvider>
  );
}
