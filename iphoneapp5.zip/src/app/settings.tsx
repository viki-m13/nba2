// Settings Screen
import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable, Switch, Alert, Linking, Platform } from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Animated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import {
  X,
  Settings,
  Bell,
  Info,
  ChevronRight,
  BarChart3,
  Crown,
  Check,
  Zap,
  ExternalLink,
  FlaskConical,
} from 'lucide-react-native';

import {
  useDiffFirstStore,
  useAlertsEnabled,
  useHasProAccess,
} from '@/lib/store';
import {
  requestNotificationPermissions,
} from '@/lib/notifications';

export default function SettingsScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [isRequestingPermission, setIsRequestingPermission] = useState(false);

  const alertsEnabled = useAlertsEnabled();
  const hasProAccess = useHasProAccess();

  const toggleAlerts = useDiffFirstStore((s) => s.toggleAlerts);

  const handleToggleAlerts = async () => {
    if (!alertsEnabled) {
      // User is trying to enable alerts - check for pro access first
      if (!hasProAccess) {
        // Non-pro users should see the paywall
        router.push('/paywall');
        return;
      }

      // Pro user - request permissions
      setIsRequestingPermission(true);
      const granted = await requestNotificationPermissions();
      setIsRequestingPermission(false);

      if (granted) {
        toggleAlerts();
      } else {
        // Permissions denied - show alert with option to open settings
        Alert.alert(
          'Notifications Disabled',
          'To receive signal alerts, please enable notifications in your device settings.',
          [
            { text: 'Cancel', style: 'cancel' },
            {
              text: 'Open Settings',
              onPress: () => {
                if (Platform.OS === 'ios') {
                  Linking.openURL('app-settings:');
                } else {
                  Linking.openSettings();
                }
              },
            },
          ]
        );
      }
    } else {
      // User is disabling - just toggle
      toggleAlerts();
    }
  };

  return (
    <View className="flex-1 bg-[#0A0A0F]">
      {/* Header */}
      <View
        style={{ paddingTop: insets.top }}
        className="px-5 pb-4 border-b border-gray-800"
      >
        <Animated.View
          entering={FadeIn.duration(300)}
          className="flex-row items-center justify-between"
        >
          <View className="flex-row items-center">
            <Settings size={24} color="#6B7280" />
            <Text className="text-white text-xl font-bold ml-2">Settings</Text>
          </View>
          <Pressable
            onPress={() => router.back()}
            className="p-2 rounded-full bg-gray-800 active:opacity-70"
          >
            <X size={20} color="#9CA3AF" />
          </Pressable>
        </Animated.View>
      </View>

      <ScrollView
        className="flex-1"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
      >
        {/* Subscription Section - First */}
        <Animated.View entering={FadeInDown.delay(100).springify()}>
          <Text className="text-gray-500 text-xs font-semibold uppercase tracking-wider px-5 pt-6 pb-2">
            Pro Access
          </Text>
          <View className="bg-[#12121A] mx-5 rounded-xl border border-gray-800 overflow-hidden">
            {hasProAccess ? (
              <>
                <View className="flex-row items-center justify-between p-4 border-b border-gray-800/50">
                  <View className="flex-row items-center flex-1">
                    <View className="bg-emerald-500/20 rounded-lg p-2 mr-3">
                      <Crown size={18} color="#10B981" />
                    </View>
                    <View className="flex-1">
                      <Text className="text-white font-semibold">Pro Active</Text>
                      <Text className="text-gray-500 text-xs">
                        Full access to all signal alerts
                      </Text>
                    </View>
                  </View>
                  <Check size={20} color="#10B981" />
                </View>
                <Pressable
                  onPress={() => router.push('/paywall')}
                  className="flex-row items-center justify-between p-4 border-b border-gray-800/50 active:bg-gray-800/30"
                >
                  <View className="flex-row items-center flex-1">
                    <View className="bg-gray-700/50 rounded-lg p-2 mr-3">
                      <Zap size={18} color="#9CA3AF" />
                    </View>
                    <View className="flex-1">
                      <Text className="text-white font-semibold">Change Plan</Text>
                      <Text className="text-gray-500 text-xs">
                        View available subscription options
                      </Text>
                    </View>
                  </View>
                  <ChevronRight size={18} color="#4B5563" />
                </Pressable>
                <Pressable
                  onPress={() => {
                    // Opens Apple's subscription management page directly
                    Linking.openURL('https://apps.apple.com/account/subscriptions');
                  }}
                  className="flex-row items-center justify-between p-4 active:bg-gray-800/30"
                >
                  <View className="flex-row items-center flex-1">
                    <View className="bg-gray-700/50 rounded-lg p-2 mr-3">
                      <ExternalLink size={18} color="#9CA3AF" />
                    </View>
                    <View className="flex-1">
                      <Text className="text-white font-semibold">Manage Subscription</Text>
                      <Text className="text-gray-500 text-xs">
                        Change or cancel in App Store
                      </Text>
                    </View>
                  </View>
                  <ChevronRight size={18} color="#4B5563" />
                </Pressable>
              </>
            ) : (
              <Pressable
                onPress={() => router.push('/paywall')}
                className="flex-row items-center justify-between p-4 active:bg-gray-800/30"
              >
                <View className="flex-row items-center flex-1">
                  <View className="bg-emerald-500/20 rounded-lg p-2 mr-3">
                    <Zap size={18} color="#10B981" />
                  </View>
                  <View className="flex-1">
                    <Text className="text-white font-semibold">Unlock Pro Signals</Text>
                    <Text className="text-gray-500 text-xs">
                      Get high-probability signal alerts
                    </Text>
                  </View>
                </View>
                <ChevronRight size={18} color="#10B981" />
              </Pressable>
            )}
          </View>
        </Animated.View>

        {/* Signal Notifications - Only show for Pro users */}
        {hasProAccess && (
          <Animated.View entering={FadeInDown.delay(150).springify()}>
            <Text className="text-gray-500 text-xs font-semibold uppercase tracking-wider px-5 pt-6 pb-2">
              Notifications
            </Text>
            <View className="bg-[#12121A] mx-5 rounded-xl border border-gray-800 overflow-hidden">
              <View className="flex-row items-center justify-between p-4">
                <View className="flex-row items-center flex-1 mr-4">
                  <View className="bg-emerald-500/20 rounded-lg p-2 mr-3">
                    <Bell size={18} color="#10B981" />
                  </View>
                  <View className="flex-1">
                    <Text className="text-white font-semibold">
                      Signal Alerts
                    </Text>
                    <Text className="text-gray-500 text-xs">
                      Push notifications when signals fire
                    </Text>
                  </View>
                </View>
                <Switch
                  value={alertsEnabled}
                  onValueChange={handleToggleAlerts}
                  trackColor={{ false: '#374151', true: '#10B98160' }}
                  thumbColor={alertsEnabled ? '#10B981' : '#6B7280'}
                  disabled={isRequestingPermission}
                />
              </View>
            </View>
          </Animated.View>
        )}

        {/* About Section */}
        <Animated.View entering={FadeInDown.delay(175).springify()}>
          <Text className="text-gray-500 text-xs font-semibold uppercase tracking-wider px-5 pt-6 pb-2">
            About
          </Text>
          <View className="bg-[#12121A] mx-5 rounded-xl border border-gray-800 overflow-hidden">
            <View className="flex-row items-center justify-between p-4 border-b border-gray-800/50">
              <View className="flex-row items-center">
                <View className="bg-emerald-500/20 rounded-lg p-2 mr-3">
                  <BarChart3 size={18} color="#10B981" />
                </View>
                <View>
                  <Text className="text-white font-semibold">CourtQuant</Text>
                  <Text className="text-gray-500 text-xs">Version 1.0.0</Text>
                </View>
              </View>
            </View>
            <Pressable
              onPress={() => router.push('/how-it-works')}
              className="flex-row items-center justify-between p-4 active:bg-gray-800/30 border-b border-gray-800/50"
            >
              <View className="flex-row items-center">
                <View className="bg-blue-500/20 rounded-lg p-2 mr-3">
                  <Info size={18} color="#3B82F6" />
                </View>
                <Text className="text-white">How It Works</Text>
              </View>
              <ChevronRight size={18} color="#4B5563" />
            </Pressable>
            <Pressable
              onPress={() => router.push('/backtest')}
              className="flex-row items-center justify-between p-4 active:bg-gray-800/30"
            >
              <View className="flex-row items-center">
                <View className="bg-purple-500/20 rounded-lg p-2 mr-3">
                  <FlaskConical size={18} color="#A855F7" />
                </View>
                <View>
                  <Text className="text-white">Signal Backtest</Text>
                  <Text className="text-gray-500 text-xs">Test strategy accuracy</Text>
                </View>
              </View>
              <ChevronRight size={18} color="#4B5563" />
            </Pressable>
          </View>
        </Animated.View>

        {/* Legal Section */}
        <Animated.View entering={FadeInDown.delay(200).springify()}>
          <Text className="text-gray-500 text-xs font-semibold uppercase tracking-wider px-5 pt-6 pb-2">
            Legal
          </Text>
          <View className="bg-[#12121A] mx-5 rounded-xl border border-gray-800 overflow-hidden">
            <Pressable
              onPress={() => Linking.openURL('https://viki-m13.github.io/courtquant/privacy-policy.html')}
              className="flex-row items-center justify-between p-4 active:bg-gray-800/30 border-b border-gray-800/50"
            >
              <View className="flex-row items-center">
                <View className="bg-gray-700/50 rounded-lg p-2 mr-3">
                  <ExternalLink size={18} color="#9CA3AF" />
                </View>
                <Text className="text-white">Privacy Policy</Text>
              </View>
              <ChevronRight size={18} color="#4B5563" />
            </Pressable>
            <Pressable
              onPress={() => Linking.openURL('https://www.apple.com/legal/internet-services/itunes/dev/stdeula/')}
              className="flex-row items-center justify-between p-4 active:bg-gray-800/30"
            >
              <View className="flex-row items-center">
                <View className="bg-gray-700/50 rounded-lg p-2 mr-3">
                  <ExternalLink size={18} color="#9CA3AF" />
                </View>
                <Text className="text-white">Terms of Use (EULA)</Text>
              </View>
              <ChevronRight size={18} color="#4B5563" />
            </Pressable>
          </View>
        </Animated.View>

        {/* Disclaimer */}
        <Animated.View
          entering={FadeInDown.delay(225).springify()}
          className="px-5 pt-6"
        >
          <View className="bg-gray-800/30 rounded-xl p-4">
            <Text className="text-gray-500 text-xs leading-5">
              <Text className="text-gray-400 font-semibold">Disclaimer:</Text>{' '}
              Educational use only. CourtQuant provides statistical indicators and visualizations based on publicly available NBA game data. It does not place wagers or connect to sportsbooks. No outcomes are guaranteed. Past or simulated results do not predict future outcomes.
            </Text>
          </View>
        </Animated.View>
      </ScrollView>
    </View>
  );
}
