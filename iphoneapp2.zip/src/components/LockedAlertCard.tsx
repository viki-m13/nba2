// Locked Alert Card - Shows signal exists but hides the actionable details
// Psychologically compelling: users see WHAT they're missing in REAL-TIME
import React, { useEffect, useState } from 'react';
import { View, Text, Pressable } from 'react-native';
import Animated, {
  FadeInUp,
  useAnimatedStyle,
  withRepeat,
  withSequence,
  withTiming,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { Zap, Lock, Star, TrendingUp, Clock, Users } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';

import type { Alert } from '@/lib/types';

interface LockedAlertCardProps {
  alert: Alert;
  onUpgradePress: () => void;
  index?: number;
}

// Format time ago (e.g., "Just now", "2m ago", "15m ago")
function formatTimeAgo(timestamp: Date): string {
  const now = Date.now();
  const alertTime = new Date(timestamp).getTime();
  const diffMs = now - alertTime;
  const diffSeconds = Math.floor(diffMs / 1000);
  const diffMinutes = Math.floor(diffSeconds / 60);

  if (diffSeconds < 30) return 'Just now';
  if (diffSeconds < 60) return `${diffSeconds}s ago`;
  if (diffMinutes < 60) return `${diffMinutes}m ago`;
  return `${Math.floor(diffMinutes / 60)}h ago`;
}

export function LockedAlertCard({ alert, onUpgradePress, index = 0 }: LockedAlertCardProps) {
  const isHighConviction = alert.isHighConviction;
  const [timeAgo, setTimeAgo] = useState(formatTimeAgo(alert.timestamp));

  // Update time ago every 10 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setTimeAgo(formatTimeAgo(alert.timestamp));
    }, 10000);
    return () => clearInterval(interval);
  }, [alert.timestamp]);

  // Pulsing animation for urgency
  const pulseStyle = useAnimatedStyle(() => ({
    opacity: withRepeat(
      withSequence(
        withTiming(1, { duration: 800 }),
        withTiming(0.6, { duration: 800 })
      ),
      -1,
      true
    ),
  }));

  // Glow animation for the lock icon
  const glowScale = useSharedValue(1);
  useEffect(() => {
    glowScale.value = withRepeat(
      withSequence(
        withSpring(1.1, { damping: 3 }),
        withSpring(1, { damping: 3 })
      ),
      -1,
      true
    );
  }, []);

  const glowStyle = useAnimatedStyle(() => ({
    transform: [{ scale: glowScale.value }],
  }));

  const handlePress = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    onUpgradePress();
  };

  // Determine colors based on signal type
  const accentColor = '#10B981';
  const accentColorDim = '#10B98120';

  return (
    <Animated.View entering={FadeInUp.delay(index * 80).springify()}>
      <Pressable onPress={handlePress} className="active:opacity-90">
        <View className="overflow-hidden rounded-2xl">
          <LinearGradient
            colors={
              isHighConviction
                ? ['#F59E0B25', '#F59E0B10', '#0A0A0F']
                : [accentColorDim, '#12121A']
            }
            style={{
              padding: 16,
              borderRadius: 16,
              borderWidth: isHighConviction ? 2 : 1,
              borderColor: isHighConviction ? '#F59E0B60' : `${accentColor}40`,
            }}
          >
            {/* LIVE indicator + Time */}
            <View className="flex-row items-center justify-between mb-3">
              <Animated.View style={pulseStyle} className="flex-row items-center">
                <View className="w-2 h-2 rounded-full bg-red-500 mr-2" />
                <Text className="text-red-400 text-xs font-bold">LIVE SIGNAL</Text>
              </Animated.View>
              <View className="flex-row items-center bg-gray-800/60 px-2 py-1 rounded-full">
                <Clock size={10} color="#9CA3AF" />
                <Text className="text-gray-400 text-xs ml-1">{timeAgo}</Text>
              </View>
            </View>

            {/* High Conviction Badge */}
            {isHighConviction && (
              <View className="flex-row items-center justify-center rounded-lg py-1.5 mb-3 bg-amber-500/20">
                <Star size={14} color="#F59E0B" fill="#F59E0B" />
                <Text className="text-xs font-bold ml-1.5 uppercase tracking-wider text-amber-400">
                  HIGH CONVICTION SIGNAL
                </Text>
              </View>
            )}

            {/* Signal Type Badge */}
            <View className="flex-row items-center justify-center rounded-lg py-2 mb-3 bg-emerald-500/15">
              <TrendingUp size={16} color="#10B981" />
              <Text className="font-bold ml-2 text-emerald-400">
                SPREAD SIGNAL
              </Text>
            </View>

            {/* Visible Info - What they CAN see */}
            <View className="bg-gray-800/40 rounded-xl p-3 mb-3">
              <View className="flex-row justify-between items-center">
                <View>
                  <Text className="text-gray-500 text-xs mb-1">Confidence</Text>
                  <Text className={`text-lg font-bold ${alert.confidence === 'high' ? 'text-emerald-400' : 'text-amber-400'}`}>
                    {alert.confidence.toUpperCase()}
                  </Text>
                </View>
                <View className="items-center">
                  <Text className="text-gray-500 text-xs mb-1">Edge</Text>
                  <Text className="text-emerald-400 text-lg font-bold">+{alert.edge}%</Text>
                </View>
                <View className="items-end">
                  <Text className="text-gray-500 text-xs mb-1">Game Time</Text>
                  <Text className="text-white text-lg font-bold">{alert.gameTime}</Text>
                </View>
              </View>
            </View>

            {/* LOCKED Section - The crucial info they can't see */}
            <View className="relative">
              {/* Blurred/Hidden Content */}
              <View className="bg-gray-900/80 rounded-xl p-4 border border-gray-700/50">
                {/* Fake blurred text lines */}
                <View className="mb-2">
                  <View className="h-5 w-3/4 bg-gray-700/60 rounded mb-1.5" />
                  <View className="h-4 w-1/2 bg-gray-700/40 rounded" />
                </View>
                <View className="h-px bg-gray-700/30 my-2" />
                <View>
                  <View className="h-4 w-full bg-gray-700/40 rounded mb-1.5" />
                  <View className="h-4 w-2/3 bg-gray-700/40 rounded" />
                </View>
              </View>

              {/* Lock Overlay */}
              <View className="absolute inset-0 items-center justify-center">
                <Animated.View
                  style={glowStyle}
                  className="bg-gray-900/95 rounded-xl px-4 py-3 border border-emerald-500/40 flex-row items-center"
                >
                  <View className="bg-emerald-500/20 rounded-full p-2 mr-3">
                    <Lock size={18} color="#10B981" />
                  </View>
                  <View>
                    <Text className="text-white font-bold text-sm">Bet locked</Text>
                    <Text className="text-gray-400 text-xs">Tap to unlock</Text>
                  </View>
                </Animated.View>
              </View>
            </View>

            {/* Social Proof - Others are acting */}
            <View className="flex-row items-center justify-center mt-3 bg-emerald-500/10 rounded-lg py-2">
              <Users size={14} color="#10B981" />
              <Text className="text-emerald-400 text-xs font-medium ml-2">
                Pro members are betting on this now
              </Text>
            </View>

            {/* Urgency CTA */}
            <Pressable
              onPress={handlePress}
              className="mt-3 bg-emerald-500 rounded-xl py-3 items-center active:bg-emerald-600"
            >
              <Text className="text-white font-bold">Unlock This Signal</Text>
            </Pressable>
          </LinearGradient>
        </View>
      </Pressable>
    </Animated.View>
  );
}

// Compact locked card for lists
export function LockedAlertCardCompact({
  alert,
  onUpgradePress,
}: {
  alert: Alert;
  onUpgradePress: () => void;
}) {
  const isHighConviction = alert.isHighConviction;
  const [timeAgo, setTimeAgo] = useState(formatTimeAgo(alert.timestamp));

  useEffect(() => {
    const interval = setInterval(() => {
      setTimeAgo(formatTimeAgo(alert.timestamp));
    }, 10000);
    return () => clearInterval(interval);
  }, [alert.timestamp]);

  const pulseStyle = useAnimatedStyle(() => ({
    opacity: withRepeat(
      withSequence(
        withTiming(1, { duration: 800 }),
        withTiming(0.6, { duration: 800 })
      ),
      -1,
      true
    ),
  }));

  return (
    <Pressable
      onPress={() => {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        onUpgradePress();
      }}
      className="active:opacity-80"
    >
      <View
        className={`rounded-xl p-3 border ${
          isHighConviction
            ? 'bg-amber-500/10 border-amber-500/40'
            : 'bg-emerald-500/10 border-emerald-500/30'
        }`}
      >
        {/* Top row: Live indicator + High Conviction badge */}
        <View className="flex-row items-center justify-between mb-2">
          <Animated.View style={pulseStyle} className="flex-row items-center">
            <View className="w-1.5 h-1.5 rounded-full bg-red-500 mr-1.5" />
            <Text className="text-red-400 text-xs font-semibold">LIVE</Text>
            <Text className="text-gray-500 text-xs ml-2">{timeAgo}</Text>
          </Animated.View>
          {isHighConviction && (
            <View className="flex-row items-center bg-amber-500/20 px-2 py-0.5 rounded-full">
              <Star size={10} color="#F59E0B" fill="#F59E0B" />
              <Text className="text-amber-400 text-xs font-bold ml-1">HC</Text>
            </View>
          )}
        </View>

        {/* Signal type + locked bet */}
        <View className="flex-row items-center justify-between">
          <View className="flex-row items-center">
            <View className="rounded-full p-1.5 mr-2 bg-emerald-500/20">
              <TrendingUp size={14} color="#10B981" />
            </View>
            <View>
              <Text className="font-bold text-sm text-emerald-400">
                Spread Signal
              </Text>
              <Text className="text-gray-500 text-xs">
                {alert.confidence.toUpperCase()} • +{alert.edge}% edge
              </Text>
            </View>
          </View>

          {/* Locked indicator */}
          <View className="flex-row items-center bg-gray-800/80 px-2.5 py-1.5 rounded-lg border border-emerald-500/30">
            <Lock size={12} color="#10B981" />
            <Text className="text-emerald-400 text-xs font-semibold ml-1">Unlock</Text>
          </View>
        </View>
      </View>
    </Pressable>
  );
}
