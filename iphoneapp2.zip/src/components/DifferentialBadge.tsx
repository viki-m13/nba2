// Differential Badge - shows the lead/deficit prominently
import React from 'react';
import { View, Text } from 'react-native';
import Animated, {
  useAnimatedStyle,
  withSpring,
  withSequence,
  withTiming,
} from 'react-native-reanimated';
import { cn } from '@/lib/cn';

interface DifferentialBadgeProps {
  differential: number;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showSign?: boolean;
  animated?: boolean;
}

export function DifferentialBadge({
  differential,
  size = 'md',
  showSign = true,
  animated = true,
}: DifferentialBadgeProps) {
  const isPositive = differential > 0;
  const isNegative = differential < 0;
  const isTied = differential === 0;

  const displayValue = Math.abs(differential);
  const sign = isPositive ? '+' : isNegative ? '-' : '';

  const animatedStyle = useAnimatedStyle(() => {
    if (!animated) return {};
    return {
      transform: [
        {
          scale: withSequence(
            withTiming(1.05, { duration: 100 }),
            withSpring(1, { damping: 10 })
          ),
        },
      ],
    };
  }, [differential]);

  const sizeStyles = {
    sm: 'text-lg',
    md: 'text-2xl',
    lg: 'text-4xl',
    xl: 'text-6xl',
  };

  const colorStyles = isTied
    ? 'text-gray-400'
    : isPositive
    ? 'text-emerald-400'
    : 'text-red-400';

  return (
    <Animated.View style={animatedStyle}>
      <View className="flex-row items-baseline">
        {showSign && (
          <Text
            className={cn(
              'font-bold',
              size === 'sm' ? 'text-sm' : size === 'md' ? 'text-base' : size === 'lg' ? 'text-2xl' : 'text-4xl',
              colorStyles
            )}
          >
            {sign}
          </Text>
        )}
        <Text
          className={cn(
            'font-black tracking-tighter',
            sizeStyles[size],
            colorStyles
          )}
        >
          {displayValue}
        </Text>
      </View>
    </Animated.View>
  );
}

// Compact inline differential for secondary displays
export function InlineDifferential({
  differential,
  className,
}: {
  differential: number;
  className?: string;
}) {
  const isPositive = differential > 0;
  const isTied = differential === 0;
  const sign = isPositive ? '+' : '';

  return (
    <Text
      className={cn(
        'font-semibold',
        isTied
          ? 'text-gray-500'
          : isPositive
          ? 'text-emerald-400'
          : 'text-red-400',
        className
      )}
    >
      {sign}
      {differential}
    </Text>
  );
}
