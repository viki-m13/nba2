// Sparkline component for differential history
import React from 'react';
import { View } from 'react-native';
import Svg, { Path, Circle } from 'react-native-svg';

interface SparklineProps {
  data: number[];
  width?: number;
  height?: number;
  strokeColor?: string;
  positiveColor?: string;
  negativeColor?: string;
}

export function Sparkline({
  data,
  width = 80,
  height = 24,
  strokeColor,
  positiveColor = '#10B981',
  negativeColor = '#EF4444',
}: SparklineProps) {
  if (data.length < 2) {
    return <View style={{ width, height }} />;
  }

  const padding = 2;
  const chartWidth = width - padding * 2;
  const chartHeight = height - padding * 2;

  // Calculate bounds
  const min = Math.min(...data, 0);
  const max = Math.max(...data, 0);
  const range = max - min || 1;

  // Generate path
  const points = data.map((value, index) => {
    const x = padding + (index / (data.length - 1)) * chartWidth;
    const y = padding + chartHeight - ((value - min) / range) * chartHeight;
    return { x, y };
  });

  const pathData = points
    .map((point, index) => `${index === 0 ? 'M' : 'L'} ${point.x} ${point.y}`)
    .join(' ');

  // Determine color based on trend
  const lastValue = data[data.length - 1];
  const firstValue = data[0];
  const color = strokeColor || (lastValue >= firstValue ? positiveColor : negativeColor);

  // Last point position
  const lastPoint = points[points.length - 1];

  return (
    <View style={{ width, height }}>
      <Svg width={width} height={height}>
        <Path
          d={pathData}
          fill="none"
          stroke={color}
          strokeWidth={1.5}
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <Circle
          cx={lastPoint.x}
          cy={lastPoint.y}
          r={2.5}
          fill={color}
        />
      </Svg>
    </View>
  );
}
