// Analytics Panel - Shows key metrics for the 4 reduced spread strategies
import React from 'react';
import { View, Text } from 'react-native';
import Animated, { FadeInUp } from 'react-native-reanimated';
import { TrendingUp, Target, TrendingDown, ArrowUpDown } from 'lucide-react-native';

import type { GameAnalytics } from '@/lib/types';

interface AnalyticsPanelProps {
  analytics: GameAnalytics;
  currentDifferential: number;
}

export function AnalyticsPanel({ analytics, currentDifferential }: AnalyticsPanelProps) {
  const leadSize = Math.abs(currentDifferential);
  const momentum = Math.abs(analytics.momentumSwing || 0);

  // Support/Resistance metrics
  const supportLevels = analytics.supportLevels || [];
  const resistanceLevels = analytics.resistanceLevels || [];

  // Find the most relevant support and resistance levels
  // Support: show closest level below current (where price bounced up from)
  // Resistance: show closest level to current (where price hit a ceiling) - could be above OR below if we broke through
  const closestSupport = supportLevels.find(s => s.level < currentDifferential);

  // For resistance: first try to find one above current (active resistance)
  // If none above, show the closest one below (broken resistance we pushed through)
  let closestResistance = resistanceLevels.find(r => r.level > currentDifferential);
  if (!closestResistance && resistanceLevels.length > 0) {
    // We're above all resistance levels - show the highest resistance (most recently broken)
    const resistanceBelowCurrent = resistanceLevels.filter(r => r.level <= currentDifferential);
    if (resistanceBelowCurrent.length > 0) {
      // Sort by level descending to get the highest (closest to current)
      closestResistance = resistanceBelowCurrent.sort((a, b) => b.level - a.level)[0];
    }
  }

  // Distance to closest levels
  const distanceToSupport = closestSupport ? Math.abs(currentDifferential - closestSupport.level) : null;
  const distanceToResistance = closestResistance ? Math.abs(closestResistance.level - currentDifferential) : null;

  // Check if we've broken through resistance (current is above the resistance level)
  const resistanceBroken = closestResistance && currentDifferential > closestResistance.level;

  // Determine which strategy thresholds are met (12-24 min time window assumed)
  // STRATEGY 1: SWEET SPOT (84.6%/90.2% WR) - Lead 10-14, Mom 10+, Spread -7 + ML
  const meetsSweetSpot = leadSize >= 10 && leadSize <= 14 && momentum >= 10;
  // STRATEGY 2: MODERATE (84.4%/90.9% WR) - Lead 12-16, Mom 12+, Spread -7 + ML
  const meetsModerate = leadSize >= 12 && leadSize <= 16 && momentum >= 12;
  // STRATEGY 3: MID-RANGE (94.4%/100% WR) - Lead 14-18, Mom 14+, Spread -7 + ML
  const meetsMidRange = leadSize >= 14 && leadSize <= 18 && momentum >= 14;
  // STRATEGY 4: SAFE (96.0%/96.3% WR) - Lead 16-20, Mom 12+, Spread -5 + ML
  const meetsSafe = leadSize >= 16 && leadSize <= 20 && momentum >= 12;

  return (
    <Animated.View
      entering={FadeInUp.delay(200).springify()}
      className="bg-[#12121A] rounded-2xl p-4 border border-gray-800"
    >
      {/* Key Metrics */}
      <View className="flex-row justify-around mb-4">
        {/* Lead Size */}
        <View className="items-center flex-1">
          <View className="flex-row items-center mb-1">
            <Target size={14} color="#6B7280" />
            <Text className="text-gray-400 text-xs ml-1">Lead</Text>
          </View>
          <Text className={`text-2xl font-bold ${leadSize >= 10 ? 'text-emerald-400' : 'text-gray-300'}`}>
            {leadSize}
          </Text>
          <Text className="text-gray-500 text-[10px]">pts</Text>
        </View>

        <View className="w-px bg-gray-800" />

        {/* Momentum */}
        <View className="items-center flex-1">
          <View className="flex-row items-center mb-1">
            <TrendingUp size={14} color="#6B7280" />
            <Text className="text-gray-400 text-xs ml-1">Momentum</Text>
          </View>
          <Text className={`text-2xl font-bold ${momentum >= 10 ? 'text-emerald-400' : 'text-gray-300'}`}>
            +{momentum}
          </Text>
          <Text className="text-gray-500 text-[10px]">pts</Text>
        </View>
      </View>

      {/* Support/Resistance Metrics */}
      {(supportLevels.length > 0 || resistanceLevels.length > 0) && (
        <View className="border-t border-gray-800 pt-3 mb-3">
          <View className="flex-row items-center mb-2">
            <ArrowUpDown size={12} color="#6B7280" />
            <Text className="text-gray-500 text-[10px] uppercase tracking-wider ml-1">Support & Resistance</Text>
          </View>

          <View className="flex-row justify-around">
            {/* Support Info */}
            <View className="items-center flex-1">
              <View className="flex-row items-center mb-1">
                <TrendingDown size={12} color="#10B981" />
                <Text className="text-emerald-400 text-[10px] ml-1">Support</Text>
              </View>
              {closestSupport ? (
                <>
                  <Text className="text-emerald-400 font-bold text-base">
                    {closestSupport.level > 0 ? '+' : ''}{closestSupport.level}
                  </Text>
                  <View className="flex-row items-center mt-0.5">
                    <View className={`w-1.5 h-1.5 rounded-full mr-1 ${
                      closestSupport.strength === 'strong' ? 'bg-emerald-400' :
                      closestSupport.strength === 'moderate' ? 'bg-emerald-400/60' :
                      'bg-emerald-400/30'
                    }`} />
                    <Text className="text-gray-500 text-[9px]">
                      {closestSupport.touches} touches • {closestSupport.strength}
                    </Text>
                  </View>
                  {distanceToSupport !== null && (
                    <Text className="text-gray-600 text-[9px] mt-0.5">
                      {distanceToSupport} pts away
                    </Text>
                  )}
                </>
              ) : (
                <Text className="text-gray-600 text-xs">None</Text>
              )}
            </View>

            <View className="w-px bg-gray-800" />

            {/* Resistance Info */}
            <View className="items-center flex-1">
              <View className="flex-row items-center mb-1">
                <TrendingUp size={12} color="#EF4444" />
                <Text className="text-red-400 text-[10px] ml-1">Resistance</Text>
              </View>
              {closestResistance ? (
                <>
                  <Text className="text-red-400 font-bold text-base">
                    {closestResistance.level > 0 ? '+' : ''}{closestResistance.level}
                  </Text>
                  <View className="flex-row items-center mt-0.5">
                    <View className={`w-1.5 h-1.5 rounded-full mr-1 ${
                      closestResistance.strength === 'strong' ? 'bg-red-400' :
                      closestResistance.strength === 'moderate' ? 'bg-red-400/60' :
                      'bg-red-400/30'
                    }`} />
                    <Text className="text-gray-500 text-[9px]">
                      {closestResistance.touches} touches • {closestResistance.strength}
                    </Text>
                  </View>
                  {distanceToResistance !== null && (
                    <Text className={`text-[9px] mt-0.5 ${resistanceBroken ? 'text-emerald-500' : 'text-gray-600'}`}>
                      {resistanceBroken ? `Broken (+${distanceToResistance} above)` : `${distanceToResistance} pts away`}
                    </Text>
                  )}
                </>
              ) : (
                <Text className="text-gray-600 text-xs">None</Text>
              )}
            </View>
          </View>

          {/* Total levels count */}
          <View className="flex-row justify-center mt-2">
            <Text className="text-gray-600 text-[9px]">
              {supportLevels.length} support level{supportLevels.length !== 1 ? 's' : ''} • {resistanceLevels.length} resistance level{resistanceLevels.length !== 1 ? 's' : ''}
            </Text>
          </View>
        </View>
      )}

      {/* Strategy Status */}
      <View className="border-t border-gray-800 pt-3">
        <Text className="text-gray-500 text-[10px] uppercase tracking-wider mb-2">Strategy Thresholds (12-24 min)</Text>

        <View className="flex-row flex-wrap">
          {/* Sweet Spot */}
          <View className={`px-2 py-1 rounded-full mr-2 mb-1 ${meetsSweetSpot ? 'bg-emerald-500/20' : 'bg-gray-800/50'}`}>
            <Text className={`text-[10px] font-semibold ${meetsSweetSpot ? 'text-emerald-400' : 'text-gray-500'}`}>
              Sweet: 10-14, M10+
            </Text>
          </View>

          {/* Moderate */}
          <View className={`px-2 py-1 rounded-full mr-2 mb-1 ${meetsModerate ? 'bg-blue-500/20' : 'bg-gray-800/50'}`}>
            <Text className={`text-[10px] font-semibold ${meetsModerate ? 'text-blue-400' : 'text-gray-500'}`}>
              Mod: 12-16, M12+
            </Text>
          </View>

          {/* Mid-Range */}
          <View className={`px-2 py-1 rounded-full mr-2 mb-1 ${meetsMidRange ? 'bg-purple-500/20' : 'bg-gray-800/50'}`}>
            <Text className={`text-[10px] font-semibold ${meetsMidRange ? 'text-purple-400' : 'text-gray-500'}`}>
              Mid: 14-18, M14+
            </Text>
          </View>

          {/* Safe */}
          <View className={`px-2 py-1 rounded-full mb-1 ${meetsSafe ? 'bg-amber-500/20' : 'bg-gray-800/50'}`}>
            <Text className={`text-[10px] font-semibold ${meetsSafe ? 'text-amber-400' : 'text-gray-500'}`}>
              Safe: 16-20, M12+
            </Text>
          </View>
        </View>
      </View>
    </Animated.View>
  );
}
