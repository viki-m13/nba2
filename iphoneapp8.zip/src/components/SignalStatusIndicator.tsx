// Signal Status Indicator - shows if game conditions meet strategy thresholds
import React from 'react';
import { View, Text } from 'react-native';
import { Target, Clock, Eye, Zap } from 'lucide-react-native';
import { cn } from '@/lib/cn';

interface SignalStatusIndicatorProps {
  leadSize: number; // Absolute value of differential
  momentum: number; // Absolute value of momentum swing
  showLabel?: boolean;
  size?: 'sm' | 'md';
}

type SignalStatus = 'signal_zone' | 'approaching' | 'monitoring' | 'no_edge';

export function SignalStatusIndicator({
  leadSize,
  momentum,
  showLabel = true,
  size = 'sm',
}: SignalStatusIndicatorProps) {
  // Determine status based on momentum-tiered strategy thresholds:
  // All strategies: Lead 10+, -5 spread - differentiated by MOMENTUM only
  // ELITE: Lead 10+, Mom 14+
  // STRONG: Lead 10+, Mom 12+
  // STANDARD: Lead 10+, Mom 10+
  // WIDE: Lead 10+, Mom 8+

  const meetsElite = leadSize >= 10 && momentum >= 14;
  const meetsStrong = leadSize >= 10 && momentum >= 12;
  const meetsStandard = leadSize >= 10 && momentum >= 10;
  const meetsWide = leadSize >= 10 && momentum >= 8;

  const meetsAnyStrategy = meetsElite || meetsStrong || meetsStandard || meetsWide;

  // Approaching = close to meeting a strategy (lead 7-9 with decent momentum, or lead 10+ with building momentum)
  const isApproaching = !meetsAnyStrategy && (
    (leadSize >= 7 && leadSize < 10 && momentum >= 6) || // Building lead
    (leadSize >= 10 && momentum >= 6 && momentum < 10) // Has lead, momentum building
  );

  // No edge = game is too close or momentum is against the lead
  const hasNoEdge = leadSize < 5 || (leadSize >= 5 && momentum < 3);

  let status: SignalStatus;
  if (meetsAnyStrategy) {
    status = 'signal_zone';
  } else if (isApproaching) {
    status = 'approaching';
  } else if (hasNoEdge) {
    status = 'no_edge';
  } else {
    status = 'monitoring';
  }

  const config: Record<SignalStatus, { icon: typeof Target; label: string; color: string; bgColor: string }> = {
    signal_zone: {
      icon: Zap,
      label: 'Signal Zone',
      color: '#10B981',
      bgColor: 'bg-emerald-500/10',
    },
    approaching: {
      icon: Target,
      label: 'Approaching',
      color: '#3B82F6',
      bgColor: 'bg-blue-500/10',
    },
    monitoring: {
      icon: Eye,
      label: 'Monitoring',
      color: '#F59E0B',
      bgColor: 'bg-amber-500/10',
    },
    no_edge: {
      icon: Clock,
      label: 'No Edge',
      color: '#6B7280',
      bgColor: 'bg-gray-500/10',
    },
  };

  const { icon: Icon, label, color, bgColor } = config[status];
  const iconSize = size === 'sm' ? 12 : 16;

  return (
    <View className={cn('flex-row items-center rounded-full px-2 py-0.5', bgColor)}>
      <Icon size={iconSize} color={color} />
      {showLabel && (
        <Text
          className={cn(
            'ml-1 font-medium',
            size === 'sm' ? 'text-xs' : 'text-sm'
          )}
          style={{ color }}
        >
          {label}
        </Text>
      )}
    </View>
  );
}
