// CourtQuant Home Screen - Technical Analysis for NBA Betting
import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, ScrollView, Pressable, RefreshControl, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { FadeInDown, FadeInUp, useAnimatedStyle, withRepeat, withSequence, withTiming } from 'react-native-reanimated';
import { Bell, Settings, TrendingUp, Zap, Lock } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';

import { useGames, useActiveAlerts, useDiffFirstStore, useHasProAccess, useIsLoadingGames, useFetchRealGames } from '@/lib/store';
import { GameTile } from '@/components/GameTile';
import { hasEntitlement } from '@/lib/revenuecatClient';

export default function HomeScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const games = useGames();
  const activeAlerts = useActiveAlerts();
  const hasProAccess = useHasProAccess();
  const isLoadingGames = useIsLoadingGames();
  const fetchRealGames = useFetchRealGames();
  const setProAccess = useDiffFirstStore((s) => s.setProAccess);

  const [refreshing, setRefreshing] = useState(false);

  // Fetch real games and check subscription on mount
  useEffect(() => {
    fetchRealGames();

    // Sync subscription status with RevenueCat
    const checkSubscription = async () => {
      const result = await hasEntitlement('pro_alerts');
      if (result.ok) {
        setProAccess(result.data);
      }
    };
    checkSubscription();
  }, [fetchRealGames, setProAccess]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await fetchRealGames();
    setRefreshing(false);
  }, [fetchRealGames]);

  const liveGames = games.filter((g) => g.status === 'live' || g.status === 'halftime');
  const upcomingGames = games.filter((g) => g.status === 'scheduled');
  const finishedGames = games.filter((g) => g.status === 'final');

  // Delayed mode for non-pro users, live for pro users
  const isDelayedMode = !hasProAccess;

  // Show live/halftime first, then upcoming, then finished
  const hasLiveOrUpcoming = liveGames.length > 0 || upcomingGames.length > 0;

  // Pulsing animation for locked signals
  const pulseStyle = useAnimatedStyle(() => ({
    opacity: withRepeat(
      withSequence(
        withTiming(1, { duration: 800 }),
        withTiming(0.6, { duration: 800 })
      ),
      -1,
      true
    ),
  }));

  return (
    <View className="flex-1 bg-[#0A0A0F]">
      {/* Header */}
      <LinearGradient
        colors={['#0A0A0F', '#0A0A0F00']}
        style={{
          paddingTop: insets.top,
          paddingHorizontal: 20,
          paddingBottom: 16,
        }}
      >
        <Animated.View
          entering={FadeInDown.delay(100).springify()}
          className="flex-row items-center justify-between"
        >
          <View>
            <Text className="text-white text-2xl font-black tracking-tight">
              CourtQuant
            </Text>
            <Text className="text-gray-500 text-sm">
              Technical Analysis for NBA
            </Text>
          </View>

          <View className="flex-row items-center">
            {/* Alerts Button */}
            <Pressable
              onPress={() => router.push('/alerts')}
              className="relative mr-3 p-2 rounded-full bg-gray-800/50 active:opacity-70"
            >
              <Bell size={22} color="#9CA3AF" />
              {activeAlerts.length > 0 && (
                <View className="absolute -top-1 -right-1 bg-emerald-500 rounded-full w-5 h-5 items-center justify-center">
                  <Text className="text-white text-xs font-bold">
                    {activeAlerts.length}
                  </Text>
                </View>
              )}
            </Pressable>

            {/* Settings Button */}
            <Pressable
              onPress={() => router.push('/settings')}
              className="p-2 rounded-full bg-gray-800/50 active:opacity-70"
            >
              <Settings size={22} color="#9CA3AF" />
            </Pressable>
          </View>
        </Animated.View>

        {/* Quick Stats - Pro Alerts (for pro users) */}
        {activeAlerts.length > 0 && hasProAccess && (
          <Animated.View
            entering={FadeInUp.delay(200).springify()}
            className="mt-4"
          >
            <Pressable
              onPress={() => router.push('/alerts')}
              className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-3 flex-row items-center active:opacity-70"
            >
              <View className="bg-emerald-500/20 rounded-full p-2 mr-3">
                <Zap size={18} color="#10B981" />
              </View>
              <View className="flex-1">
                <Text className="text-emerald-400 font-semibold">
                  {activeAlerts.length} High-Probability Signal{activeAlerts.length > 1 ? 's' : ''}
                </Text>
                <Text className="text-gray-400 text-xs">
                  Tap to view technical analysis
                </Text>
              </View>
              <TrendingUp size={18} color="#10B981" />
            </Pressable>
          </Animated.View>
        )}

        {/* LOCKED SIGNALS BANNER - For non-pro users when signals are firing */}
        {activeAlerts.length > 0 && !hasProAccess && (
          <Animated.View
            entering={FadeInUp.delay(200).springify()}
            className="mt-4"
          >
            <Pressable
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                router.push('/paywall');
              }}
              className="overflow-hidden rounded-xl active:opacity-90"
            >
              <LinearGradient
                colors={['#10B98120', '#F59E0B15', '#10B98110']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={{
                  padding: 14,
                  borderRadius: 12,
                  borderWidth: 1,
                  borderColor: '#10B98140',
                }}
              >
                {/* Pulsing live indicator */}
                <View className="flex-row items-center justify-between mb-2">
                  <Animated.View style={pulseStyle} className="flex-row items-center">
                    <View className="w-2 h-2 rounded-full bg-red-500 mr-2" />
                    <Text className="text-red-400 text-xs font-bold">LIVE SIGNALS</Text>
                  </Animated.View>
                </View>

                <View className="flex-row items-center">
                  <View className="bg-emerald-500/20 rounded-full p-2 mr-3 shrink-0">
                    <Lock size={18} color="#10B981" />
                  </View>
                  <View className="flex-1 shrink mr-3">
                    <Text className="text-white font-bold" numberOfLines={1}>
                      {activeAlerts.length} Signal{activeAlerts.length > 1 ? 's' : ''} Firing Now
                    </Text>
                    <Text className="text-gray-400 text-xs mt-0.5" numberOfLines={1}>
                      Pro members are betting on these right now
                    </Text>
                  </View>
                  <View className="bg-emerald-500 rounded-lg px-3 py-1.5 shrink-0">
                    <Text className="text-white text-xs font-bold">UNLOCK</Text>
                  </View>
                </View>
              </LinearGradient>
            </Pressable>
          </Animated.View>
        )}

        {/* Data Status Indicator */}
        <Animated.View
          entering={FadeInUp.delay(250).springify()}
          className="mt-4 flex-row items-center justify-end"
        >
          {isDelayedMode ? (
            <Pressable
              onPress={() => router.push('/paywall')}
              className="flex-row items-center"
            >
              <View className="w-2 h-2 rounded-full mr-1.5 bg-amber-500" />
              <Text className="text-amber-400 text-xs font-medium">
                Signals locked
              </Text>
              <Lock size={10} color="#6B7280" style={{ marginLeft: 4 }} />
            </Pressable>
          ) : (
            <View className="flex-row items-center">
              <View className="w-2 h-2 rounded-full mr-1.5 bg-emerald-500" />
              <Text className="text-emerald-400 text-xs font-medium">
                Live
              </Text>
            </View>
          )}
        </Animated.View>
      </LinearGradient>

      {/* Games List */}
      <ScrollView
        className="flex-1 px-5"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor="#10B981"
            colors={['#10B981']}
          />
        }
      >
        {/* Live Games */}
        {liveGames.length > 0 && (
          <View className="mb-6">
            <Animated.View
              entering={FadeInDown.delay(150).springify()}
              className="flex-row items-center mb-3"
            >
              <View className="w-2 h-2 rounded-full bg-red-500 mr-2" />
              <Text className="text-gray-400 text-sm font-semibold uppercase tracking-wider">
                Live Now
              </Text>
              <Text className="text-gray-600 text-sm ml-2">
                {liveGames.length} game{liveGames.length > 1 ? 's' : ''}
              </Text>
            </Animated.View>

            {liveGames.map((game, index) => (
              <GameTile
                key={game.id}
                game={game}
                index={index}
                delayedMode={isDelayedMode}
                onUpgradePress={() => router.push('/paywall')}
              />
            ))}
          </View>
        )}

        {/* Upcoming Games */}
        {upcomingGames.length > 0 && (
          <View className="mb-6">
            <Animated.View
              entering={FadeInDown.delay(200 + liveGames.length * 50).springify()}
              className="flex-row items-center mb-3"
            >
              <View className="w-2 h-2 rounded-full bg-gray-500 mr-2" />
              <Text className="text-gray-400 text-sm font-semibold uppercase tracking-wider">
                Upcoming
              </Text>
              <Text className="text-gray-600 text-sm ml-2">
                {upcomingGames.length} game{upcomingGames.length > 1 ? 's' : ''}
              </Text>
            </Animated.View>

            {upcomingGames.map((game, index) => (
              <GameTile
                key={game.id}
                game={game}
                index={liveGames.length + index}
              />
            ))}
          </View>
        )}

        {/* Finished Games */}
        {finishedGames.length > 0 && (
          <View className="mb-6">
            <Animated.View
              entering={FadeInDown.delay(250 + (liveGames.length + upcomingGames.length) * 50).springify()}
              className="flex-row items-center mb-3"
            >
              <View className="w-2 h-2 rounded-full bg-gray-600 mr-2" />
              <Text className="text-gray-500 text-sm font-semibold uppercase tracking-wider">
                Final
              </Text>
              <Text className="text-gray-600 text-sm ml-2">
                {finishedGames.length} game{finishedGames.length > 1 ? 's' : ''}
              </Text>
            </Animated.View>

            {finishedGames.map((game, index) => (
              <GameTile
                key={game.id}
                game={game}
                index={liveGames.length + upcomingGames.length + index}
              />
            ))}
          </View>
        )}

        {/* Empty State */}
        {games.length === 0 && !isLoadingGames && (
          <View className="items-center justify-center py-20">
            <Text className="text-gray-500 text-lg">No games today</Text>
            <Text className="text-gray-600 text-sm mt-2">
              Pull down to refresh
            </Text>
          </View>
        )}

        {/* Loading State */}
        {isLoadingGames && games.length === 0 && (
          <View className="items-center justify-center py-20">
            <ActivityIndicator size="large" color="#10B981" />
            <Text className="text-gray-500 text-sm mt-4">
              Loading NBA games...
            </Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}
