// CourtQuant Pro Paywall
import React, { useState } from 'react';
import { View, Text, Pressable, ActivityIndicator, ScrollView } from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { FadeIn, FadeInDown, FadeInUp } from 'react-native-reanimated';
import {
  X,
  Zap,
  TrendingUp,
  Target,
  BarChart3,
  Shield,
  Crown,
  Star,
  Check,
  Clock,
  Eye,
  CheckCircle,
  ArrowDownRight,
} from 'lucide-react-native';
import { useQuery, useMutation } from '@tanstack/react-query';
import * as Haptics from 'expo-haptics';

import { useDiffFirstStore } from '@/lib/store';
import {
  getOfferings,
  purchasePackage,
  restorePurchases,
  hasEntitlement,
} from '@/lib/revenuecatClient';
import { cn } from '@/lib/cn';

type PlanType = 'weekly' | 'monthly' | 'annual';

const PLAN_DETAILS: Record<PlanType, { name: string; price: string; savings?: string; perWeek: string; popular?: boolean }> = {
  weekly: { name: 'Weekly', price: '$9.99', perWeek: '$9.99/wk' },
  monthly: { name: 'Monthly', price: '$29.99', savings: 'Save 25%', perWeek: '$7.50/wk', popular: true },
  annual: { name: 'Season Pass', price: '$199.99', savings: 'Best Value', perWeek: '$3.85/wk' },
};

export default function PaywallScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const setProAccess = useDiffFirstStore((s) => s.setProAccess);

  const [selectedPlan, setSelectedPlan] = useState<PlanType>('monthly');

  // Fetch offerings from RevenueCat
  const { data: offerings, isLoading: loadingOfferings } = useQuery({
    queryKey: ['offerings'],
    queryFn: async () => {
      const result = await getOfferings();
      return result.ok ? result.data : null;
    },
  });

  // Purchase mutation
  const purchaseMutation = useMutation({
    mutationFn: async (planType: PlanType) => {
      const packageId = planType === 'weekly' ? '$rc_weekly' : planType === 'monthly' ? '$rc_monthly' : '$rc_annual';
      const pkg = offerings?.current?.availablePackages?.find(
        (p) => p.identifier === packageId
      );
      if (!pkg) throw new Error('Package not found');
      const result = await purchasePackage(pkg);
      if (!result.ok) throw new Error(result.reason);
      return result.data;
    },
    onSuccess: async () => {
      const result = await hasEntitlement('pro_alerts');
      if (result.ok && result.data) {
        // Success haptic to celebrate the purchase
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        setProAccess(true);
        router.back();
      }
    },
  });

  // Restore purchases mutation
  const restoreMutation = useMutation({
    mutationFn: async () => {
      const result = await restorePurchases();
      if (!result.ok) throw new Error(result.reason);
      return result.data;
    },
    onSuccess: async () => {
      const result = await hasEntitlement('pro_alerts');
      if (result.ok && result.data) {
        // Success haptic for restored purchase
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        setProAccess(true);
        router.back();
      }
    },
  });

  const isProcessing = purchaseMutation.isPending || restoreMutation.isPending;

  const handlePurchase = () => {
    if (!isProcessing) {
      purchaseMutation.mutate(selectedPlan);
    }
  };

  const handleRestore = () => {
    if (!isProcessing) {
      restoreMutation.mutate();
    }
  };

  return (
    <View className="flex-1 bg-[#0A0A0F]">
      <LinearGradient
        colors={['#10B98120', '#0A0A0F']}
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          height: 300,
        }}
      />

      {/* Header */}
      <View
        style={{ paddingTop: insets.top }}
        className="px-5 pb-4 border-b border-gray-800"
      >
        <Animated.View
          entering={FadeIn.duration(300)}
          className="flex-row items-center justify-between"
        >
          <View className="flex-row items-center">
            <Crown size={24} color="#10B981" />
            <Text className="text-white text-xl font-bold ml-2">
              CourtQuant Pro
            </Text>
          </View>
          <Pressable
            onPress={() => router.back()}
            className="p-2 rounded-full bg-gray-800 active:opacity-70"
          >
            <X size={20} color="#9CA3AF" />
          </Pressable>
        </Animated.View>
      </View>

      <ScrollView
        className="flex-1 px-5"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingTop: 16, paddingBottom: insets.bottom + 20 }}
      >
        {/* Hero */}
        <Animated.View
          entering={FadeInDown.delay(100).springify()}
          className="items-center mb-5"
        >
          <View className="bg-emerald-500/20 rounded-full px-3 py-1 mb-3">
            <Text className="text-emerald-400 text-xs font-semibold">
              WALL STREET MEETS THE HARDWOOD
            </Text>
          </View>
          <Text className="text-white text-2xl font-bold text-center mb-2">
            We Trade Games{'\n'}Like Stocks
          </Text>
          <Text className="text-gray-400 text-center text-sm">
            The same indicators hedge funds use—{'\n'}now applied to NBA betting
          </Text>
        </Animated.View>

        {/* Validation Banner */}
        <Animated.View
          entering={FadeInDown.delay(150).springify()}
          className="bg-gradient-to-r from-amber-500/10 to-emerald-500/10 border border-amber-500/30 rounded-xl p-3 mb-5"
        >
          <View className="flex-row items-center justify-center mb-2">
            <CheckCircle size={16} color="#10B981" />
            <Text className="text-emerald-400 font-bold ml-2">
              Rigorously Validated
            </Text>
          </View>
          <Text className="text-white text-sm text-center mb-2">
            Strategies tested on 300+ real historical NBA games
          </Text>
          <View className="flex-row flex-wrap justify-center gap-2">
            <View className="bg-gray-800/50 px-2 py-1 rounded-full">
              <Text className="text-gray-300 text-xs">No data leakage</Text>
            </View>
            <View className="bg-gray-800/50 px-2 py-1 rounded-full">
              <Text className="text-gray-300 text-xs">No look-ahead bias</Text>
            </View>
            <View className="bg-gray-800/50 px-2 py-1 rounded-full">
              <Text className="text-gray-300 text-xs">~1 in 3 games signal</Text>
            </View>
          </View>
          <Text className="text-gray-500 text-xs text-center mt-2">
            Selective signals—quality over quantity
          </Text>
        </Animated.View>

        {/* Four Reduced Spread Strategies */}
        <Animated.View
          entering={FadeInDown.delay(200).springify()}
          className="mb-5"
        >
          <Text className="text-gray-500 text-xs font-semibold uppercase tracking-wider mb-3 text-center">
            4 Proven Strategies (96.5% Avg Win Rate)
          </Text>

          {/* Sweet Spot Strategy */}
          <View className="bg-[#12121A] border border-emerald-500/30 rounded-xl p-4 mb-3">
            <View className="flex-row items-center justify-between mb-2">
              <View className="flex-row items-center">
                <View className="bg-emerald-500/20 rounded-full p-2 mr-3">
                  <Target size={18} color="#10B981" />
                </View>
                <View>
                  <Text className="text-emerald-400 font-bold">Sweet Spot</Text>
                  <Text className="text-gray-500 text-xs">12-24 min | Lead 10-14 | Mom 10+</Text>
                </View>
              </View>
              <View className="bg-emerald-500/20 px-2 py-1 rounded-full">
                <Text className="text-emerald-400 text-xs font-bold">94.9%</Text>
              </View>
            </View>
            <Text className="text-gray-400 text-xs">Bet -7 spread | +$28 EV | 20.9% edge</Text>
          </View>

          {/* Moderate Strategy */}
          <View className="bg-[#12121A] border border-blue-500/30 rounded-xl p-4 mb-3">
            <View className="flex-row items-center justify-between mb-2">
              <View className="flex-row items-center">
                <View className="bg-blue-500/20 rounded-full p-2 mr-3">
                  <TrendingUp size={18} color="#3B82F6" />
                </View>
                <View>
                  <Text className="text-blue-400 font-bold">Moderate</Text>
                  <Text className="text-gray-500 text-xs">12-24 min | Lead 12-16 | Mom 12+</Text>
                </View>
              </View>
              <View className="bg-blue-500/20 px-2 py-1 rounded-full">
                <Text className="text-blue-400 text-xs font-bold">94.5%</Text>
              </View>
            </View>
            <Text className="text-gray-400 text-xs">Bet -7 spread | +$24 EV | 18.5% edge</Text>
          </View>

          {/* Mid-Range Strategy */}
          <View className="bg-[#12121A] border border-purple-500/30 rounded-xl p-4 mb-3">
            <View className="flex-row items-center justify-between mb-2">
              <View className="flex-row items-center">
                <View className="bg-purple-500/20 rounded-full p-2 mr-3">
                  <BarChart3 size={18} color="#A855F7" />
                </View>
                <View>
                  <Text className="text-purple-400 font-bold">Mid-Range</Text>
                  <Text className="text-gray-500 text-xs">12-24 min | Lead 14-18 | Mom 14+</Text>
                </View>
              </View>
              <View className="bg-purple-500/20 px-2 py-1 rounded-full">
                <Text className="text-purple-400 text-xs font-bold">96.4%</Text>
              </View>
            </View>
            <Text className="text-gray-400 text-xs">Bet -7 spread | +$22 EV | 17.4% edge</Text>
          </View>

          {/* Safe Strategy */}
          <View className="bg-[#12121A] border border-amber-500/30 rounded-xl p-4">
            <View className="flex-row items-center justify-between mb-2">
              <View className="flex-row items-center">
                <View className="bg-amber-500/20 rounded-full p-2 mr-3">
                  <Shield size={18} color="#F59E0B" />
                </View>
                <View>
                  <Text className="text-amber-400 font-bold">Safe</Text>
                  <Text className="text-gray-500 text-xs">12-24 min | Lead 16-20 | Mom 12+</Text>
                </View>
              </View>
              <View className="bg-amber-500/20 px-2 py-1 rounded-full">
                <Text className="text-amber-400 text-xs font-bold">100%</Text>
              </View>
            </View>
            <Text className="text-gray-400 text-xs">Bet -5 spread | +$19 EV | 16.0% edge</Text>
          </View>
        </Animated.View>

        {/* What You Get */}
        <Animated.View
          entering={FadeInDown.delay(250).springify()}
          className="mb-5"
        >
          <Text className="text-gray-500 text-xs font-semibold uppercase tracking-wider mb-3 text-center">
            What Pro Members Get
          </Text>
          <View className="bg-gray-800/30 rounded-xl p-4">
            <View className="flex-row items-center mb-3">
              <View className="bg-emerald-500/20 rounded-full p-1.5 mr-3">
                <Zap size={14} color="#10B981" />
              </View>
              <Text className="text-white font-medium flex-1">Instant alerts when signals fire</Text>
            </View>
            <View className="flex-row items-center mb-3">
              <View className="bg-emerald-500/20 rounded-full p-1.5 mr-3">
                <Target size={14} color="#10B981" />
              </View>
              <Text className="text-white font-medium flex-1">Exact bet instructions—no guessing</Text>
            </View>
            <View className="flex-row items-center mb-3">
              <View className="bg-emerald-500/20 rounded-full p-1.5 mr-3">
                <Eye size={14} color="#10B981" />
              </View>
              <Text className="text-white font-medium flex-1">Full transparency on every signal</Text>
            </View>
            <View className="flex-row items-center">
              <View className="bg-amber-500/20 rounded-full p-1.5 mr-3">
                <Star size={14} color="#F59E0B" />
              </View>
              <Text className="text-white font-medium flex-1">High conviction alerts with proven accuracy</Text>
            </View>
          </View>
        </Animated.View>

        {/* Urgency */}
        <Animated.View
          entering={FadeInUp.delay(280).springify()}
          className="bg-red-500/10 border border-red-500/20 rounded-xl p-3 mb-5"
        >
          <View className="flex-row items-center justify-center">
            <Clock size={14} color="#EF4444" />
            <Text className="text-red-400 font-semibold text-sm ml-2">
              Games are live now—don't miss today's signals
            </Text>
          </View>
        </Animated.View>

        {/* Plan Selection */}
        <Animated.View
          entering={FadeInUp.delay(300).springify()}
          className="mb-5"
        >
          <Text className="text-gray-500 text-xs font-semibold uppercase tracking-wider mb-3 text-center">
            Choose Your Plan
          </Text>
          <View className="flex-row">
            {(['weekly', 'monthly', 'annual'] as PlanType[]).map((plan) => (
              <Pressable
                key={plan}
                onPress={() => setSelectedPlan(plan)}
                className={cn(
                  'flex-1 mx-1 p-3 rounded-xl border-2 relative',
                  selectedPlan === plan
                    ? 'border-emerald-500 bg-emerald-500/10'
                    : 'border-gray-700 bg-gray-800/30'
                )}
              >
                {PLAN_DETAILS[plan].popular && (
                  <View className="absolute -top-2 left-0 right-0 items-center">
                    <View className="bg-amber-500 rounded-full px-2 py-0.5">
                      <Text className="text-black text-[9px] font-bold">POPULAR</Text>
                    </View>
                  </View>
                )}
                {PLAN_DETAILS[plan].savings && !PLAN_DETAILS[plan].popular && (
                  <View className="absolute -top-2 left-0 right-0 items-center">
                    <View className="bg-emerald-500 rounded-full px-2 py-0.5">
                      <Text className="text-white text-[9px] font-bold">
                        {PLAN_DETAILS[plan].savings}
                      </Text>
                    </View>
                  </View>
                )}
                <Text
                  className={cn(
                    'text-center font-semibold text-sm mt-1',
                    selectedPlan === plan ? 'text-white' : 'text-gray-400'
                  )}
                >
                  {PLAN_DETAILS[plan].name}
                </Text>
                <Text
                  className={cn(
                    'text-center font-bold text-lg',
                    selectedPlan === plan ? 'text-emerald-400' : 'text-gray-300'
                  )}
                >
                  {PLAN_DETAILS[plan].price}
                </Text>
                <Text className="text-gray-500 text-center text-xs">
                  {PLAN_DETAILS[plan].perWeek}
                </Text>
              </Pressable>
            ))}
          </View>
        </Animated.View>

        {/* CTA Button */}
        <Animated.View entering={FadeInUp.delay(400).springify()}>
          <Pressable
            onPress={handlePurchase}
            disabled={isProcessing || loadingOfferings}
            className={cn(
              'rounded-xl p-4 items-center',
              isProcessing ? 'bg-emerald-500/50' : 'bg-emerald-500 active:bg-emerald-600'
            )}
          >
            {isProcessing ? (
              <ActivityIndicator color="white" />
            ) : (
              <>
                <Text className="text-white font-bold text-lg">
                  Get the Edge Now
                </Text>
                <Text className="text-emerald-100 text-xs mt-0.5">
                  Start winning with data-driven signals
                </Text>
              </>
            )}
          </Pressable>

          <Pressable
            onPress={handleRestore}
            disabled={isProcessing}
            className="mt-3 p-2 items-center active:opacity-70"
          >
            <Text className="text-gray-400 text-sm">
              Restore Purchases
            </Text>
          </Pressable>

          {/* Footer */}
          <View className="flex-row justify-center items-center mt-3">
            <Shield size={12} color="#6B7280" />
            <Text className="text-gray-500 text-xs ml-1">
              Cancel anytime • Secure payment
            </Text>
          </View>
        </Animated.View>
      </ScrollView>
    </View>
  );
}
