// How It Works Screen - Detailed explanation of the CourtQuant 4 reduced spread strategies
import React from 'react';
import { View, Text, ScrollView, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Animated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import {
  X,
  TrendingUp,
  Activity,
  Target,
  Zap,
  BarChart3,
  History,
  AlertTriangle,
  CheckCircle,
  Info,
  Clock,
  Percent,
} from 'lucide-react-native';

interface SectionProps {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  delay?: number;
}

function Section({ title, icon, children, delay = 100 }: SectionProps) {
  return (
    <Animated.View
      entering={FadeInDown.delay(delay).springify()}
      className="mb-6"
    >
      <View className="flex-row items-center mb-3 px-5">
        {icon}
        <Text className="text-white text-lg font-bold ml-2">{title}</Text>
      </View>
      <View className="bg-[#12121A] mx-5 rounded-xl border border-gray-800 p-4">
        {children}
      </View>
    </Animated.View>
  );
}

export default function HowItWorksScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  return (
    <View className="flex-1 bg-[#0A0A0F]">
      {/* Header */}
      <View
        style={{ paddingTop: insets.top }}
        className="px-5 pb-4 border-b border-gray-800"
      >
        <Animated.View
          entering={FadeIn.duration(300)}
          className="flex-row items-center justify-between"
        >
          <View className="flex-row items-center">
            <Info size={24} color="#3B82F6" />
            <Text className="text-white text-xl font-bold ml-2">How It Works</Text>
          </View>
          <Pressable
            onPress={() => router.back()}
            className="p-2 rounded-full bg-gray-800 active:opacity-70"
          >
            <X size={20} color="#9CA3AF" />
          </Pressable>
        </Animated.View>
      </View>

      <ScrollView
        className="flex-1"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: insets.bottom + 20, paddingTop: 20 }}
      >
        {/* Core Philosophy */}
        <Section
          title="Our Philosophy"
          icon={<BarChart3 size={20} color="#10B981" />}
          delay={100}
        >
          <Text className="text-gray-300 leading-6 mb-3">
            CourtQuant uses <Text className="text-emerald-400 font-semibold">4 validated spread + moneyline strategies</Text> for NBA games, tested on <Text className="text-emerald-400 font-semibold">156 real games</Text>.
          </Text>
          <Text className="text-gray-300 leading-6 mb-3">
            Each signal recommends TWO bets: a <Text className="text-white font-semibold">reduced spread</Text> (-7 or -5) AND a <Text className="text-white font-semibold">moneyline</Text> bet:
          </Text>
          <View className="flex-row items-center mb-1">
            <View className="w-2 h-2 rounded-full bg-emerald-500 mr-2" />
            <Text className="text-gray-300 text-sm">
              <Text className="text-emerald-400 font-semibold">Sweet Spot</Text> - Spread 84.6% / ML 90.2% (+$24 combined)
            </Text>
          </View>
          <View className="flex-row items-center mb-1">
            <View className="w-2 h-2 rounded-full bg-blue-500 mr-2" />
            <Text className="text-gray-300 text-sm">
              <Text className="text-blue-400 font-semibold">Moderate</Text> - Spread 84.4% / ML 90.9% (+$18 combined)
            </Text>
          </View>
          <View className="flex-row items-center mb-1">
            <View className="w-2 h-2 rounded-full bg-purple-500 mr-2" />
            <Text className="text-gray-300 text-sm">
              <Text className="text-purple-400 font-semibold">Mid-Range</Text> - Spread 94.4% / ML 100% (+$32 combined)
            </Text>
          </View>
          <View className="flex-row items-center">
            <View className="w-2 h-2 rounded-full bg-amber-500 mr-2" />
            <Text className="text-gray-300 text-sm">
              <Text className="text-amber-400 font-semibold">Safe</Text> - Spread 96.0% / ML 96.3% (+$19 combined)
            </Text>
          </View>
        </Section>

        {/* Data Modes */}
        <Section
          title="Live vs Delayed Data"
          icon={<Clock size={20} color="#EF4444" />}
          delay={125}
        >
          <View className="mb-4">
            <View className="flex-row items-center mb-2">
              <View className="w-2 h-2 rounded-full bg-emerald-500 mr-2" />
              <Text className="text-emerald-400 font-semibold">Live Mode (Pro)</Text>
            </View>
            <Text className="text-gray-400 text-sm leading-5">
              Real-time data and signals as games happen. Pro subscribers get instant access to
              live scores, momentum indicators, and alerts the moment they fire.
            </Text>
          </View>

          <View>
            <View className="flex-row items-center mb-2">
              <View className="w-2 h-2 rounded-full bg-amber-500 mr-2" />
              <Text className="text-amber-400 font-semibold">Locked Mode (Free)</Text>
            </View>
            <Text className="text-gray-400 text-sm leading-5">
              You can see that signals exist and when they fire, but the actual
              recommendation is locked. Upgrade to Pro to unlock real-time signal instructions.
            </Text>
          </View>
        </Section>

        {/* Core Strategy */}
        <Section
          title="The 4 Reduced Spread + ML Strategies"
          icon={<TrendingUp size={20} color="#10B981" />}
          delay={175}
        >
          <Text className="text-gray-300 leading-6 mb-4">
            Signal for <Text className="text-emerald-400 font-semibold">REDUCED spreads</Text> + <Text className="text-emerald-400 font-semibold">moneyline</Text> for higher combined EV.
            All strategies require 12-24 minutes remaining and momentum aligning with lead.
          </Text>

          {/* Strategy 1: Sweet Spot */}
          <View className="bg-emerald-500/15 border border-emerald-500/40 rounded-xl p-3 mb-3">
            <View className="flex-row items-center mb-2">
              <View className="bg-emerald-500 rounded-full w-5 h-5 items-center justify-center mr-2">
                <Text className="text-white text-xs font-bold">1</Text>
              </View>
              <Text className="text-emerald-400 font-bold">SWEET SPOT</Text>
              <View className="bg-emerald-500/20 px-2 py-0.5 rounded-full ml-auto">
                <Text className="text-emerald-400 text-xs font-bold">84.6% / 90.2%</Text>
              </View>
            </View>
            <View className="flex-row flex-wrap">
              <Text className="text-gray-400 text-sm">Lead: <Text className="text-white">10-14</Text> | </Text>
              <Text className="text-gray-400 text-sm">Mom: <Text className="text-white">10+</Text> | </Text>
              <Text className="text-gray-400 text-sm">Bet: <Text className="text-emerald-400 font-bold">-7 + ML</Text></Text>
            </View>
            <Text className="text-gray-500 text-xs mt-1">Spread +$14 EV | ML +$10 EV | Combined +$24</Text>
          </View>

          {/* Strategy 2: Moderate */}
          <View className="bg-blue-500/15 border border-blue-500/40 rounded-xl p-3 mb-3">
            <View className="flex-row items-center mb-2">
              <View className="bg-blue-500 rounded-full w-5 h-5 items-center justify-center mr-2">
                <Text className="text-white text-xs font-bold">2</Text>
              </View>
              <Text className="text-blue-400 font-bold">MODERATE</Text>
              <View className="bg-blue-500/20 px-2 py-0.5 rounded-full ml-auto">
                <Text className="text-blue-400 text-xs font-bold">84.4% / 90.9%</Text>
              </View>
            </View>
            <View className="flex-row flex-wrap">
              <Text className="text-gray-400 text-sm">Lead: <Text className="text-white">12-16</Text> | </Text>
              <Text className="text-gray-400 text-sm">Mom: <Text className="text-white">12+</Text> | </Text>
              <Text className="text-gray-400 text-sm">Bet: <Text className="text-blue-400 font-bold">-7 + ML</Text></Text>
            </View>
            <Text className="text-gray-500 text-xs mt-1">Spread +$11 EV | ML +$7 EV | Combined +$18</Text>
          </View>

          {/* Strategy 3: Mid-Range */}
          <View className="bg-purple-500/15 border border-purple-500/40 rounded-xl p-3 mb-3">
            <View className="flex-row items-center mb-2">
              <View className="bg-purple-500 rounded-full w-5 h-5 items-center justify-center mr-2">
                <Text className="text-white text-xs font-bold">3</Text>
              </View>
              <Text className="text-purple-400 font-bold">MID-RANGE</Text>
              <View className="bg-purple-500/20 px-2 py-0.5 rounded-full ml-auto">
                <Text className="text-purple-400 text-xs font-bold">94.4% / 100%</Text>
              </View>
            </View>
            <View className="flex-row flex-wrap">
              <Text className="text-gray-400 text-sm">Lead: <Text className="text-white">14-18</Text> | </Text>
              <Text className="text-gray-400 text-sm">Mom: <Text className="text-white">14+</Text> | </Text>
              <Text className="text-gray-400 text-sm">Bet: <Text className="text-purple-400 font-bold">-7 + ML</Text></Text>
            </View>
            <Text className="text-gray-500 text-xs mt-1">Spread +$20 EV | ML +$12 EV | Combined +$32</Text>
          </View>

          {/* Strategy 4: Safe */}
          <View className="bg-amber-500/15 border border-amber-500/40 rounded-xl p-3 mb-3">
            <View className="flex-row items-center mb-2">
              <View className="bg-amber-500 rounded-full w-5 h-5 items-center justify-center mr-2">
                <Text className="text-white text-xs font-bold">4</Text>
              </View>
              <Text className="text-amber-400 font-bold">SAFE</Text>
              <View className="bg-amber-500/20 px-2 py-0.5 rounded-full ml-auto">
                <Text className="text-amber-400 text-xs font-bold">96.0% / 96.3%</Text>
              </View>
            </View>
            <View className="flex-row flex-wrap">
              <Text className="text-gray-400 text-sm">Lead: <Text className="text-white">16-20</Text> | </Text>
              <Text className="text-gray-400 text-sm">Mom: <Text className="text-white">12+</Text> | </Text>
              <Text className="text-gray-400 text-sm">Bet: <Text className="text-amber-400 font-bold">-5 + ML</Text></Text>
            </View>
            <Text className="text-gray-500 text-xs mt-1">Spread +$14 EV | ML +$5 EV | Combined +$19</Text>
          </View>

          <View className="bg-gray-800/50 rounded-lg p-3">
            <Text className="text-gray-400 text-xs leading-5">
              <Text className="text-white font-semibold">Key Insight:</Text> Each signal recommends TWO bets: a reduced spread (-7 or -5) AND a moneyline bet. Spread bets have higher payout per win (lower market prob = better odds) with 84-96% WR. Moneyline bets have higher win rates (90-100% WR) but lower payout per win. Combined EV is +$18-$32 per signal.
            </Text>
          </View>
        </Section>

        {/* Signal Conditions */}
        <Section
          title="Strategy Conditions Table"
          icon={<Zap size={20} color="#10B981" />}
          delay={200}
        >
          <Text className="text-gray-300 leading-6 mb-4">
            Each strategy has specific requirements. Momentum must ALWAYS align with lead direction:
          </Text>

          {/* Condition Table */}
          <View className="bg-gray-800/50 rounded-lg overflow-hidden mb-4">
            <View className="flex-row border-b border-gray-700 p-3">
              <Text className="text-gray-400 font-semibold w-16">Strategy</Text>
              <Text className="text-gray-400 font-semibold w-14">Lead</Text>
              <Text className="text-gray-400 font-semibold w-10">Mom</Text>
              <Text className="text-gray-400 font-semibold w-16">Bet</Text>
              <Text className="text-gray-400 font-semibold flex-1">Spread/ML</Text>
            </View>
            <View className="flex-row border-b border-gray-700/50 p-3">
              <Text className="text-emerald-400 w-16">Sweet</Text>
              <Text className="text-white w-14">10-14</Text>
              <Text className="text-white w-10">10+</Text>
              <Text className="text-emerald-400 w-16 font-semibold">-7+ML</Text>
              <Text className="text-gray-300 flex-1">84.6/90.2%</Text>
            </View>
            <View className="flex-row border-b border-gray-700/50 p-3">
              <Text className="text-blue-400 w-16">Mod</Text>
              <Text className="text-white w-14">12-16</Text>
              <Text className="text-white w-10">12+</Text>
              <Text className="text-blue-400 w-16 font-semibold">-7+ML</Text>
              <Text className="text-gray-300 flex-1">84.4/90.9%</Text>
            </View>
            <View className="flex-row border-b border-gray-700/50 p-3">
              <Text className="text-purple-400 w-16">Mid</Text>
              <Text className="text-white w-14">14-18</Text>
              <Text className="text-white w-10">14+</Text>
              <Text className="text-purple-400 w-16 font-semibold">-7+ML</Text>
              <Text className="text-gray-300 flex-1">94.4/100%</Text>
            </View>
            <View className="flex-row p-3">
              <Text className="text-amber-400 w-16">Safe</Text>
              <Text className="text-white w-14">16-20</Text>
              <Text className="text-white w-10">12+</Text>
              <Text className="text-amber-400 w-16 font-semibold">-5+ML</Text>
              <Text className="text-gray-300 flex-1">96.0/96.3%</Text>
            </View>
          </View>

          <Text className="text-gray-500 text-xs mb-4">All strategies require 12-24 minutes remaining in game.</Text>

          {/* Decision Logic */}
          <View className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-3 mb-3">
            <View className="flex-row items-center">
              <CheckCircle size={14} color="#10B981" />
              <Text className="text-emerald-400 font-semibold ml-2 text-sm">Signal fires</Text>
            </View>
            <Text className="text-gray-400 text-xs mt-1">
              → Leading team at REDUCED spread (e.g., -7 or -5) + MONEYLINE bet
            </Text>
          </View>

          <View className="bg-red-500/10 border border-red-500/30 rounded-lg p-3">
            <View className="flex-row items-center">
              <AlertTriangle size={14} color="#EF4444" />
              <Text className="text-red-400 font-semibold ml-2 text-sm">No match</Text>
            </View>
            <Text className="text-gray-400 text-xs mt-1">
              → No signal. Wait for next opportunity.
            </Text>
          </View>
        </Section>

        {/* Key Rules */}
        <Section
          title="Critical Rules"
          icon={<AlertTriangle size={20} color="#F59E0B" />}
          delay={225}
        >
          <View className="mb-4">
            <View className="flex-row items-center mb-2">
              <CheckCircle size={14} color="#10B981" />
              <Text className="text-emerald-400 font-semibold ml-2">Momentum Must Align</Text>
            </View>
            <Text className="text-gray-400 text-sm leading-5">
              If home leads, home must have positive momentum. If away leads, away must have positive momentum.
              No signal fires if momentum contradicts the lead.
            </Text>
          </View>

          <View className="mb-4">
            <View className="flex-row items-center mb-2">
              <CheckCircle size={14} color="#10B981" />
              <Text className="text-emerald-400 font-semibold ml-2">No Tie Games</Text>
            </View>
            <Text className="text-gray-400 text-sm leading-5">
              Signals only fire when one team has a clear lead. Tied games return no signal.
            </Text>
          </View>

          <View>
            <View className="flex-row items-center mb-2">
              <CheckCircle size={14} color="#10B981" />
              <Text className="text-emerald-400 font-semibold ml-2">Signal the Leader</Text>
            </View>
            <Text className="text-gray-400 text-sm leading-5">
              We always signal on the team that's winning AND has momentum. This is the key insight
              from backtesting real NBA games.
            </Text>
          </View>
        </Section>

        {/* How Momentum is Calculated */}
        <Section
          title="5-Minute Momentum Calculation"
          icon={<Activity size={20} color="#A855F7" />}
          delay={250}
        >
          <Text className="text-gray-300 leading-6 mb-4">
            Momentum is calculated by comparing points scored over the last ~5 minutes:
          </Text>

          <View className="bg-gray-800/50 rounded-xl p-3 mb-3">
            <Text className="text-white font-mono text-sm mb-2">
              momentum = home_pts_5min - away_pts_5min
            </Text>
            <Text className="text-gray-400 text-sm leading-5">
              Positive = home outscoring away recently{'\n'}
              Negative = away outscoring home recently
            </Text>
          </View>

          <View className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-3">
            <Text className="text-emerald-400 text-sm font-semibold mb-1">Example:</Text>
            <Text className="text-gray-400 text-sm">
              Home scored 14 pts in last 5 min, Away scored 4 pts{'\n'}
              Momentum = 14 - 4 = <Text className="text-emerald-400 font-bold">+10</Text> (home momentum)
            </Text>
          </View>
        </Section>

        {/* Track Record */}
        <Section
          title="Reduced Spread Signal Grading"
          icon={<History size={20} color="#3B82F6" />}
          delay={275}
        >
          <Text className="text-gray-300 leading-6 mb-4">
            We signal <Text className="text-white font-semibold">REDUCED spreads</Text>, not full lead.
            This dramatically increases historical accuracy:
          </Text>

          <View className="bg-gray-800/50 rounded-xl p-3 mb-4">
            <Text className="text-white font-semibold text-sm mb-2">Example: Team leads by 12, Signal: -7 SPREAD</Text>
            <Text className="text-gray-400 text-sm leading-5">
              Signal is -7 (not -12). This would win if team wins by 8+ points.{'\n'}
              Much easier than needing to win by 13+!
            </Text>
          </View>

          <View className="flex-row items-center mb-2">
            <CheckCircle size={14} color="#10B981" />
            <Text className="text-emerald-400 font-semibold ml-2 mr-2">CORRECT</Text>
            <Text className="text-gray-400 text-sm flex-1">
              Team wins by MORE than the reduced spread
            </Text>
          </View>

          <View className="flex-row items-center mb-2">
            <AlertTriangle size={14} color="#EF4444" />
            <Text className="text-red-400 font-semibold ml-2 mr-2">INCORRECT</Text>
            <Text className="text-gray-400 text-sm flex-1">
              Team wins by less than spread, or loses
            </Text>
          </View>

          <View className="flex-row items-center mb-4">
            <Activity size={14} color="#F59E0B" />
            <Text className="text-amber-400 font-semibold ml-2 mr-2">PUSH</Text>
            <Text className="text-gray-400 text-sm flex-1">
              Team wins by exactly the spread (rare)
            </Text>
          </View>

          <View className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-3">
            <Text className="text-emerald-400 font-semibold text-sm mb-1">Tested on 156 Real NBA Games</Text>
            <Text className="text-gray-400 text-sm leading-5">
              Spread: 84.6% / 84.4% / 94.4% / 96.0% • ML: 90.2% / 90.9% / 100% / 96.3%
            </Text>
          </View>
        </Section>

        {/* Probability Calculations */}
        <Section
          title="Market Probability & Edge"
          icon={<Percent size={20} color="#A855F7" />}
          delay={300}
        >
          <Text className="text-gray-300 leading-6 mb-4">
            The key insight is the "cushion" (lead minus spread required):
          </Text>

          <View className="flex-row items-start mb-4">
            <View className="bg-emerald-500/20 rounded-lg p-2 mr-3">
              <TrendingUp size={18} color="#10B981" />
            </View>
            <View className="flex-1">
              <Text className="text-white font-semibold mb-1">Market Probability</Text>
              <Text className="text-gray-400 text-sm leading-5">
                Sweet Spot (cushion 3-7): ~74% market prob{'\n'}
                Safe (cushion 11-15): ~84% market prob
              </Text>
            </View>
          </View>

          <View className="flex-row items-start mb-4">
            <View className="bg-amber-500/20 rounded-lg p-2 mr-3">
              <Activity size={18} color="#F59E0B" />
            </View>
            <View className="flex-1">
              <Text className="text-white font-semibold mb-1">Lower Market Prob = Higher Theoretical Return</Text>
              <Text className="text-gray-400 text-sm leading-5">
                Sweet Spot has lower market prob (~74% spread) but 84.6% spread WR / 90.2% ML WR.
                Safe has higher market prob (~84% spread) but 96.0% spread WR / 96.3% ML WR.
              </Text>
            </View>
          </View>

          <View className="flex-row items-start mb-4">
            <View className="bg-blue-500/20 rounded-lg p-2 mr-3">
              <Clock size={18} color="#3B82F6" />
            </View>
            <View className="flex-1">
              <Text className="text-white font-semibold mb-1">Indicator = Model Prob - Market Prob</Text>
              <Text className="text-gray-400 text-sm leading-5">
                Our model achieves 84-100% historical accuracy vs 74-92% market expectations.
                This gap is our informational indicator (8-15%).
              </Text>
            </View>
          </View>

          <View className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-3">
            <Text className="text-emerald-400 font-semibold mb-1">Theoretical Calculation</Text>
            <Text className="text-gray-400 text-sm leading-5">
              Based on historical data analysis.{'\n'}
              Example: 70% market prob with 95% historical accuracy in our model.{'\n'}
              Past performance does not guarantee future results.
            </Text>
          </View>
        </Section>

        {/* Disclaimer */}
        <Animated.View
          entering={FadeInDown.delay(325).springify()}
          className="px-5"
        >
          <View className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-4">
            <View className="flex-row items-center mb-2">
              <AlertTriangle size={16} color="#F59E0B" />
              <Text className="text-amber-400 font-semibold ml-2">Important Disclaimer</Text>
            </View>
            <Text className="text-gray-400 text-sm leading-5">
              No model is perfect. Our signals are based on statistical patterns from historical simulations that may provide insight
              over time, not guaranteed outcomes. Individual results will vary. Past performance does
              not guarantee future results. This information is for educational purposes only.
            </Text>
          </View>
        </Animated.View>
      </ScrollView>
    </View>
  );
}
