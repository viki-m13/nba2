// ScoreFlow Chart - Spread time series visualization
import React, { useMemo } from 'react';
import { View, Text, Dimensions } from 'react-native';
import Svg, { Path, Line, Rect, Circle, G, Defs, LinearGradient as SvgGradient, Stop, Text as SvgText } from 'react-native-svg';
import Animated, { FadeIn } from 'react-native-reanimated';

import type { DifferentialPoint, Run, SupportResistanceLevel, Alert } from '@/lib/types';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

interface ScoreFlowChartProps {
  data: DifferentialPoint[];
  runs?: Run[];
  supportLevels?: SupportResistanceLevel[];
  resistanceLevels?: SupportResistanceLevel[];
  alerts?: Alert[];
  height?: number;
  homeTeamAbbr: string;
  awayTeamAbbr: string;
  hideSignals?: boolean; // Hide signal markers on chart (for non-pro users on live games)
}

export function ScoreFlowChart({
  data,
  runs = [],
  supportLevels = [],
  resistanceLevels = [],
  alerts = [],
  height = 240,
  homeTeamAbbr,
  awayTeamAbbr,
  hideSignals = false,
}: ScoreFlowChartProps) {
  const width = SCREEN_WIDTH - 40;
  const padding = { top: 20, right: 16, bottom: 30, left: 40 };
  const chartWidth = width - padding.left - padding.right;
  const chartHeight = height - padding.top - padding.bottom;

  const chartData = useMemo(() => {
    if (data.length < 2) return null;

    // Calculate bounds from spread values
    const differentials = data.map((d) => d.differential);
    const allValues = [...differentials, 0];

    let min = Math.min(...allValues);
    let max = Math.max(...allValues);

    // Add some padding to bounds
    const range = max - min || 10;
    min = min - range * 0.1;
    max = max + range * 0.1;

    // Scale functions
    const xScale = (index: number) => padding.left + (index / (data.length - 1)) * chartWidth;
    const yScale = (value: number) => padding.top + chartHeight - ((value - min) / (max - min)) * chartHeight;

    // Generate main path
    const points = data.map((d, i) => ({ x: xScale(i), y: yScale(d.differential) }));
    const mainPath = points
      .map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`)
      .join(' ');

    // Generate area path (filled below/above zero line)
    const zeroY = yScale(0);
    const areaPathPositive = points
      .map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${Math.min(p.y, zeroY)}`)
      .join(' ') + ` L ${points[points.length - 1].x} ${zeroY} L ${points[0].x} ${zeroY} Z`;

    const areaPathNegative = points
      .map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${Math.max(p.y, zeroY)}`)
      .join(' ') + ` L ${points[points.length - 1].x} ${zeroY} L ${points[0].x} ${zeroY} Z`;

    // Quarter markers
    const quarters = data.reduce<{ possession: number; quarter: number }[]>((acc, d, i) => {
      if (i === 0 || d.quarter !== data[i - 1].quarter) {
        acc.push({ possession: i, quarter: d.quarter });
      }
      return acc;
    }, []);

    // Y-axis labels - use index for unique keys
    const yTicks = 5;
    const yLabels = Array.from({ length: yTicks }, (_, i) => {
      const value = min + ((max - min) / (yTicks - 1)) * i;
      return { index: i, value: Math.round(value), y: yScale(value) };
    }).reverse();

    return {
      min,
      max,
      points,
      mainPath,
      areaPathPositive,
      areaPathNegative,
      quarters,
      yLabels,
      zeroY,
      xScale,
      yScale,
      lastPoint: points[points.length - 1],
      lastValue: data[data.length - 1].differential,
    };
  }, [data, chartWidth, chartHeight]);

  if (!chartData) {
    return (
      <View style={{ height, width }} className="items-center justify-center">
        <Text className="text-gray-500">Waiting for game data...</Text>
      </View>
    );
  }

  return (
    <Animated.View entering={FadeIn.duration(500)}>
      <View style={{ height, width }}>
        <Svg width={width} height={height}>
          <Defs>
            {/* Positive gradient */}
            <SvgGradient id="positiveGradient" x1="0" y1="0" x2="0" y2="1">
              <Stop offset="0" stopColor="#10B981" stopOpacity="0.4" />
              <Stop offset="1" stopColor="#10B981" stopOpacity="0" />
            </SvgGradient>
            {/* Negative gradient */}
            <SvgGradient id="negativeGradient" x1="0" y1="0" x2="0" y2="1">
              <Stop offset="0" stopColor="#EF4444" stopOpacity="0" />
              <Stop offset="1" stopColor="#EF4444" stopOpacity="0.4" />
            </SvgGradient>
          </Defs>

          {/* Grid lines */}
          {chartData.yLabels.map(({ index, value, y }) => (
            <G key={`y-label-${index}`}>
              <Line
                x1={padding.left}
                y1={y}
                x2={width - padding.right}
                y2={y}
                stroke="#1E1E2E"
                strokeWidth={value === 0 ? 2 : 1}
                strokeDasharray={value === 0 ? undefined : '4,4'}
              />
              <SvgText
                x={padding.left - 8}
                y={y + 4}
                fill="#6B7280"
                fontSize={10}
                textAnchor="end"
              >
                {value > 0 ? `+${value}` : value}
              </SvgText>
            </G>
          ))}

          {/* Quarter markers */}
          {chartData.quarters.map(({ possession, quarter }, idx) => {
            const x = chartData.xScale(possession);
            return (
              <G key={`quarter-${idx}-${possession}`}>
                <Line
                  x1={x}
                  y1={padding.top}
                  x2={x}
                  y2={height - padding.bottom}
                  stroke="#2D2D3A"
                  strokeWidth={1}
                />
                <SvgText
                  x={x + 4}
                  y={height - 10}
                  fill="#6B7280"
                  fontSize={10}
                >
                  Q{quarter}
                </SvgText>
              </G>
            );
          })}

          {/* Support/Resistance levels with identification markers */}
          {supportLevels.map((level, i) => {
            const startX = level.identifiedAt?.possessionIndex
              ? chartData.xScale(Math.min(level.identifiedAt.possessionIndex, data.length - 1))
              : padding.left;
            return (
              <G key={`support-${i}-${level.level}`}>
                {/* Level line - only from when it was identified */}
                <Line
                  x1={startX}
                  y1={chartData.yScale(level.level)}
                  x2={width - padding.right}
                  y2={chartData.yScale(level.level)}
                  stroke="#10B981"
                  strokeWidth={1.5}
                  strokeDasharray="6,3"
                  opacity={0.6}
                />
                {/* Identification marker */}
                {level.identifiedAt && (
                  <>
                    <Circle
                      cx={startX}
                      cy={chartData.yScale(level.level)}
                      r={4}
                      fill="#10B981"
                      opacity={0.8}
                    />
                    <SvgText
                      x={startX + 6}
                      y={chartData.yScale(level.level) - 4}
                      fill="#10B981"
                      fontSize={8}
                      opacity={0.8}
                    >
                      S:{level.level > 0 ? '+' : ''}{level.level}
                    </SvgText>
                  </>
                )}
              </G>
            );
          })}
          {resistanceLevels.map((level, i) => {
            const startX = level.identifiedAt?.possessionIndex
              ? chartData.xScale(Math.min(level.identifiedAt.possessionIndex, data.length - 1))
              : padding.left;
            return (
              <G key={`resistance-${i}-${level.level}`}>
                {/* Level line - only from when it was identified */}
                <Line
                  x1={startX}
                  y1={chartData.yScale(level.level)}
                  x2={width - padding.right}
                  y2={chartData.yScale(level.level)}
                  stroke="#EF4444"
                  strokeWidth={1.5}
                  strokeDasharray="6,3"
                  opacity={0.6}
                />
                {/* Identification marker */}
                {level.identifiedAt && (
                  <>
                    <Circle
                      cx={startX}
                      cy={chartData.yScale(level.level)}
                      r={4}
                      fill="#EF4444"
                      opacity={0.8}
                    />
                    <SvgText
                      x={startX + 6}
                      y={chartData.yScale(level.level) - 4}
                      fill="#EF4444"
                      fontSize={8}
                      opacity={0.8}
                    >
                      R:{level.level > 0 ? '+' : ''}{level.level}
                    </SvgText>
                  </>
                )}
              </G>
            );
          })}

          {/* Run highlights */}
          {runs.map((run, i) => {
            const startX = chartData.xScale(run.startPossession);
            const endX = chartData.xScale(run.endPossession);
            return (
              <Rect
                key={`run-${i}`}
                x={startX}
                y={padding.top}
                width={endX - startX}
                height={chartHeight}
                fill={run.team === 'home' ? '#10B981' : '#EF4444'}
                opacity={0.1}
              />
            );
          })}

          {/* Area fills */}
          <Path
            d={chartData.areaPathPositive}
            fill="url(#positiveGradient)"
          />
          <Path
            d={chartData.areaPathNegative}
            fill="url(#negativeGradient)"
          />

          {/* Main spread line */}
          <Path
            d={chartData.mainPath}
            fill="none"
            stroke={chartData.lastValue >= 0 ? '#10B981' : '#EF4444'}
            strokeWidth={2.5}
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* Current value indicator */}
          <Circle
            cx={chartData.lastPoint.x}
            cy={chartData.lastPoint.y}
            r={5}
            fill={chartData.lastValue >= 0 ? '#10B981' : '#EF4444'}
          />
          <Circle
            cx={chartData.lastPoint.x}
            cy={chartData.lastPoint.y}
            r={8}
            fill={chartData.lastValue >= 0 ? '#10B981' : '#EF4444'}
            opacity={0.3}
          />

          {/* Signal markers on chart - all signals get golden ring */}
          {!hideSignals && alerts.map((alert, i) => {
            // Use possessionIndex if available for accurate X positioning
            let x: number;
            let y: number;

            if (alert.possessionIndex !== undefined && alert.possessionIndex < data.length) {
              x = chartData.xScale(alert.possessionIndex);
              const signalDiff = alert.scoreAtSignal?.differential ?? data[alert.possessionIndex].differential;
              y = chartData.yScale(signalDiff);
            } else {
              // Fallback: estimate position from quarter
              const quarterMatch = alert.gameTime?.match(/Q(\d)/);
              const quarter = quarterMatch ? parseInt(quarterMatch[1]) : 1;
              const possessionEstimate = Math.min(
                Math.floor((quarter - 1) * (data.length / 4) + (data.length / 8)),
                data.length - 1
              );
              x = chartData.xScale(possessionEstimate);
              const differential = alert.scoreAtSignal?.differential ?? 0;
              y = chartData.yScale(differential);
            }

            const isWin = alert.outcome === 'win';
            const isLoss = alert.outcome === 'loss';

            // Calculate spread target line
            const spreadBet = alert.spreadBet;
            const signalDiff = alert.scoreAtSignal?.differential ?? 0;
            let spreadTargetY: number | null = null;
            let spreadTargetLevel: number | null = null;

            if (spreadBet !== undefined && alert.possessionIndex !== undefined) {
              if (signalDiff > 0) {
                spreadTargetLevel = Math.abs(spreadBet);
              } else {
                spreadTargetLevel = -Math.abs(spreadBet);
              }
              spreadTargetY = chartData.yScale(spreadTargetLevel);
            }

            // All signals get the same treatment - colored dot with golden ring
            return (
              <G key={`signal-${alert.id}-${i}`}>
                {/* Spread target line from signal point to end of chart */}
                {spreadTargetY !== null && spreadTargetLevel !== null && (
                  <>
                    <Line
                      x1={x}
                      y1={spreadTargetY}
                      x2={width - padding.right}
                      y2={spreadTargetY}
                      stroke={isWin ? '#10B981' : isLoss ? '#EF4444' : '#F59E0B'}
                      strokeWidth={1.5}
                      strokeDasharray="4,3"
                      opacity={0.6}
                    />
                    <SvgText
                      x={x + 4}
                      y={spreadTargetY - 4}
                      fill={isWin ? '#10B981' : isLoss ? '#EF4444' : '#F59E0B'}
                      fontSize={7}
                      opacity={0.8}
                    >
                      {spreadBet}
                    </SvgText>
                  </>
                )}
                {/* Outer golden glow */}
                <Circle
                  cx={x}
                  cy={y}
                  r={14}
                  fill="#F59E0B"
                  opacity={0.15}
                />
                {/* Golden ring */}
                <Circle
                  cx={x}
                  cy={y}
                  r={10}
                  fill="none"
                  stroke="#F59E0B"
                  strokeWidth={2}
                  opacity={0.8}
                />
                {/* Inner circle with outcome color (green/red) */}
                <Circle
                  cx={x}
                  cy={y}
                  r={6}
                  fill={isWin ? '#10B981' : isLoss ? '#EF4444' : '#F59E0B'}
                />
              </G>
            );
          })}
        </Svg>

        {/* Team labels */}
        <View
          style={{
            position: 'absolute',
            right: padding.right + 8,
            top: padding.top,
          }}
        >
          <Text className="text-emerald-400 text-xs font-semibold">
            {homeTeamAbbr} +
          </Text>
        </View>
        <View
          style={{
            position: 'absolute',
            right: padding.right + 8,
            bottom: padding.bottom + 8,
          }}
        >
          <Text className="text-red-400 text-xs font-semibold">
            {awayTeamAbbr} +
          </Text>
        </View>
      </View>

      {/* Legend */}
      <View className="flex-row items-center justify-center mt-2 flex-wrap">
        <View className="flex-row items-center mx-2">
          <View className={`w-3 h-0.5 mr-1 ${chartData.lastValue >= 0 ? 'bg-emerald-400' : 'bg-red-400'}`} />
          <Text className="text-gray-400 text-xs">Spread</Text>
        </View>
        {supportLevels.length > 0 && (
          <View className="flex-row items-center mx-2">
            <View className="w-3 h-0.5 bg-emerald-400 mr-1 opacity-60" style={{ borderStyle: 'dashed' }} />
            <Text className="text-gray-400 text-xs">Support</Text>
          </View>
        )}
        {resistanceLevels.length > 0 && (
          <View className="flex-row items-center mx-2">
            <View className="w-3 h-0.5 bg-red-400 mr-1 opacity-60" />
            <Text className="text-gray-400 text-xs">Resistance</Text>
          </View>
        )}
        {!hideSignals && alerts.length > 0 && (
          <View className="flex-row items-center mx-2">
            <View className={`w-4 h-4 rounded-full border-2 border-amber-400 items-center justify-center mr-1`}>
              <View className={`w-2 h-2 rounded-full ${chartData.lastValue >= 0 ? 'bg-emerald-400' : 'bg-red-400'}`} />
            </View>
            <Text className="text-gray-400 text-xs">Signals</Text>
          </View>
        )}
      </View>
    </Animated.View>
  );
}
