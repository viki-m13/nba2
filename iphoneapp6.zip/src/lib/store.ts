// CourtQuant Global State - v5.0 RSI+Slope Strategy
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { Game, Alert, UserTeamPreference } from './types';
import { fetchNBAData } from './nba-api';
// Note: mock-data.ts kept only for NBA_TEAMS reference in settings, not for game generation

// Signal type preferences
export type SignalTypePreference = 'all' | 'high_conviction_only' | 'standard_only';

interface DiffFirstState {
  // Games
  games: Game[];
  selectedGameId: string | null;
  isLoadingGames: boolean;
  lastFetchTime: number | null;

  // User preferences
  favoriteTeamId: UserTeamPreference;
  alertsEnabled: boolean;
  signalTypePreference: SignalTypePreference;

  // Subscription
  hasProAccess: boolean;

  // Alerts history
  alertHistory: Alert[];

  // Actions
  setGames: (games: Game[]) => void;
  selectGame: (gameId: string | null) => void;
  setFavoriteTeam: (teamId: string | null) => void;
  toggleAlerts: () => void;
  setSignalTypePreference: (preference: SignalTypePreference) => void;
  setProAccess: (hasAccess: boolean) => void;
  addAlert: (alert: Alert) => void;
  updateAlertOutcome: (alertId: string, outcome: Alert['outcome']) => void;
  refreshGames: () => void;
  fetchRealGames: () => Promise<void>;
}

export const useDiffFirstStore = create<DiffFirstState>()(
  persist(
    (set, get) => ({
      // Initial state - start empty, will fetch real data
      games: [],
      selectedGameId: null,
      isLoadingGames: false,
      lastFetchTime: null,
      favoriteTeamId: null,
      alertsEnabled: true,
      signalTypePreference: 'all' as SignalTypePreference,
      hasProAccess: false,
      alertHistory: [],

      // Actions
      setGames: (games) => set({ games }),

      selectGame: (gameId) => set({ selectedGameId: gameId }),

      setFavoriteTeam: (teamId) => set({ favoriteTeamId: teamId }),

      toggleAlerts: () =>
        set((state) => ({ alertsEnabled: !state.alertsEnabled })),

      setSignalTypePreference: (preference) => set({ signalTypePreference: preference }),

      setProAccess: (hasAccess) => set({ hasProAccess: hasAccess }),

      addAlert: (alert) =>
        set((state) => ({ alertHistory: [alert, ...state.alertHistory].slice(0, 100) })),

      updateAlertOutcome: (alertId, outcome) =>
        set((state) => ({
          alertHistory: state.alertHistory.map((a) =>
            a.id === alertId ? { ...a, outcome } : a
          ),
        })),

      refreshGames: () => {
        // Try to fetch real games, fallback to mock
        get().fetchRealGames();
      },

      fetchRealGames: async () => {
        const state = get();

        // Prevent duplicate fetches within 30 seconds
        if (state.isLoadingGames) return;
        if (state.lastFetchTime && Date.now() - state.lastFetchTime < 30000) {
          return;
        }

        set({ isLoadingGames: true });

        try {
          const games = await fetchNBAData();
          if (games.length > 0) {
            set({ games, lastFetchTime: Date.now() });
            console.log('[Store] Loaded real NBA games:', games.length);
          } else {
            // No real games available - keep empty (no mock data)
            set({ games: [], lastFetchTime: Date.now() });
            console.log('[Store] No real games available');
          }
        } catch (error) {
          console.log('[Store] Error fetching games:', error);
          set({ games: [], lastFetchTime: Date.now() });
        } finally {
          set({ isLoadingGames: false });
        }
      },
    }),
    {
      name: 'courtquant-storage',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        favoriteTeamId: state.favoriteTeamId,
        alertsEnabled: state.alertsEnabled,
        signalTypePreference: state.signalTypePreference,
        hasProAccess: state.hasProAccess,
        alertHistory: state.alertHistory,
      }),
    }
  )
);

// Selectors for optimized re-renders
export const useGames = () => useDiffFirstStore((s) => s.games);
export const useSelectedGameId = () => useDiffFirstStore((s) => s.selectedGameId);
export const useIsLoadingGames = () => useDiffFirstStore((s) => s.isLoadingGames);
export const useFetchRealGames = () => useDiffFirstStore((s) => s.fetchRealGames);
export const useSelectedGame = () => {
  const games = useDiffFirstStore((s) => s.games);
  const selectedId = useDiffFirstStore((s) => s.selectedGameId);
  return games.find((g) => g.id === selectedId) ?? null;
};
export const useFavoriteTeamId = () => useDiffFirstStore((s) => s.favoriteTeamId);
export const useAlertsEnabled = () => useDiffFirstStore((s) => s.alertsEnabled);
export const useSignalTypePreference = () => useDiffFirstStore((s) => s.signalTypePreference);
export const useSetSignalTypePreference = () => useDiffFirstStore((s) => s.setSignalTypePreference);
export const useAlertHistory = () => {
  const games = useDiffFirstStore((s) => s.games);
  const storedHistory = useDiffFirstStore((s) => s.alertHistory);

  // Combine stored history with alerts from all finished games
  const gameAlerts = games
    .filter((g) => g.status === 'final')
    .flatMap((g) =>
      g.alerts.map((a) => ({
        ...a,
        // Add game info for context
        _gameHomeTeam: g.homeTeam.abbreviation,
        _gameAwayTeam: g.awayTeam.abbreviation,
        _gameDate: g.gameDate,
      }))
    )
    .filter((a) => a.outcome !== 'pending');

  // Merge and dedupe by id, sorted by timestamp (newest first)
  const allAlerts = [...storedHistory, ...gameAlerts];
  const uniqueAlerts = Array.from(
    new Map(allAlerts.map((a) => [a.id, a])).values()
  );

  return uniqueAlerts.sort(
    (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );
};

// Get active alerts from all games
export const useActiveAlerts = () => {
  const games = useDiffFirstStore((s) => s.games);
  return games.flatMap((g) => g.alerts).filter((a) => a.outcome === 'pending');
};

// Get all historical alerts including high conviction
export const useAllHistoricalAlerts = () => {
  const games = useDiffFirstStore((s) => s.games);
  const storedHistory = useDiffFirstStore((s) => s.alertHistory);

  // Get alerts from all games (live games' past alerts + final games' alerts)
  const gameAlerts = games.flatMap((g) =>
    g.alerts
      .filter((a) => a.outcome !== 'pending')
      .map((a) => ({
        ...a,
        _gameHomeTeam: g.homeTeam.abbreviation,
        _gameAwayTeam: g.awayTeam.abbreviation,
        _gameDate: g.gameDate,
        _gameFinal: g.status === 'final',
      }))
  );

  // Merge stored and game alerts
  const allAlerts = [...storedHistory, ...gameAlerts];
  const uniqueAlerts = Array.from(
    new Map(allAlerts.map((a) => [a.id, a])).values()
  );

  return uniqueAlerts.sort(
    (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );
};

// Get high conviction alerts only
export const useHighConvictionAlerts = () => {
  const allAlerts = useAllHistoricalAlerts();
  return allAlerts.filter((a) => a.isHighConviction);
};

// Get momentum alerts only (original spread strategy)
export const useMomentumAlerts = () => {
  const allAlerts = useAllHistoricalAlerts();
  return allAlerts.filter((a) => !a.signalStrategy || a.signalStrategy === 'momentum');
};

// Get active momentum alerts
export const useActiveMomentumAlerts = () => {
  const activeAlerts = useActiveAlerts();
  return activeAlerts.filter((a) => !a.signalStrategy || a.signalStrategy === 'momentum');
};

// Get high conviction Momentum alerts
export const useHighConvictionMomentumAlerts = () => {
  const momentumAlerts = useMomentumAlerts();
  return momentumAlerts.filter((a) => a.isHighConviction);
};

// Pro access state (managed separately for subscription status)
export const useHasProAccess = () => useDiffFirstStore((s) => s.hasProAccess);
export const useSetProAccess = () => useDiffFirstStore((s) => s.setProAccess);
