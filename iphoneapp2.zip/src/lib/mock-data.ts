// DiffFirst Mock Data Generator
import type { Game, Team, Possession, DifferentialPoint, Run, Alert, GameAnalytics, SupportResistanceLevel, OddsData } from './types';

// NBA Teams
export const NBA_TEAMS: Team[] = [
  { id: 'lal', name: 'Lakers', abbreviation: 'LAL', city: 'Los Angeles', primaryColor: '#552583', secondaryColor: '#FDB927' },
  { id: 'bos', name: 'Celtics', abbreviation: 'BOS', city: 'Boston', primaryColor: '#007A33', secondaryColor: '#BA9653' },
  { id: 'gsw', name: 'Warriors', abbreviation: 'GSW', city: 'Golden State', primaryColor: '#1D428A', secondaryColor: '#FFC72C' },
  { id: 'mia', name: 'Heat', abbreviation: 'MIA', city: 'Miami', primaryColor: '#98002E', secondaryColor: '#F9A01B' },
  { id: 'phi', name: '76ers', abbreviation: 'PHI', city: 'Philadelphia', primaryColor: '#006BB6', secondaryColor: '#ED174C' },
  { id: 'den', name: 'Nuggets', abbreviation: 'DEN', city: 'Denver', primaryColor: '#0E2240', secondaryColor: '#FEC524' },
  { id: 'dal', name: 'Mavericks', abbreviation: 'DAL', city: 'Dallas', primaryColor: '#00538C', secondaryColor: '#002B5E' },
  { id: 'mil', name: 'Bucks', abbreviation: 'MIL', city: 'Milwaukee', primaryColor: '#00471B', secondaryColor: '#EEE1C6' },
  { id: 'phx', name: 'Suns', abbreviation: 'PHX', city: 'Phoenix', primaryColor: '#1D1160', secondaryColor: '#E56020' },
  { id: 'cle', name: 'Cavaliers', abbreviation: 'CLE', city: 'Cleveland', primaryColor: '#860038', secondaryColor: '#FDBB30' },
];

// Generate realistic possession-by-possession data
function generatePossessions(quarter: number, maxPossessions: number): Possession[] {
  const possessions: Possession[] = [];
  let homeScore = 0;
  let awayScore = 0;
  let timestamp = 0;

  for (let q = 1; q <= quarter; q++) {
    const possessionsInQuarter = q === quarter ? Math.floor(maxPossessions * 0.8) : Math.floor(Math.random() * 10) + 20;

    for (let p = 0; p < possessionsInQuarter; p++) {
      const isHomeTeam = Math.random() > 0.5;
      const scoringChance = Math.random();
      let pointsScored = 0;
      let event: Possession['event'] = 'turnover';

      if (scoringChance > 0.55) {
        // Scoring possession
        const shotType = Math.random();
        if (shotType < 0.15) {
          pointsScored = 3;
        } else if (shotType < 0.7) {
          pointsScored = 2;
        } else {
          pointsScored = Math.random() > 0.2 ? 2 : 1; // FT situation
        }
        event = 'score';

        if (isHomeTeam) {
          homeScore += pointsScored;
        } else {
          awayScore += pointsScored;
        }
      } else if (scoringChance > 0.45) {
        event = 'foul';
      } else if (scoringChance > 0.42) {
        event = 'timeout';
      }

      const quarterSeconds = (12 * 60) - (p * (12 * 60 / possessionsInQuarter));
      const minutes = Math.floor(quarterSeconds / 60);
      const seconds = Math.floor(quarterSeconds % 60);

      timestamp = (q - 1) * 12 * 60 + (12 * 60 - quarterSeconds);

      possessions.push({
        id: `pos-${q}-${p}`,
        timestamp,
        quarter: q,
        quarterTime: `${minutes}:${seconds.toString().padStart(2, '0')}`,
        team: isHomeTeam ? 'home' : 'away',
        homeScore,
        awayScore,
        differential: homeScore - awayScore,
        fairDifferential: homeScore - awayScore + (Math.random() - 0.5) * 2,
        event,
        pointsScored: pointsScored > 0 ? pointsScored : undefined,
      });
    }
  }

  return possessions;
}

// Detect runs in possession data
function detectRuns(possessions: Possession[]): Run[] {
  const runs: Run[] = [];
  if (possessions.length < 5) return runs;

  let runStart = 0;
  let runTeam: 'home' | 'away' = 'home';
  let homeRunPoints = 0;
  let awayRunPoints = 0;

  for (let i = 1; i < possessions.length; i++) {
    const prev = possessions[i - 1];
    const curr = possessions[i];

    const homeScored = curr.homeScore - prev.homeScore;
    const awayScored = curr.awayScore - prev.awayScore;

    homeRunPoints += homeScored;
    awayRunPoints += awayScored;

    // Check if run should end (opposing team scores 4+ points)
    const isHomeRun = runTeam === 'home';
    const opposingPoints = isHomeRun ? awayRunPoints : homeRunPoints;
    const teamPoints = isHomeRun ? homeRunPoints : awayRunPoints;

    if (opposingPoints >= 4 || i - runStart > 15) {
      // End current run if significant
      if (teamPoints >= 8 && teamPoints - opposingPoints >= 6) {
        runs.push({
          startPossession: runStart,
          endPossession: i - 1,
          team: runTeam,
          points: teamPoints,
          opposingPoints,
          description: `${teamPoints}-${opposingPoints} run`,
        });
      }

      // Start new run
      runStart = i;
      runTeam = awayScored > homeScored ? 'away' : 'home';
      homeRunPoints = homeScored;
      awayRunPoints = awayScored;
    }
  }

  return runs;
}

// Calculate analytics from possession data
function calculateAnalytics(possessions: Possession[]): GameAnalytics {
  if (possessions.length < 5) {
    return {
      rsi7: 50,
      rsi14: 50,
      slope6: 0,
      slopeFromStart: 0,
      raRSI: 50,
      trendStrength: 0,
      trendDirection: 'neutral',
      volatility: 'medium',
      regimeShift: false,
      regimeShiftConfirmed: false,
      supportLevels: [],
      resistanceLevels: [],
      currentMomentum: 'neutral',
      meanReversionStretch: false,
      momentumSwing: 0,
      isCloseGame: false,
      leadRegressionEligible: false,
      blowoutDetected: false,
      recentLeadMaxCount: 0,
    };
  }

  const differentials = possessions.map(p => p.differential);
  const recentDiffs = differentials.slice(-20);

  // Calculate RSI-like metric
  let gains = 0;
  let losses = 0;
  for (let i = 1; i < recentDiffs.length; i++) {
    const change = recentDiffs[i] - recentDiffs[i - 1];
    if (change > 0) gains += change;
    else losses -= change;
  }
  const rs = losses === 0 ? 100 : gains / losses;
  const raRSI = 100 - (100 / (1 + rs));

  // Trend calculation
  const trendWindow = Math.min(15, differentials.length);
  const trendDiffs = differentials.slice(-trendWindow);
  const avgStart = trendDiffs.slice(0, Math.floor(trendWindow / 2)).reduce((a, b) => a + b, 0) / Math.floor(trendWindow / 2);
  const avgEnd = trendDiffs.slice(-Math.floor(trendWindow / 2)).reduce((a, b) => a + b, 0) / Math.floor(trendWindow / 2);
  const trendStrength = Math.max(-1, Math.min(1, (avgEnd - avgStart) / 10));

  // Volatility calculation - based on standard deviation of score changes
  // Basketball typically has 2-3 pt swings per possession
  const changes = recentDiffs.map((d, i) => i === 0 ? 0 : Math.abs(d - recentDiffs[i - 1]));
  const avgChange = changes.slice(1).reduce((a, b) => a + b, 0) / (changes.length - 1);
  // Low: < 2 avg change, Medium: 2-4, High: > 4
  const volatility = avgChange > 4 ? 'high' : avgChange > 2 ? 'medium' : 'low';

  // Support/Resistance detection with identification timing
  const diffCounts: Map<number, { count: number; firstSeen: number }> = new Map();
  differentials.forEach((d, idx) => {
    const rounded = Math.round(d);
    const existing = diffCounts.get(rounded);
    if (existing) {
      existing.count++;
    } else {
      diffCounts.set(rounded, { count: 1, firstSeen: idx });
    }
  });

  const supportLevels: SupportResistanceLevel[] = [];
  const resistanceLevels: SupportResistanceLevel[] = [];
  const currentDiff = differentials[differentials.length - 1];

  diffCounts.forEach(({ count, firstSeen }, level) => {
    if (count >= 3) {
      const strength = count >= 5 ? 'strong' : count >= 4 ? 'moderate' : 'weak';
      // Calculate when this level was first identified (after 3 touches)
      const identifiedPossession = Math.min(firstSeen + count * 3, possessions.length - 1);
      const identifiedQuarter = possessions[identifiedPossession]?.quarter || 1;
      const identifiedTime = possessions[identifiedPossession]?.quarterTime || '10:00';

      const levelData: SupportResistanceLevel = {
        level,
        type: level < currentDiff ? 'support' : 'resistance',
        touches: count,
        strength,
        identifiedAt: {
          quarter: identifiedQuarter,
          gameTime: `Q${identifiedQuarter} ${identifiedTime}`,
          possessionIndex: identifiedPossession,
        },
      };

      if (level < currentDiff) {
        supportLevels.push(levelData);
      } else if (level > currentDiff) {
        resistanceLevels.push(levelData);
      }
    }
  });

  // Mean reversion stretch detection
  const meanReversionStretch = raRSI < 25 || raRSI > 75;

  // Calculate momentum swing (last 10 possessions)
  const last10Diffs = differentials.slice(-10);
  const momentumSwing = last10Diffs.length >= 2
    ? last10Diffs[last10Diffs.length - 1] - last10Diffs[0]
    : 0;

  // Check if close game (within 3 points)
  const currentDifferential = differentials[differentials.length - 1];
  const isCloseGame = Math.abs(currentDifferential) <= 3;

  // Calculate RSI-7 for spread strategy
  const rsi7Window = differentials.slice(-8);
  let rsi7Gains = 0;
  let rsi7Losses = 0;
  for (let i = 1; i < rsi7Window.length; i++) {
    const change = rsi7Window[i] - rsi7Window[i - 1];
    if (change > 0) rsi7Gains += change;
    else rsi7Losses -= change;
  }
  const rsi7Rs = rsi7Losses === 0 ? 100 : rsi7Gains / rsi7Losses;
  const rsi7 = rsi7Window.length >= 7 ? 100 - (100 / (1 + rsi7Rs)) : 50;

  // Calculate RSI-14 for spread strategy
  const rsi14Window = differentials.slice(-15);
  let rsi14Gains = 0;
  let rsi14Losses = 0;
  for (let i = 1; i < rsi14Window.length; i++) {
    const change = rsi14Window[i] - rsi14Window[i - 1];
    if (change > 0) rsi14Gains += change;
    else rsi14Losses -= change;
  }
  const rsi14Rs = rsi14Losses === 0 ? 100 : rsi14Gains / rsi14Losses;
  const rsi14 = rsi14Window.length >= 14 ? 100 - (100 / (1 + rsi14Rs)) : 50;

  // Calculate 6-possession slope for spread strategy
  const slope6Window = differentials.slice(-6);
  let slope6 = 0;
  if (slope6Window.length >= 6) {
    const n = slope6Window.length;
    let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
    for (let i = 0; i < n; i++) {
      sumX += i;
      sumY += slope6Window[i];
      sumXY += i * slope6Window[i];
      sumX2 += i * i;
    }
    slope6 = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
  }

  // Calculate slope from game start
  let slopeFromStart = 0;
  if (differentials.length >= 5) {
    const n = differentials.length;
    let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
    for (let i = 0; i < n; i++) {
      sumX += i;
      sumY += differentials[i];
      sumXY += i * differentials[i];
      sumX2 += i * i;
    }
    const denom = n * sumX2 - sumX * sumX;
    if (denom !== 0) {
      slopeFromStart = (n * sumXY - sumX * sumY) / denom;
    }
  }

  // Lead Regression Analytics
  const leadCurrentDiff = differentials[differentials.length - 1];
  const absDiff = Math.abs(leadCurrentDiff);

  // Blowout detection: count new lead highs in last 15 possessions
  const last15Diffs = differentials.slice(-15).map(d => Math.abs(d));
  let recentLeadMaxCount = 0;
  let runningMax = last15Diffs[0] || 0;
  for (let i = 1; i < last15Diffs.length; i++) {
    if (last15Diffs[i] > runningMax) {
      recentLeadMaxCount++;
      runningMax = last15Diffs[i];
    }
  }
  const blowoutDetected = recentLeadMaxCount >= 3;

  // Lead regression eligibility: 12+ point lead, not a blowout
  const leadRegressionEligible = absDiff >= 12 && !blowoutDetected;

  return {
    rsi7: Math.round(rsi7),
    rsi14: Math.round(rsi14),
    slope6: Math.round(slope6 * 100) / 100,
    slopeFromStart: Math.round(slopeFromStart * 1000) / 1000,
    raRSI: Math.round(raRSI),
    trendStrength,
    trendDirection: trendStrength > 0.2 ? 'bullish' : trendStrength < -0.2 ? 'bearish' : 'neutral',
    volatility,
    regimeShift: Math.abs(trendStrength) > 0.5,
    regimeShiftConfirmed: Math.abs(trendStrength) > 0.7,
    supportLevels: supportLevels.sort((a, b) => b.level - a.level).slice(0, 3),
    resistanceLevels: resistanceLevels.sort((a, b) => a.level - b.level).slice(0, 3),
    currentMomentum: trendStrength > 0.15 ? 'home' : trendStrength < -0.15 ? 'away' : 'neutral',
    meanReversionStretch,
    momentumSwing,
    isCloseGame,
    leadRegressionEligible,
    blowoutDetected,
    recentLeadMaxCount,
  };
}

// Generate mock odds
function generateOdds(differential: number): OddsData {
  const baseSpread = -differential + (Math.random() - 0.5) * 3;

  return {
    homeSpread: Math.round(baseSpread * 2) / 2,
    homeSpreadOdds: -110 + Math.floor(Math.random() * 20 - 10),
    awaySpread: -Math.round(baseSpread * 2) / 2,
    awaySpreadOdds: -110 + Math.floor(Math.random() * 20 - 10),
    homeMoneyline: differential > 5 ? -200 - differential * 20 : differential < -5 ? 150 - differential * 15 : -110 - differential * 10,
    awayMoneyline: differential > 5 ? 180 + differential * 15 : differential < -5 ? -180 + differential * 20 : 100 + differential * 10,
    total: 210 + Math.floor(Math.random() * 20),
    overOdds: -110,
    underOdds: -110,
    impliedHomeProbability: 0.5 + differential * 0.02,
    impliedAwayProbability: 0.5 - differential * 0.02,
  };
}

// Generate indicator state snapshot for signal (no forward bias - only uses data available at signal time)
function generateIndicatorSnapshot(
  raRSI: number,
  volatility: 'low' | 'medium' | 'high',
  differential: number,
  quarter: number,
  isAwayStretched: boolean
): import('./types').SignalIndicatorState[] {
  return [
    {
      name: 'raRSI (Run-Adjusted RSI)',
      value: raRSI,
      explanation: raRSI > 70
        ? `Momentum heavily favoring one team (${raRSI}). Historically, extreme readings mean-revert 65% of the time.`
        : raRSI < 30
        ? `Momentum heavily oversold (${raRSI}). Historically, extreme readings mean-revert 65% of the time.`
        : `Neutral momentum reading (${raRSI}). No extreme detected.`,
      signalContribution: raRSI > 70 ? 'bearish' : raRSI < 30 ? 'bullish' : 'neutral',
    },
    {
      name: 'Volatility',
      value: volatility,
      explanation: volatility === 'high'
        ? 'High scoring swings detected. Both teams exchanging runs frequently - good fade opportunity.'
        : volatility === 'low'
        ? 'Low scoring variance. Game flow is stable and predictable.'
        : 'Moderate variance. Normal game flow with occasional runs.',
      signalContribution: volatility === 'high' ? (isAwayStretched ? 'bullish' : 'bearish') : 'neutral',
    },
    {
      name: 'Differential',
      value: `${differential > 0 ? '+' : ''}${differential}`,
      explanation: Math.abs(differential) > 10
        ? `Large ${Math.abs(differential)}-point gap. Statistically likely to compress in Q${quarter >= 4 ? '4' : quarter + 1}.`
        : Math.abs(differential) > 5
        ? `Moderate ${Math.abs(differential)}-point lead. Game still competitive.`
        : 'Close game. Either team could take control.',
      signalContribution: Math.abs(differential) > 10 ? (differential > 0 ? 'bearish' : 'bullish') : 'neutral',
    },
    {
      name: 'Game Phase',
      value: `Q${quarter}`,
      explanation: quarter <= 2
        ? 'Early game - signals have more time to play out but also more variance.'
        : quarter === 3
        ? 'Third quarter - historically where comebacks begin.'
        : 'Fourth quarter - urgency increases variance and mean reversion likelihood.',
      signalContribution: quarter >= 3 ? 'bullish' : 'neutral',
    },
  ];
}

// Generate alerts based on analytics - MOMENTUM + MODERATE DEFICIT approach
function generateAlerts(game: Partial<Game>, analytics: GameAnalytics, odds: OddsData, forceAlert: boolean = false): Alert[] {
  const alerts: Alert[] = [];

  // MOMENTUM STRATEGY: Only generate alert if conditions are optimal
  const absDiff = Math.abs(game.differential || 0);
  const quarter = game.quarter || 2;

  // Momentum thresholds: 7-12 point deficit, Q2/Q3 only
  const isOptimalDeficit = absDiff >= 7 && absDiff <= 12;
  const isOptimalTiming = quarter === 2 || quarter === 3;
  const shouldGenerate = (isOptimalDeficit && isOptimalTiming) || forceAlert;

  if (shouldGenerate && (Math.random() > 0.5 || forceAlert)) {
    const isAwayBet = (game.differential || 0) > 0; // Away is trailing if home leads
    const modelProb = isAwayBet ? 58 : 58; // Momentum-based 58% model probability
    const impliedProb = 45; // Market implied for moderate deficit
    const edge = Math.round((modelProb - impliedProb) / 10) / 10 + 7; // Base 7% + bonus

    const scoreAtSignal = {
      home: game.homeScore || 0,
      away: game.awayScore || 0,
      differential: game.differential || 0,
    };

    // Generate momentum-based bet instruction
    const betTeamName = isAwayBet ? game.awayTeam?.name || 'Away' : game.homeTeam?.name || 'Home';
    const betTeamAbbr = isAwayBet ? game.awayTeam?.abbreviation || 'AWY' : game.homeTeam?.abbreviation || 'HME';
    // Spread = actual deficit
    const betSpread = isAwayBet ? absDiff : -absDiff;
    const spreadDisplay = betSpread > 0 ? `+${betSpread}` : `${betSpread}`;

    const betInstruction = `BET: Take ${betTeamAbbr} ${spreadDisplay} on the SPREAD`;
    const expectedOutcome = `EXPECT: ${betTeamName} to cover. They are down ${absDiff} at Q${quarter} ${game.quarterTime || '8:00'}.`;

    // High conviction for 8-10 point deficit with momentum
    const isHighConviction = absDiff >= 8 && absDiff <= 10;

    alerts.push({
      id: `alert-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      gameId: game.id || '',
      timestamp: new Date(),
      gameTime: `Q${quarter} ${game.quarterTime || '8:00'}`,
      betType: 'spread',
      team: isAwayBet ? 'away' : 'home',
      recommendation: `${betTeamAbbr} ${spreadDisplay}`,
      betInstruction,
      expectedOutcome,
      edge: Math.round(edge * 10) / 10,
      modelProbability: modelProb,
      impliedProbability: impliedProb,
      confidence: isHighConviction ? 'high' : 'medium',
      reasonCodes: [
        `Moderate deficit: ${absDiff}-pt (optimal 7-12 range)`,
        `Signal at Q${quarter} ${game.quarterTime || '8:00'}`,
        isHighConviction ? 'High conviction: 8-10 pt deficit + momentum' : 'Standard momentum signal',
      ],
      riskLevel: isHighConviction ? 'low' : 'medium',
      outcome: 'pending',
      isHighConviction,
      scoreAtSignal,
      indicatorsAtSignal: generateIndicatorSnapshot(analytics.raRSI, analytics.volatility, scoreAtSignal.differential, quarter, isAwayBet),
      supportResistanceAtSignal: [...analytics.supportLevels, ...analytics.resistanceLevels],
    });
  }

  return alerts;
}

// Create a mock live game
export function createMockGame(
  homeTeam: Team,
  awayTeam: Team,
  gameState: 'live' | 'halftime' | 'scheduled' | 'final' = 'live',
  gameDate: string = 'Today'
): Game {
  const quarter = gameState === 'scheduled' ? 0 : gameState === 'final' ? 4 : gameState === 'halftime' ? 2 : Math.floor(Math.random() * 4) + 1;
  const possessions = gameState === 'scheduled' ? [] : generatePossessions(gameState === 'final' ? 4 : quarter, gameState === 'final' ? 25 : Math.floor(Math.random() * 15) + 10);

  const lastPossession = possessions[possessions.length - 1];
  const homeScore = lastPossession?.homeScore || 0;
  const awayScore = lastPossession?.awayScore || 0;
  const differential = homeScore - awayScore;

  const analytics = calculateAnalytics(possessions);
  const odds = generateOdds(differential);

  const game: Partial<Game> = {
    id: `${homeTeam.id}-${awayTeam.id}-${Date.now()}`,
    homeTeam,
    awayTeam,
    homeScore,
    awayScore,
    differential,
    fairDifferential: differential + (Math.random() - 0.5) * 2,
  };

  // Generate current alerts for live/halftime games
  let alerts = generateAlerts(game, analytics, odds, false);

  // For finished games, generate MOMENTUM-BASED historical alerts with outcomes
  if (gameState === 'final') {
    // Only 1-2 alerts per finished game (quality over quantity)
    const numHistoricalAlerts = Math.floor(Math.random() * 2) + 1;
    const historicalAlerts: Alert[] = [];

    // Generate signals only in Q2 and Q3 (momentum timing)
    for (let i = 0; i < numHistoricalAlerts; i++) {
      const timeOffset = (i + 1) * 18 * 60 * 1000; // 18 min intervals

      // Only Q2 and Q3 signals
      const signalQuarter = i === 0 ? 2 : 3;

      // Calculate realistic game state at signal time
      const signalProgress = signalQuarter === 2 ? 0.35 : 0.65;
      const signalHomeScore = Math.round(homeScore * signalProgress);
      const signalAwayScore = Math.round(awayScore * signalProgress);
      const signalDiff = signalHomeScore - signalAwayScore;
      const absDiff = Math.abs(signalDiff);

      // MOMENTUM STRATEGY: Only generate if deficit was 7-12 points
      if (absDiff < 7 || absDiff > 12) {
        continue;
      }

      // Determine who was trailing (bet on trailing team)
      const wasAwayBet = signalDiff > 0; // Away trails if home leads
      const betTeam = wasAwayBet ? 'away' : 'home';
      const betTeamAbbr = wasAwayBet ? awayTeam.abbreviation : homeTeam.abbreviation;
      const betTeamName = wasAwayBet ? awayTeam.name : homeTeam.name;

      // Spread = actual deficit
      const betSpread = absDiff;
      const spreadDisplay = `+${betSpread}`;

      // Higher win rate with momentum approach (60%)
      const outcomes: ('win' | 'loss' | 'push')[] = ['win', 'win', 'win', 'win', 'win', 'win', 'loss', 'loss', 'loss', 'push'];
      const outcome = outcomes[Math.floor(Math.random() * outcomes.length)];

      // Edge: 7-11%
      const edge = Math.round((7 + Math.random() * 4) * 10) / 10;

      // High conviction for 8-10 point deficit
      const isHighConviction = absDiff >= 8 && absDiff <= 10;

      // Timing: Q2 3+ min or Q3 2+ min
      const quarterMinutes = signalQuarter === 2 ? 3 + Math.floor(Math.random() * 8) : 2 + Math.floor(Math.random() * 8);
      const quarterSeconds = Math.floor(Math.random() * 60);

      // Calculate possession index for accurate chart placement
      const possessionIndex = Math.floor(signalProgress * possessions.length);

      const signalRSI = Math.round(50 + Math.random() * 15);
      const signalVolatility: 'low' | 'medium' | 'high' = 'medium';

      const betInstruction = `BET: Take ${betTeamAbbr} ${spreadDisplay} on the SPREAD`;
      const expectedOutcomeText = `EXPECT: ${betTeamName} to cover. They were down ${absDiff} at Q${signalQuarter} ${quarterMinutes}:${quarterSeconds.toString().padStart(2, '0')}. Final margin was ${Math.abs(differential)} for ${differential > 0 ? homeTeam.abbreviation : awayTeam.abbreviation}.`;

      historicalAlerts.push({
        id: `alert-hist-${i}-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
        gameId: game.id || '',
        timestamp: new Date(Date.now() - timeOffset),
        gameTime: `Q${signalQuarter} ${quarterMinutes}:${quarterSeconds.toString().padStart(2, '0')}`,
        betType: 'spread',
        team: betTeam,
        recommendation: `${betTeamAbbr} ${spreadDisplay}`,
        edge,
        modelProbability: isHighConviction ? 60 : 57,
        impliedProbability: 45,
        confidence: isHighConviction ? 'high' : 'medium',
        reasonCodes: [
          `Moderate deficit: ${absDiff}-pt (optimal 7-12 range)`,
          `Signal at Q${signalQuarter} ${quarterMinutes}:${quarterSeconds.toString().padStart(2, '0')}`,
          isHighConviction ? 'High conviction: 8-10 pt deficit + momentum' : 'Standard momentum signal',
        ],
        riskLevel: isHighConviction ? 'low' : 'medium',
        outcome,
        isHighConviction,
        betInstruction,
        expectedOutcome: expectedOutcomeText,
        scoreAtSignal: {
          home: signalHomeScore,
          away: signalAwayScore,
          differential: signalDiff,
        },
        possessionIndex,
        indicatorsAtSignal: generateIndicatorSnapshot(signalRSI, signalVolatility, signalDiff, signalQuarter, wasAwayBet),
        supportResistanceAtSignal: [],
      });
    }

    alerts = historicalAlerts;
  }

  // For live games in later quarters, add momentum-based past alerts
  if ((gameState === 'live' || gameState === 'halftime') && quarter >= 2) {
    const absDiff = Math.abs(differential);

    // Only add past alert if current game had a 7-12 point deficit in Q2
    if (absDiff >= 5) {
      const pastQuarter = 2;
      const pastProgress = 0.35;
      const pastHomeScore = Math.round(homeScore * pastProgress);
      const pastAwayScore = Math.round(awayScore * pastProgress);
      const pastDiff = pastHomeScore - pastAwayScore;
      const pastAbsDiff = Math.abs(pastDiff);

      // Only if it met momentum thresholds (7-12 points)
      if (pastAbsDiff >= 7 && pastAbsDiff <= 12) {
        const wasAwayBet = pastDiff > 0;
        const betTeam = wasAwayBet ? 'away' : 'home';
        const betTeamAbbr = wasAwayBet ? awayTeam.abbreviation : homeTeam.abbreviation;
        const betTeamName = wasAwayBet ? awayTeam.name : homeTeam.name;
        const spreadDisplay = `+${pastAbsDiff}`;
        const isHighConviction = pastAbsDiff >= 8 && pastAbsDiff <= 10;

        const pastAlert: Alert = {
          id: `alert-past-${Date.now()}`,
          gameId: game.id || '',
          timestamp: new Date(Date.now() - 30 * 60 * 1000),
          gameTime: `Q${pastQuarter} ${Math.floor(Math.random() * 8) + 3}:${Math.floor(Math.random() * 60).toString().padStart(2, '0')}`,
          betType: 'spread',
          team: betTeam,
          recommendation: `${betTeamAbbr} ${spreadDisplay}`,
          edge: Math.round((7 + Math.random() * 4) * 10) / 10,
          modelProbability: isHighConviction ? 60 : 57,
          impliedProbability: 45,
          confidence: isHighConviction ? 'high' : 'medium',
          reasonCodes: [
            `Moderate deficit: ${pastAbsDiff}-pt (optimal 7-12 range)`,
            `Signal at Q${pastQuarter}`,
            isHighConviction ? 'High conviction: 8-10 pt deficit + momentum' : 'Standard momentum signal',
          ],
          riskLevel: isHighConviction ? 'low' : 'medium',
          outcome: Math.random() > 0.4 ? 'win' : 'loss',
          isHighConviction,
          betInstruction: `BET: Take ${betTeamAbbr} ${spreadDisplay} on the SPREAD`,
          expectedOutcome: `EXPECT: ${betTeamName} to cover. They were down ${pastAbsDiff} at Q${pastQuarter}.`,
          scoreAtSignal: {
            home: pastHomeScore,
            away: pastAwayScore,
            differential: pastDiff,
          },
          possessionIndex: Math.floor(pastProgress * possessions.length),
          indicatorsAtSignal: generateIndicatorSnapshot(55, 'medium', pastDiff, pastQuarter, wasAwayBet),
          supportResistanceAtSignal: [],
        };

        alerts = [pastAlert, ...alerts];
      }
    }
  }

  return {
    ...game,
    quarter,
    quarterTime: gameState === 'final' ? '0:00' : lastPossession?.quarterTime || '12:00',
    gameTime: '7:30 PM ET',
    gameDate,
    status: gameState,
    possession: gameState === 'live' ? (Math.random() > 0.5 ? 'home' : 'away') : null,
    possessions,
    differentialHistory: possessions.map((p, i) => ({
      possession: i,
      differential: p.differential,
      fairDifferential: p.fairDifferential,
      timestamp: p.timestamp,
      quarter: p.quarter,
    })),
    runs: detectRuns(possessions),
    analytics,
    odds,
    alerts,
    recentDifferentials: possessions.slice(-20).map(p => p.differential),
    playByPlayAvailable: true,
  } as Game;
}

// Generate a set of mock games for today
export function generateMockGames(): Game[] {
  const games: Game[] = [];

  // Get formatted dates
  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  const twoDaysAgo = new Date(today);
  twoDaysAgo.setDate(twoDaysAgo.getDate() - 2);
  const threeDaysAgo = new Date(today);
  threeDaysAgo.setDate(threeDaysAgo.getDate() - 3);

  const formatDate = (d: Date) => d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

  // Live games - Today
  games.push(createMockGame(NBA_TEAMS[0], NBA_TEAMS[1], 'live', 'Today')); // LAL vs BOS
  games.push(createMockGame(NBA_TEAMS[2], NBA_TEAMS[3], 'live', 'Today')); // GSW vs MIA
  games.push(createMockGame(NBA_TEAMS[4], NBA_TEAMS[5], 'halftime', 'Today')); // PHI vs DEN

  // Upcoming games - Today
  games.push(createMockGame(NBA_TEAMS[6], NBA_TEAMS[7], 'scheduled', 'Today')); // DAL vs MIL
  games.push(createMockGame(NBA_TEAMS[8], NBA_TEAMS[9], 'scheduled', 'Today')); // PHX vs CLE

  // Finished games with historical dates
  games.push(createMockGame(NBA_TEAMS[1], NBA_TEAMS[6], 'final', formatDate(yesterday))); // BOS vs DAL - Yesterday
  games.push(createMockGame(NBA_TEAMS[3], NBA_TEAMS[8], 'final', formatDate(twoDaysAgo))); // MIA vs PHX - 2 days ago
  games.push(createMockGame(NBA_TEAMS[0], NBA_TEAMS[9], 'final', formatDate(threeDaysAgo))); // LAL vs CLE - 3 days ago

  return games;
}
