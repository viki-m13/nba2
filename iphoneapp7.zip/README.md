# CourtQuant

**Quantitative Spread + Moneyline Betting Signals for NBA Games.** A sophisticated NBA analytics platform that identifies high-probability betting windows using **4 validated strategies** with **84-96% spread WR** and **90-100% ML WR** on 156 real games.

## Core Strategy: Reduced Spread + Moneyline Betting

CourtQuant uses **FOUR reduced spread + moneyline strategies** for optimal EV:

### Spread Bets (Validated on 156 real games)

| Strategy | Spread WR | Spread EV | Spread Edge | Lead | Momentum | Spread Bet |
|----------|-----------|-----------|-------------|------|----------|------------|
| **Sweet Spot** | 84.6% | +$14 | 10.6% | 10-14 pts | >= 10 | -7 (fixed) |
| **Moderate** | 84.4% | +$11 | 8.4% | 12-16 pts | >= 12 | -7 (fixed) |
| **Mid-Range** | 94.4% | +$20 | 15.4% | 14-18 pts | >= 14 | -7 (fixed) |
| **Safe** | 96.0% | +$14 | 12.0% | 16-20 pts | >= 12 | -5 (fixed) |

### Moneyline Bets (Same 156 games)

| Strategy | ML WR | ML EV | ML Edge | ML Market Prob |
|----------|-------|-------|---------|----------------|
| **Sweet Spot** | 90.2% | +$10 | 8.2% | 82% |
| **Moderate** | 90.9% | +$7 | 5.9% | 85% |
| **Mid-Range** | 100% | +$12 | 11.0% | 89% |
| **Safe** | 96.3% | +$5 | 4.3% | 92% |

### Combined EV (Per Signal)

| Strategy | Spread EV | ML EV | Combined EV |
|----------|-----------|-------|-------------|
| **Sweet Spot** | +$14 | +$10 | **+$24** |
| **Moderate** | +$11 | +$7 | **+$18** |
| **Mid-Range** | +$20 | +$12 | **+$32** |
| **Safe** | +$14 | +$5 | **+$19** |

**All strategies require**: 12-24 minutes remaining, momentum aligning with lead direction.

**Key Insight**: Each signal recommends TWO bets: a reduced spread (-7 or -5) AND a moneyline bet. Spread bets offer higher payouts, while moneyline bets offer higher win rates.

### How Reduced Spreads Work

Instead of betting the full lead (e.g., -14 when leading by 14), we bet a reduced spread:
- **Sweet Spot / Moderate / Mid-Range**: Always bet -7, regardless of lead size
- **Safe**: Always bet -5, regardless of lead size

This makes winning much easier while still providing significant edge over market odds.

## Signal Logic

```python
def get_signal(home_score, away_score, home_pts_5min, away_pts_5min, mins_remaining):
    """
    Validated on 156 real NBA games.
    Returns signal with REDUCED spread + MONEYLINE.
    """

    # Calculate lead and momentum
    score_diff = home_score - away_score
    lead = abs(score_diff)
    momentum = home_pts_5min - away_pts_5min
    mom = abs(momentum)

    # Determine leading team
    if score_diff > 0:
        side = 'home'
    elif score_diff < 0:
        side = 'away'
    else:
        return None  # Tie - no signal

    # CRITICAL: Momentum must align with lead
    if score_diff > 0 and momentum <= 0:
        return None  # Home leads but away has momentum - NO BET
    if score_diff < 0 and momentum >= 0:
        return None  # Away leads but home has momentum - NO BET

    # TIME WINDOW: 12-24 minutes remaining only
    if mins_remaining < 12 or mins_remaining > 24:
        return None

    # STRATEGY 1: SWEET SPOT (Spread 84.6% / ML 90.2%, +$24 combined EV)
    if 10 <= lead <= 14 and mom >= 10:
        return {'side': side, 'signal': 'sweet_spot', 'spread': -7, 'bet': 'spread_and_ml'}

    # STRATEGY 2: MODERATE (Spread 84.4% / ML 90.9%, +$18 combined EV)
    if 12 <= lead <= 16 and mom >= 12:
        return {'side': side, 'signal': 'moderate', 'spread': -7, 'bet': 'spread_and_ml'}

    # STRATEGY 3: MID-RANGE (Spread 94.4% / ML 100%, +$32 combined EV)
    if 14 <= lead <= 18 and mom >= 14:
        return {'side': side, 'signal': 'mid_range', 'spread': -7, 'bet': 'spread_and_ml'}

    # STRATEGY 4: SAFE (Spread 96.0% / ML 96.3%, +$19 combined EV)
    if 16 <= lead <= 20 and mom >= 12:
        return {'side': side, 'signal': 'safe', 'spread': -5, 'bet': 'spread_and_ml'}

    return None
```

## Market Probability

### Spread Market Probability (Based on cushion)

| Strategy | Cushion Range | Market Prob |
|----------|---------------|-------------|
| Sweet Spot | 3-7 | ~74% |
| Moderate | 5-9 | ~76% |
| Mid-Range | 7-11 | ~79% |
| Safe | 11-15 | ~84% |

### Moneyline Market Probability

| Strategy | ML Market Prob |
|----------|----------------|
| Sweet Spot | ~82% |
| Moderate | ~85% |
| Mid-Range | ~89% |
| Safe | ~92% |

**Edge = Model Probability - Market Probability**

## Bet Grading

### Spread Bet (REDUCED spread)
- **WIN**: Team wins by MORE than the reduced spread
- **LOSS**: Team wins by less than the spread, or loses
- **PUSH**: Team wins by exactly the spread (rare)

### Moneyline Bet
- **WIN**: Team wins the game (any margin)
- **LOSS**: Team loses the game

### Example

```
Signal: BOS -7 SPREAD + ML (Sweet Spot Strategy)
Current score: BOS 58 - NYK 46 (12-pt lead)
5-min momentum: +11 (BOS)

Bets:
1. BOS -7 SPREAD (NOT -12)
2. BOS MONEYLINE

Spread outcome:
  - BOS wins by 8+ → SPREAD WIN
  - BOS wins by exactly 7 → SPREAD PUSH
  - BOS wins by 6 or less, or loses → SPREAD LOSS

ML outcome:
  - BOS wins (any margin) → ML WIN
  - BOS loses → ML LOSS
```

## 5-Minute Momentum Calculation

```
momentum = home_pts_5min - away_pts_5min
```

- **Positive momentum**: Home team outscoring away recently
- **Negative momentum**: Away team outscoring home recently

We look at approximately the last 10 possessions (~5 minutes of game time).

## Critical Rules

1. **Momentum Must Align**: If home leads, home must have positive momentum. If away leads, away must have positive momentum.

2. **No Tie Games**: Signals only fire when one team has a clear lead.

3. **Time Window**: All strategies require 12-24 minutes remaining in the game.

4. **Strategy Priority**: Strategies are checked in order (Sweet Spot → Moderate → Mid-Range → Safe). First match wins.

5. **One Signal Per Game**: Maximum one signal per game (first valid).

6. **Two Bets Per Signal**: Each signal recommends both spread and moneyline bets.

## Features

### Home Screen - Live Games
- **Real-time scores** for all NBA games
- **Locked signals for free users** - See signals fire but details are locked
- **Pro users get instant access** - Full signal details including exact spread bet + ML

### Signal Display
- **Model probability**: Spread WR (84-96%)
- **Market probability**: ~74-84% (based on cushion at signal time)
- **Edge**: 8-15% (spread)
- **Bet instruction**: Team, REDUCED spread, AND moneyline (e.g., "BOS -7 SPREAD + ML")
- **Strategy name**: sweet_spot, moderate, mid_range, or safe

## Subscription Plans

- **Weekly** - $9.99/week
- **Monthly** - $29.99/month (Save 25%)
- **Season Pass** - $199.99/year (Save 60%)

## Technical Stack

- Expo SDK 53 + React Native
- NativeWind for styling
- Zustand for state management
- React Query for async operations
- RevenueCat for subscriptions

## Data Integration

### NBA Game Data (No API Key Required)
- **NBA.com liveData endpoints** - Official real-time scores
- **Play-by-play data** - Real scoring events for momentum calculation
- **No mock data** - All game data comes from real NBA sources

### Signal Generation Pipeline

1. **Fetch possessions** - Get play-by-play data
2. **Calculate minutes remaining** - From quarter and game clock
3. **Calculate 5-min momentum** - Points differential over last ~10 possessions
4. **Check strategy conditions** - In priority order (Sweet Spot → Moderate → Mid-Range → Safe)
5. **Verify momentum alignment** - Must match lead direction
6. **Generate signal** - Return leading team, REDUCED spread, AND moneyline
7. **Grade outcomes** - Compare final margin to REDUCED spread, check team win for ML

## Why This Strategy Works

1. **Higher Win Rate**: Betting -7 when leading by 12 means winning by 8+ is enough. Much easier than needing to win by 13+.

2. **Momentum Filter**: Requiring 10-14+ momentum ensures the leader is actively extending, not coasting.

3. **Optimal Timing**: 12-24 minute window where conditions are most predictive.

4. **Dual Bets**: Spread offers higher payout, ML offers higher win rate. Combined EV is maximized.

5. **Validated on Real Data**: Spread 84-96% WR, ML 90-100% WR across 156 real games.

## Disclaimer

CourtQuant provides spread and moneyline betting signals for entertainment and educational purposes. Historical win rates do not guarantee future results. Individual outcomes will vary. Always gamble responsibly and within your means.
