// Alert Card - Signal display for reduced spread strategies
import React from 'react';
import { View, Text, Pressable } from 'react-native';
import Animated, { FadeInUp, useAnimatedStyle, withRepeat, withSequence, withTiming } from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { Zap, TrendingUp, AlertTriangle, CheckCircle, XCircle, Clock } from 'lucide-react-native';

import type { Alert } from '@/lib/types';

interface AlertCardProps {
  alert: Alert;
  expanded?: boolean;
  onPress?: () => void;
  index?: number;
}

export function AlertCard({ alert, expanded = false, onPress, index = 0 }: AlertCardProps) {
  const pulseStyle = useAnimatedStyle(() => {
    if (alert.outcome !== 'pending') return { opacity: 1 };
    return {
      opacity: withRepeat(
        withSequence(
          withTiming(1, { duration: 1000 }),
          withTiming(0.7, { duration: 1000 })
        ),
        -1,
        true
      ),
    };
  });

  const confidenceColors = {
    low: { bg: '#F59E0B20', border: '#F59E0B40', text: '#F59E0B' },
    medium: { bg: '#10B98120', border: '#10B98140', text: '#10B981' },
    high: { bg: '#10B98130', border: '#10B98160', text: '#10B981' },
  };

  const riskColors = {
    low: '#10B981',
    medium: '#F59E0B',
    high: '#EF4444',
  };

  const outcomeConfig = {
    pending: { icon: Clock, color: '#6B7280', label: 'Pending' },
    win: { icon: CheckCircle, color: '#10B981', label: 'Win' },
    loss: { icon: XCircle, color: '#EF4444', label: 'Loss' },
    push: { icon: AlertTriangle, color: '#F59E0B', label: 'Push' },
  };

  const outcome = outcomeConfig[alert.outcome || 'pending'];

  // Determine strategy type from reason codes
  const getStrategyLabel = () => {
    const reasons = alert.reasonCodes?.join(' ') || '';
    if (reasons.includes('Sweet Spot')) return 'SWEET SPOT';
    if (reasons.includes('Moderate')) return 'MODERATE';
    if (reasons.includes('Mid-Range')) return 'MID-RANGE';
    if (reasons.includes('Safe')) return 'SAFE';
    return 'SPREAD';
  };

  return (
    <Animated.View entering={FadeInUp.delay(index * 100).springify()}>
      <Pressable onPress={onPress} className="active:opacity-80">
        <View className="overflow-hidden rounded-2xl">
          <LinearGradient
            colors={
              alert.confidence === 'high'
                ? ['#10B98115', '#10B98105']
                : ['#1A1A24', '#12121A']
            }
            style={{
              padding: 16,
              borderRadius: 16,
              borderWidth: 1,
              borderColor: confidenceColors[alert.confidence].border,
            }}
          >
            {/* Header */}
            <View className="flex-row items-center justify-between mb-3">
              <View className="flex-row items-center">
                <Animated.View
                  style={[
                    {
                      backgroundColor: confidenceColors[alert.confidence].bg,
                      borderRadius: 20,
                      padding: 6,
                    },
                    pulseStyle,
                  ]}
                >
                  <Zap size={16} color={confidenceColors[alert.confidence].text} />
                </Animated.View>
                <View className="ml-3">
                  <Text
                    className="font-bold text-lg"
                    style={{ color: confidenceColors[alert.confidence].text }}
                  >
                    {alert.recommendation}
                  </Text>
                  <Text className="text-gray-500 text-xs">
                    {alert.betType === 'spread_and_ml' ? 'SPREAD + MONEYLINE' : alert.betType.toUpperCase()}
                  </Text>
                </View>
              </View>

              {/* Outcome Badge */}
              <View
                className="flex-row items-center px-2 py-1 rounded-full"
                style={{ backgroundColor: `${outcome.color}20` }}
              >
                <outcome.icon size={14} color={outcome.color} />
                <Text
                  className="text-xs font-semibold ml-1"
                  style={{ color: outcome.color }}
                >
                  {outcome.label}
                </Text>
              </View>
            </View>

            {/* Probability Stats - Main Display */}
            <View className="bg-gray-800/50 rounded-xl p-3 mb-3">
              <View className="flex-row justify-between items-center mb-2">
                <View>
                  <Text className="text-gray-400 text-xs mb-1">Model Prob</Text>
                  <Text className="text-xl font-bold text-emerald-400">
                    {alert.modelProbability}%
                  </Text>
                </View>
                <View className="items-center">
                  <TrendingUp size={20} color="#10B981" />
                  <Text className="font-bold mt-1 text-emerald-400">
                    +{alert.edge}%
                  </Text>
                  <Text className="text-gray-500 text-xs">Edge</Text>
                </View>
                <View className="items-end">
                  <Text className="text-gray-400 text-xs mb-1">Market Prob</Text>
                  <Text className="text-gray-300 text-xl font-bold">
                    {alert.impliedProbability}%
                  </Text>
                </View>
              </View>
              {/* Momentum & Lead Details */}
              <View className="flex-row justify-between items-center pt-2 border-t border-gray-700/50">
                <View className="flex-row items-center">
                  <Text className="text-gray-500 text-xs">Lead: </Text>
                  <Text className="text-white text-xs font-semibold">
                    {alert.scoreAtSignal?.differential ? Math.abs(alert.scoreAtSignal.differential) + 'pts' : '--'}
                  </Text>
                </View>
                <View className="flex-row items-center">
                  <Text className="text-gray-500 text-xs">Momentum: </Text>
                  <Text className="text-white text-xs font-semibold">
                    {(() => {
                      // Extract momentum from reason codes (e.g., "15-pt lead with 8-pt momentum")
                      const momReason = alert.reasonCodes?.find(r => r.includes('momentum'));
                      if (momReason) {
                        const match = momReason.match(/(\d+)-pt momentum/);
                        if (match) return '+' + match[1];
                      }
                      return '--';
                    })()}
                  </Text>
                </View>
              </View>
            </View>

            {/* Signal Instruction & Expected Outcome */}
            {alert.betInstruction && (
              <View className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-3 mb-3">
                <Text className="text-emerald-400 font-bold text-base mb-2">
                  {alert.betInstruction}
                </Text>
                <Text className="text-gray-300 text-sm leading-5">
                  {alert.expectedOutcome}
                </Text>
              </View>
            )}

            {/* Reason Codes */}
            {expanded && (
              <View className="mb-3">
                <Text className="text-gray-400 text-xs mb-2 font-semibold">
                  SIGNAL DETAILS
                </Text>
                {alert.reasonCodes.map((reason, i) => (
                  <View key={i} className="flex-row items-start mb-1.5">
                    <View className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 mr-2" />
                    <Text className="text-gray-300 text-sm flex-1">{reason}</Text>
                  </View>
                ))}
              </View>
            )}

            {/* Footer - Strategy & Risk */}
            <View className="flex-row items-center justify-between pt-3 border-t border-gray-800/50">
              <View className="flex-row items-center">
                <View
                  className="px-2 py-1 rounded-full mr-2"
                  style={{ backgroundColor: confidenceColors[alert.confidence].bg }}
                >
                  <Text
                    className="text-xs font-semibold"
                    style={{ color: confidenceColors[alert.confidence].text }}
                  >
                    {getStrategyLabel()}
                  </Text>
                </View>
              </View>
              <View className="flex-row items-center">
                <Text className="text-gray-500 text-xs mr-1">Risk:</Text>
                <View
                  className="w-2 h-2 rounded-full mr-1"
                  style={{ backgroundColor: riskColors[alert.riskLevel] }}
                />
                <Text
                  className="text-xs font-semibold"
                  style={{ color: riskColors[alert.riskLevel] }}
                >
                  {alert.riskLevel.toUpperCase()}
                </Text>
              </View>
            </View>

            {/* Timestamp */}
            <Text className="text-gray-600 text-xs mt-2 text-center">
              Signal generated at {alert.gameTime}
            </Text>
          </LinearGradient>
        </View>
      </Pressable>
    </Animated.View>
  );
}

// Compact version for game detail screen
export function AlertCardCompact({ alert }: { alert: Alert }) {
  return (
    <View className="rounded-xl p-3 bg-emerald-500/10 border border-emerald-500/30">
      <View className="flex-row items-center mb-2">
        <View className="rounded-full p-2 mr-3 bg-emerald-500/20">
          <Zap size={16} color="#10B981" />
        </View>
        <View className="flex-1">
          <Text className="font-bold text-emerald-400">{alert.recommendation}</Text>
          <Text className="text-gray-400 text-xs">
            {alert.betType === 'spread_and_ml' ? 'SPREAD + ML' : alert.betType.toUpperCase()} • {alert.gameTime}
          </Text>
        </View>
      </View>
      {/* Probability Stats - Main Display */}
      <View className="bg-gray-800/30 rounded-lg p-2 mb-2">
        <View className="flex-row justify-between items-center mb-2">
          <View>
            <Text className="text-gray-500 text-xs">Model</Text>
            <Text className="text-base font-bold text-emerald-400">{alert.modelProbability}%</Text>
          </View>
          <View className="items-center">
            <Text className="text-gray-500 text-xs">Edge</Text>
            <Text className="text-base font-bold text-emerald-400">+{alert.edge}%</Text>
          </View>
          <View className="items-end">
            <Text className="text-gray-500 text-xs">Market</Text>
            <Text className="text-gray-300 text-base font-bold">{alert.impliedProbability}%</Text>
          </View>
        </View>
        {/* Momentum & Lead Details */}
        <View className="flex-row justify-between items-center pt-2 border-t border-gray-700/30">
          <View className="flex-row items-center">
            <Text className="text-gray-500 text-xs">Lead: </Text>
            <Text className="text-white text-xs font-semibold">
              {alert.scoreAtSignal?.differential ? Math.abs(alert.scoreAtSignal.differential) + 'pts' : '--'}
            </Text>
          </View>
          <View className="flex-row items-center">
            <Text className="text-gray-500 text-xs">Momentum: </Text>
            <Text className="text-white text-xs font-semibold">
              {(() => {
                // Extract momentum from reason codes
                const momReason = alert.reasonCodes?.find(r => r.includes('momentum'));
                if (momReason) {
                  const match = momReason.match(/(\d+)-pt momentum/);
                  if (match) return '+' + match[1];
                }
                return '--';
              })()}
            </Text>
          </View>
        </View>
      </View>
      {alert.betInstruction && (
        <View className="bg-gray-800/40 rounded-lg p-2">
          <Text className="text-xs font-semibold text-emerald-400">{alert.betInstruction}</Text>
          <Text className="text-gray-400 text-xs mt-1">{alert.expectedOutcome}</Text>
        </View>
      )}
    </View>
  );
}
